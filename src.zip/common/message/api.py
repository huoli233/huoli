import asyncio
import os
import importlib.metadata
from typing import Optional, Callable, Awaitable, Any
from src.common.logger import get_logger
from src.common.server import get_global_server
from src.config.config import global_config
logger = get_logger("message_api")
_global_api = None
class MessageAPIClient:
    """消息 API 客户端"""
    def __init__(self):
        self._host: Optional[str] = None
        self._port: Optional[int] = None
        self._connected = False
        self._message_handlers: dict[str, Callable] = {}
    async def connect(self, host: str, port: int) -> bool:
        self._host = host
        self._port = port
        self._connected = True
        logger.info(f"消息 API 已连接: {host}:{port}")
        return True
    async def disconnect(self) -> None:
        self._connected = False
        logger.info("消息 API 已断开")
    async def send_message(self, message: dict) -> bool:
        if not self._connected:
            logger.warning("消息 API 未连接")
            return False
        logger.debug(f"发送消息: {message.get('message_type', 'unknown')}")
        return True
    def register_handler(self, message_type: str, handler: Callable[[dict], Awaitable[None]]) -> None:
        self._message_handlers[message_type] = handler

    def register_message_handler(self, handler: Callable[[dict], Awaitable[None]]) -> None:
        """注册消息处理器（通用）"""
        self._message_handlers["default"] = handler

    def register_custom_message_handler(self, message_type: str, handler: Callable[[dict], Awaitable[None]]) -> None:
        """注册自定义消息处理器"""
        self._message_handlers[message_type] = handler

    async def run(self) -> None:
        """运行消息服务器"""
        if self._connected:
            logger.info("消息服务器正在运行...")
            while self._connected:
                await asyncio.sleep(1)
        else:
            logger.warning("消息服务器未连接，无法运行")

    async def start(self) -> None:
        """启动消息服务器"""
        await self.connect(self._host or "127.0.0.1", self._port or 8080)
    async def process_message(self, message: dict) -> None:
        msg_type = message.get("message_type", "unknown")
        handler = self._message_handlers.get(msg_type)
        if handler:
            await handler(message)
        else:
            logger.debug(f"未找到消息处理器: {msg_type}")
    @property
    def is_connected(self) -> bool:
        return self._connected
def get_message_api() -> MessageAPIClient:
    global _global_api
    if _global_api is None:
        _global_api = MessageAPIClient()
    return _global_api


get_global_api = get_message_api
async def initialize_message_api() -> MessageAPIClient:
    api = get_message_api()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8080"))
    await api.connect(host, port)
    return api
def check_maim_message_version() -> tuple[bool, bool]:
    try:
        version_str = importlib.metadata.version("maim_message")
        parts = [int(x) for x in version_str.split(".")]
        compatible = parts >= [0, 3, 3]
        has_api_server = parts >= [0, 6, 2]
        return compatible, has_api_server
    except (importlib.metadata.PackageNotFoundError, ValueError):
        return False, False
async def setup_message_server() -> Any:
    compatible, has_api_server = check_maim_message_version()
    if not compatible:
        logger.warning("maim_message 版本不兼容，使用基础模式")
        return get_message_api()
    try:
        from maim_message import MessageServer
        host = os.environ.get("HOST", "127.0.0.1")
        port = int(os.environ.get("PORT", "8080"))
        kwargs = {
            "host": host,
            "port": port,
            "app": get_global_server().get_app(),
            "custom_logger": logger,
        }
        maim_config = getattr(global_config, "maim_message", None)
        if maim_config:
            auth_tokens = getattr(maim_config, "auth_token", [])
            if auth_tokens:
                kwargs["enable_token"] = True
        server = MessageServer(**kwargs)
        if maim_config:
            auth_tokens = getattr(maim_config, "auth_token", [])
            for token in auth_tokens:
                server.add_valid_token(token)
        logger.info(f"消息服务器已初始化: {host}:{port}")
        return server
    except ImportError:
        logger.warning("maim_message 未安装，使用基础消息 API")
        return get_message_api()
