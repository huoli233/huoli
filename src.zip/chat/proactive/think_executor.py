import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config
from src.common.data_models.proactive_models import (
    ThinkOutcome, DeliveryPayload, ExecutionReport,
)
from src.chat.proactive.think_scheduler import (
    CognitiveJob, JobDomain, get_cognitive_dispatcher,
)

import src.chat.prompts.catalog  # noqa: F401 注册提示词
from src.chat.utils.prompt_builder import global_prompt_manager

logger = get_logger("cognitive_worker")


@dataclass
class WorkerContext:
    """执行上下文 — 贯穿整个思考流水线"""
    session: Any = None
    speaker_name: str = ""
    scenario: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)
    succeeded: bool = False
    parsed_outcome: Optional[ThinkOutcome] = None
    fault_reason: Optional[str] = None
    start_ts: float = 0.0
    finish_ts: float = 0.0


class CognitiveWorker:
    """
    认知执行器
    为每种 JobDomain 维护一套提示词构建器，
    通过 LLM 产出结构化决策后驱动行为执行并记录到会话日志。
    """
    _solo: Optional["CognitiveWorker"] = None
    @classmethod
    def instance(cls) -> "CognitiveWorker":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        cls._solo = None
    def __init__(self):
        self._scenario_builders: Dict[str, Any] = {
            "timeout_resolve": self._compose_timeout_prompt,
            "ponder_refresh": self._compose_ponder_prompt,
            "impulse_launch": self._compose_impulse_prompt,
            "generic_work": self._compose_generic_prompt,
        }
        self._metrics = {
            "total_runs": 0,
            "ok_runs": 0,
            "fail_runs": 0,
            "llm_calls": 0,
            "actions_fired": 0,
        }
    # ---- 主入口 ----
    async def handle_job(self, job: CognitiveJob) -> Dict[str, Any]:
        """执行一个认知任务，返回结果摘要"""
        self._metrics["total_runs"] += 1
        try:
            session = await self._acquire_session(job.target_user, job.target_channel)
            speaker_name = await self._resolve_speaker(job.target_user)
            scenario = self._domain_to_scenario(job.domain)
            ctx = WorkerContext(
                session=session,
                speaker_name=speaker_name,
                scenario=scenario,
                extra=job.payload,
                start_ts=time.time(),
            )
            await self._run_pipeline(ctx)
            ctx.finish_ts = time.time()
            if ctx.succeeded:
                self._metrics["ok_runs"] += 1
            else:
                self._metrics["fail_runs"] += 1
            return {
                "succeeded": ctx.succeeded,
                "outcome": ctx.parsed_outcome.to_brief() if ctx.parsed_outcome else None,
                "fault": ctx.fault_reason,
                "elapsed_ms": int((ctx.finish_ts - ctx.start_ts) * 1000),
            }
        except Exception as exc:
            self._metrics["fail_runs"] += 1
            logger.error(f"[执行器] 任务失败: {exc}")
            return {"succeeded": False, "fault": str(exc)}
    # ---- 流水线 ----
    async def _run_pipeline(self, ctx: WorkerContext) -> None:
        """完整思考流水线"""
        try:
            prompt = self._build_prompt(ctx)
            if not prompt:
                ctx.fault_reason = "无法构建提示词"
                return
            raw_reply = await self._call_model(prompt)
            self._metrics["llm_calls"] += 1
            if not raw_reply:
                ctx.fault_reason = "模型响应为空"
                return
            outcome = self._parse_model_output(raw_reply)
            ctx.parsed_outcome = outcome
            await self._carry_out_actions(ctx)
            await self._persist_session(ctx)
            ctx.succeeded = True
        except Exception as exc:
            ctx.fault_reason = str(exc)
            logger.error(f"[执行器] 流水线异常: {exc}")
    # ---- 提示词构建 ----
    def _build_prompt(self, ctx: WorkerContext) -> Optional[str]:
        builder = self._scenario_builders.get(ctx.scenario)
        if not builder:
            logger.warning(f"[执行器] 未找到场景构建器: {ctx.scenario}")
            return None
        return builder(ctx)
    def _compose_timeout_prompt(self, ctx: WorkerContext) -> str:
        """超时追问决策提示词"""
        session = ctx.session
        name = ctx.speaker_name
        params = ctx.extra
        last_reply = ""
        if session and hasattr(session, "fetch_last_bot_reply"):
            last_reply = session.fetch_last_bot_reply() or "(未知)"
        anticipated = params.get("anticipated_reply", "对方能回复点什么")
        seq_timeout = params.get("sequential_timeout_count", 0)
        chase_n = params.get("chase_count", 0)
        since_str = params.get("time_since_user_reply_str", "未知")
        return global_prompt_manager.get_prompt("proactive_timeout").render(
            name=name,
            last_reply=last_reply[:100],
            anticipated=anticipated,
            seq_timeout=seq_timeout,
            chase_n=chase_n,
            since_str=since_str,
        )
    def _compose_ponder_prompt(self, ctx: WorkerContext) -> str:
        """反思更新提示词"""
        session = ctx.session
        name = ctx.speaker_name
        params = ctx.extra
        last_reply = ""
        if session and hasattr(session, "fetch_last_bot_reply"):
            last_reply = session.fetch_last_bot_reply() or "(未知)"
        if len(last_reply) > 100:
            last_reply = last_reply[:100] + "..."
        elapsed_min = params.get("elapsed_minutes", 0)
        max_wait_min = params.get("max_wait_minutes", 5)
        progress = params.get("progress_percent", 50)
        anticipated = params.get("anticipated_reply", "对方能回复点什么")
        return global_prompt_manager.get_prompt("proactive_ponder").render(
            name=name,
            last_reply=last_reply,
            anticipated=anticipated,
            elapsed_min=f"{elapsed_min:.0f}",
            max_wait_min=f"{max_wait_min:.0f}",
            progress=progress,
        )
    def _compose_impulse_prompt(self, ctx: WorkerContext) -> str:
        """主动发起对话提示词"""
        name = ctx.speaker_name
        params = ctx.extra
        silence_desc = params.get("silence_duration", "一段时间")
        trigger_reason = params.get("trigger_reason", "")
        return global_prompt_manager.get_prompt("proactive_impulse").render(
            name=name,
            silence_desc=silence_desc,
            trigger_reason=trigger_reason,
        )
    def _compose_generic_prompt(self, ctx: WorkerContext) -> str:
        """通用新消息响应提示词"""
        session = ctx.session
        name = ctx.speaker_name
        params = ctx.extra
        user_msg = params.get("user_message", "")
        history_text = self._render_history(session)
        return global_prompt_manager.get_prompt("proactive_generic").render(
            name=name,
            history_text=history_text,
            user_msg=user_msg,
        )
    def _render_history(self, session: Any) -> str:
        """将会话日志渲染为文本片段"""
        if not session or not hasattr(session, "latest_entries"):
            return "(暂无对话历史)"
        try:
            records = session.latest_entries(5)
        except Exception:
            return "(暂无对话历史)"
        if not records:
            return "(暂无对话历史)"
        lines = ["最近的对话："]
        for rec in records:
            kind = getattr(rec, "kind", None)
            if kind and kind.value == "user_utterance":
                speaker = getattr(rec, "author_name", "")
                body = getattr(rec, "text_excerpt", "")[:50]
                if body:
                    lines.append(f"  {speaker}: {body}...")
            elif kind and kind.value == "bot_verdict":
                actions = getattr(rec, "action_list", [])
                for act in actions:
                    if isinstance(act, dict) and act.get("type") in ("respond", "miao_reply"):
                        content_preview = act.get("content", "")[:50]
                        if content_preview:
                            lines.append(f"  你: {content_preview}...")
                            break
        return "\n".join(lines)
    # ---- LLM 调用 ----
    async def _call_model(self, prompt: str) -> Optional[str]:
        """调用语言模型"""
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            req = LLMRequest(model_config.focus_chat, request_type="cognitive_worker")
            text, _ = await req.generate_response_async(prompt)
            return text or None
        except Exception as exc:
            logger.error(f"[执行器] 模型调用失败: {exc}")
            return None
    # ---- 响应解析 ----
    def _parse_model_output(self, raw: str) -> ThinkOutcome:
        """从模型输出解析结构化 ThinkOutcome"""
        text = raw.strip()
        json_hit = re.search(r'\{.*\}', text, re.DOTALL)
        if json_hit:
            try:
                data = json.loads(json_hit.group())
                inner = str(data.get("thought", ""))
                actions_raw = data.get("actions", [])
                anticipated = str(data.get("expected_reaction", ""))
                wait_sec = int(data.get("max_wait_seconds", 0) or 0)
                action_dicts = []
                for a in actions_raw:
                    if isinstance(a, dict):
                        action_dicts.append({
                            "type": a.get("type", "idle"),
                            "content": a.get("content", ""),
                        })
                return ThinkOutcome(
                    inner_thought=inner,
                    action_list=action_dicts,
                    anticipated_reply=anticipated,
                    follow_up_wait=wait_sec,
                )
            except json.JSONDecodeError:
                pass
        # 非 JSON 回退：纯文本当作独白
        return ThinkOutcome(
            inner_thought=text[:200],
            action_list=[{"type": "idle"}],
        )
    # ---- 行为执行 ----
    async def _carry_out_actions(self, ctx: WorkerContext) -> None:
        """遍历 ThinkOutcome 中的动作并执行"""
        if not ctx.parsed_outcome:
            return
        for action in ctx.parsed_outcome.action_list:
            if not isinstance(action, dict):
                continue
            act_type = action.get("type", "idle")
            if act_type == "idle":
                continue
            self._metrics["actions_fired"] += 1
            if act_type in ("respond", "miao_reply"):
                content = action.get("content", "")
                if content:
                    sent = await self._dispatch_message(
                        ctx.session, ctx.speaker_name, content,
                    )
                    if not sent:
                        raise RuntimeError("主动消息发送失败")
            elif act_type == "nudge":
                nudged = await self._dispatch_nudge(ctx.session)
                if not nudged:
                    raise RuntimeError("主动动作执行失败")
    async def _dispatch_message(self, session: Any, speaker: str, content: str) -> bool:
        """发送消息到频道"""
        try:
            if not session:
                logger.warning("[执行器] 缺少会话对象，无法发送主动消息")
                return False
            channel_id = getattr(session, "channel_id", "") or ""
            payload = content.strip()
            if not channel_id or not payload:
                logger.warning("[执行器] 缺少频道或内容，跳过主动发送")
                return False
            from src.chat.heart_flow.reply_coordinator import (
                ReplyUrgency,
                acquire_reply_coordinator,
            )
            from src.plugin_system.apis import send_api

            sent = await acquire_reply_coordinator().execute_reply(
                channel_id,
                send_api.text_to_stream(
                    payload,
                    stream_id=channel_id,
                    typing=False,
                    storage_message=True,
                ),
                urgency=ReplyUrgency.ACTIVE,
            )
            if sent:
                logger.info(f"[执行器] 发送到 {channel_id[:8]}: {payload[:50]}...")
            else:
                logger.error(f"[执行器] 发送失败: {channel_id[:8]}")
            return bool(sent)
        except Exception as exc:
            logger.error(f"[执行器] 发送失败: {exc}")
            return False
    async def _dispatch_nudge(self, session: Any) -> bool:
        """发送戳一戳"""
        try:
            user_id = getattr(session, "user_id", "") if session else ""
            logger.info(f"[执行器] 戳一戳 {user_id}")
            return True
        except Exception as exc:
            logger.error(f"[执行器] 戳一戳失败: {exc}")
            return False
    # ---- 会话更新 ----
    async def _persist_session(self, ctx: WorkerContext) -> None:
        """将思考结果写入会话日志并更新等待状态"""
        if not ctx.parsed_outcome or not ctx.session:
            return
        session = ctx.session
        outcome = ctx.parsed_outcome
        # 记录决策日志
        if hasattr(session, "log_bot_decision"):
            session.log_bot_decision(
                inner_thought=outcome.inner_thought,
                behaviors=outcome.action_list,
                anticipated_reply=outcome.anticipated_reply,
                timeout_seconds=outcome.follow_up_wait,
            )
        # 更新等待状态
        if outcome.follow_up_wait > 0 and hasattr(session, "begin_awaiting"):
            session.begin_awaiting(
                anticipated_reply=outcome.anticipated_reply,
                timeout_seconds=outcome.follow_up_wait,
            )
        elif hasattr(session, "finish_awaiting"):
            session.finish_awaiting()
        if any(
            isinstance(act, dict) and act.get("type") != "idle"
            for act in outcome.action_list
        ):
            session.last_initiative_at = time.time()
        # 持久化
        try:
            from src.chat.proactive.session_tracker import get_memoir_cabinet
            cabinet = get_memoir_cabinet()
            user_id = getattr(session, "user_id", "")
            if user_id:
                await cabinet.persist_memoir(user_id)
        except Exception as exc:
            logger.debug(f"[执行器] 会话持久化跳过: {exc}")
    # ---- 辅助 ----
    def _domain_to_scenario(self, domain: JobDomain) -> str:
        mapping = {
            JobDomain.TIMEOUT_RESOLVE: "timeout_resolve",
            JobDomain.PONDER_REFRESH: "ponder_refresh",
            JobDomain.IMPULSE_LAUNCH: "impulse_launch",
            JobDomain.GENERIC_WORK: "generic_work",
        }
        return mapping.get(domain, "generic_work")
    async def _acquire_session(self, user_id: str, channel_id: str) -> Any:
        """获取会话对象"""
        try:
            from src.chat.proactive.session_tracker import get_memoir_cabinet
            cabinet = get_memoir_cabinet()
            return await cabinet.fetch_memoir(user_id, channel_id)
        except Exception:
            return None
    async def _resolve_speaker(self, user_id: str) -> str:
        """解析用户名称"""
        return user_id
    def collect_metrics(self) -> Dict[str, Any]:
        return self._metrics.copy()


def get_cognitive_worker() -> CognitiveWorker:
    """获取认知执行器单例"""
    return CognitiveWorker.instance()


async def wire_up_handlers() -> None:
    """将执行器注册到调度器的各个领域"""
    dispatcher = get_cognitive_dispatcher()
    worker = get_cognitive_worker()
    dispatcher.bind_handler(JobDomain.TIMEOUT_RESOLVE, worker.handle_job)
    dispatcher.bind_handler(JobDomain.PONDER_REFRESH, worker.handle_job)
    dispatcher.bind_handler(JobDomain.IMPULSE_LAUNCH, worker.handle_job)
    dispatcher.bind_handler(JobDomain.GENERIC_WORK, worker.handle_job)
    logger.info("[执行器] 全部领域处理器已绑定")
