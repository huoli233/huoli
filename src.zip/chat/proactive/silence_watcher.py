import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config

logger = get_logger("quiet_patrol")


@dataclass
class ChannelPulseRecord:
    """单个频道的活动脉搏记录"""
    channel_id: str = ""
    latest_any_ts: float = 0.0
    latest_bot_ts: float = 0.0
    latest_human_ts: float = 0.0
    total_msg_count: int = 0
    distinct_speakers: int = 0
    known_speakers: List[str] = field(default_factory=list)
    # 静默倒计时相关
    countdown_handle: Optional[asyncio.TimerHandle] = None
    countdown_minutes: int = 0
    countdown_reset_ts: float = 0.0
    frozen: bool = False
    # 统计
    triggered_tally: int = 0
    born_at: float = field(default_factory=time.time)


class QuietPeriodMonitor:
    """
    静默期巡查器
    维护每个频道的活动记录，当频道沉默指定时长后通过回调通知上层。
    支持暂停/恢复、快速判定、LLM辅助判定三种模式。
    """
    _solo: Optional["QuietPeriodMonitor"] = None
    @classmethod
    def instance(cls) -> "QuietPeriodMonitor":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        if cls._solo is not None:
            cls._solo.disband_all()
        cls._solo = None
    def __init__(self):
        # 频道记录表
        self._pulse_table: Dict[str, ChannelPulseRecord] = {}
        # 全局静默回调（异步函数，接收 channel_id）
        self._on_quiet_callback: Optional[Callable] = None
        # 配置缓存
        self._param_cache: Dict[str, Any] = {}
        self._param_ts: float = 0.0
        self._refresh_params()
        # 统计汇总
        self._counters = {
            "resets": 0,
            "fires": 0,
            "cancels": 0,
        }
        logger.info("[巡查器] 静默期巡查器启动")
    # ---- 配置读取 ----
    def _refresh_params(self) -> None:
        now = time.time()
        if now - self._param_ts < 60.0:
            return
        hub = get_core_config()
        blk = hub.silence_detection_block()
        self._param_cache = {
            "default_minutes": int(blk.get("default_idle_minutes", 10)),
            "fast_threshold_sec": float(blk.get("fast_quiet_threshold_seconds", 300.0)),
            "active_user_factor": float(blk.get("active_user_time_factor", 0.35)),
            "stale_channel_hours": float(blk.get("stale_channel_purge_hours", 24.0)),
        }
        self._param_ts = now
    def _cp(self, key: str) -> Any:
        self._refresh_params()
        return self._param_cache[key]
    # ---- 回调设置 ----
    def attach_quiet_handler(self, handler: Callable) -> None:
        """绑定静默触发回调（异步函数，签名 async def(channel_id: str)）"""
        self._on_quiet_callback = handler
        logger.debug("[巡查器] 已绑定静默回调")
    # ---- 活动记录 ----
    def _ensure_record(self, channel_id: str) -> ChannelPulseRecord:
        if channel_id not in self._pulse_table:
            self._pulse_table[channel_id] = ChannelPulseRecord(channel_id=channel_id)
        return self._pulse_table[channel_id]
    def note_activity(
        self,
        channel_id: str,
        speaker_id: Optional[str] = None,
        is_bot: bool = False,
        idle_minutes: Optional[int] = None,
        one_shot_callback: Optional[Callable] = None,
    ) -> None:
        """
        记录频道活动并重置静默倒计时
        每次任何消息（用户或机器人）到达时调用。
        """
        rec = self._ensure_record(channel_id)
        now = time.time()
        rec.latest_any_ts = now
        rec.total_msg_count += 1
        if is_bot:
            rec.latest_bot_ts = now
        else:
            rec.latest_human_ts = now
            if speaker_id and speaker_id not in rec.known_speakers:
                rec.known_speakers.append(speaker_id)
                rec.distinct_speakers = len(rec.known_speakers)
        # 活动到来意味着打破静默
        self._revoke_countdown(channel_id)
        # 冻结状态下不设新倒计时
        if rec.frozen:
            logger.debug(f"[巡查器] {channel_id[:12]} 处于冻结态，跳过倒计时")
            return
        # 确定倒计时时长
        minutes = idle_minutes if idle_minutes is not None else self._cp("default_minutes")
        rec.countdown_minutes = minutes
        rec.countdown_reset_ts = now
        # 启动新的倒计时
        try:
            loop = asyncio.get_running_loop()
            captured_ch = channel_id
            captured_cb = one_shot_callback
            def _on_expire(ch=captured_ch, cb=captured_cb):
                self._fire_quiet_event(ch, cb)
            rec.countdown_handle = loop.call_later(minutes * 60, _on_expire)
            self._counters["resets"] += 1
            logger.debug(f"[巡查器] {channel_id[:12]} 倒计时重置: {minutes}分钟")
        except RuntimeError as exc:
            logger.warning(f"[巡查器] 无法获取事件循环: {exc}")
    # ---- 静默触发 ----
    def _fire_quiet_event(
        self,
        channel_id: str,
        specific_callback: Optional[Callable] = None,
    ) -> None:
        """倒计时到期，触发静默事件"""
        rec = self._pulse_table.get(channel_id)
        if not rec:
            return
        if rec.frozen:
            logger.debug(f"[巡查器] {channel_id[:12]} 已冻结，跳过触发")
            return
        rec.countdown_handle = None
        rec.triggered_tally += 1
        self._counters["fires"] += 1
        elapsed_sec = time.time() - rec.countdown_reset_ts
        elapsed_min = elapsed_sec / 60
        logger.info(f"[巡查器] {channel_id[:12]} 已静默 {elapsed_min:.1f} 分钟，触发回调")
        callback = specific_callback or self._on_quiet_callback
        if callback:
            try:
                asyncio.create_task(
                    self._invoke_callback(channel_id, callback),
                    name=f"quiet_fire_{channel_id[:8]}",
                )
            except Exception as exc:
                logger.error(f"[巡查器] 创建回调任务失败: {exc}")
        else:
            logger.warning(f"[巡查器] {channel_id[:12]} 无回调可触发")
    async def _invoke_callback(self, channel_id: str, callback: Callable) -> None:
        """安全执行回调"""
        try:
            if asyncio.iscoroutinefunction(callback):
                await callback(channel_id)
            else:
                callback(channel_id)
        except Exception as exc:
            logger.error(f"[巡查器] 回调执行异常 {channel_id[:12]}: {exc}")
    # ---- 内部倒计时管理 ----
    def _revoke_countdown(self, channel_id: str) -> bool:
        rec = self._pulse_table.get(channel_id)
        if rec and rec.countdown_handle:
            try:
                rec.countdown_handle.cancel()
                rec.countdown_handle = None
                return True
            except Exception as exc:
                logger.warning(f"[巡查器] 取消倒计时失败: {exc}")
        return False
    # ---- 暂停/恢复 ----
    def suspend_watch(self, channel_id: str) -> bool:
        """暂停某频道的静默监控"""
        rec = self._pulse_table.get(channel_id)
        if not rec:
            return False
        self._revoke_countdown(channel_id)
        rec.frozen = True
        logger.debug(f"[巡查器] {channel_id[:12]} 已暂停")
        return True
    def resume_watch(self, channel_id: str, override_minutes: Optional[int] = None) -> bool:
        """恢复某频道的静默监控"""
        rec = self._pulse_table.get(channel_id)
        if not rec:
            return False
        rec.frozen = False
        minutes = override_minutes if override_minutes is not None else rec.countdown_minutes
        if minutes <= 0:
            minutes = self._cp("default_minutes")
        self.note_activity(channel_id, idle_minutes=minutes)
        logger.debug(f"[巡查器] {channel_id[:12]} 已恢复")
        return True
    def disband_watch(self, channel_id: str) -> bool:
        """彻底移除某频道的监控"""
        if self._revoke_countdown(channel_id):
            self._pulse_table.pop(channel_id, None)
            self._counters["cancels"] += 1
            logger.debug(f"[巡查器] {channel_id[:12]} 已移除")
            return True
        if channel_id in self._pulse_table:
            self._pulse_table.pop(channel_id)
            self._counters["cancels"] += 1
            return True
        return False
    def disband_all(self) -> int:
        """移除所有频道的监控"""
        removed = 0
        for ch_id in list(self._pulse_table.keys()):
            if self.disband_watch(ch_id):
                removed += 1
        logger.info(f"[巡查器] 已移除 {removed} 个频道的监控")
        return removed
    # ---- 静默持续时间 ----
    def measure_silence_sec(self, channel_id: str) -> float:
        """获取指定频道的静默持续秒数"""
        rec = self._pulse_table.get(channel_id)
        if not rec or rec.latest_any_ts == 0.0:
            return 0.0
        return time.time() - rec.latest_any_ts
    # ---- 快速判定（无 LLM） ----
    def evaluate_stillness_quick(self, channel_id: str) -> bool:
        """
        快速静默判定
        综合考虑活跃人数对阈值的放大效应。
        """
        rec = self._ensure_record(channel_id)
        if rec.latest_any_ts == 0.0:
            return False
        elapsed = time.time() - rec.latest_any_ts
        base_sec = self._cp("fast_threshold_sec")
        user_factor = self._cp("active_user_factor")
        speaker_bonus = 1.0 + min(3.0, rec.distinct_speakers * user_factor)
        adjusted_threshold = max(60.0, base_sec * speaker_bonus)
        return elapsed >= adjusted_threshold
    # ---- LLM 辅助判定 ----
    async def evaluate_stillness_smart(
        self,
        channel_id: str,
        llm_caller: Optional[Callable] = None,
    ) -> bool:
        """
        智能静默判定
        优先尝试 LLM 判断是否应该主动发言，失败时回退到快速判定。
        """
        if llm_caller is None:
            return self.evaluate_stillness_quick(channel_id)
        rec = self._ensure_record(channel_id)
        if rec.latest_any_ts == 0.0:
            return False
        elapsed = self.measure_silence_sec(channel_id)
        snapshot = self.fetch_channel_snapshot(channel_id)
        try:
            prompt = (
                f"频道已静默 {elapsed:.0f} 秒。"
                f"最近有 {snapshot.get('distinct_speakers', 0)} 人参与，"
                f"共 {snapshot.get('total_msg_count', 0)} 条消息。"
                f"\n是否应该主动发言？回答 JSON: {{\"should_act\": true/false}}"
            )
            raw = await llm_caller(prompt)
            import json
            parsed = json.loads(raw)
            return bool(parsed.get("should_act", False))
        except Exception as exc:
            logger.debug(f"[巡查器] LLM 判定失败，回退快速模式: {exc}")
            return self.evaluate_stillness_quick(channel_id)
    # ---- 剩余时间查询 ----
    def remaining_countdown_sec(self, channel_id: str) -> Optional[float]:
        """查询当前剩余倒计时秒数"""
        rec = self._pulse_table.get(channel_id)
        if not rec or not rec.countdown_handle or rec.frozen:
            return None
        gone = time.time() - rec.countdown_reset_ts
        left = (rec.countdown_minutes * 60) - gone
        return max(0.0, left)
    # ---- 快照查询 ----
    def fetch_channel_snapshot(self, channel_id: str) -> Dict[str, Any]:
        """获取频道静默状态快照"""
        rec = self._pulse_table.get(channel_id)
        if not rec:
            return {"channel_id": channel_id, "tracked": False}
        remaining = self.remaining_countdown_sec(channel_id)
        return {
            "channel_id": channel_id,
            "tracked": True,
            "latest_any_ts": rec.latest_any_ts,
            "latest_bot_ts": rec.latest_bot_ts,
            "latest_human_ts": rec.latest_human_ts,
            "total_msg_count": rec.total_msg_count,
            "distinct_speakers": rec.distinct_speakers,
            "silence_sec": self.measure_silence_sec(channel_id),
            "countdown_minutes": rec.countdown_minutes,
            "frozen": rec.frozen,
            "remaining_sec": remaining,
            "triggered_tally": rec.triggered_tally,
        }
    # ---- 过期清理 ----
    def purge_stale_channels(self) -> int:
        """清理超过最大存活时长的频道记录"""
        max_age_sec = self._cp("stale_channel_hours") * 3600
        now = time.time()
        stale_ids = [
            ch_id for ch_id, rec in self._pulse_table.items()
            if rec.latest_any_ts > 0.0 and (now - rec.latest_any_ts) > max_age_sec
        ]
        for ch_id in stale_ids:
            self.disband_watch(ch_id)
        if stale_ids:
            logger.debug(f"[巡查器] 清理了 {len(stale_ids)} 个过期频道")
        return len(stale_ids)
    # ---- 全局统计 ----
    def tally_overview(self) -> Dict[str, Any]:
        """汇总统计信息"""
        active_count = sum(
            1 for rec in self._pulse_table.values()
            if rec.countdown_handle and not rec.frozen
        )
        frozen_count = sum(1 for rec in self._pulse_table.values() if rec.frozen)
        return {
            **self._counters,
            "total_channels": len(self._pulse_table),
            "active_channels": active_count,
            "frozen_channels": frozen_count,
        }


def get_quiet_monitor() -> QuietPeriodMonitor:
    """获取全局静默期巡查器实例"""
    return QuietPeriodMonitor.instance()
