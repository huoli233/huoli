import json
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config

logger = get_logger("activation_sentinel")


class SignalCategory(Enum):
    """信号分类"""
    TEMPORAL = "temporal"
    REACTIVE = "reactive"
    CONDITIONAL = "conditional"
    CALENDAR = "calendar"


class SignalWeight(Enum):
    """信号权重等级"""
    VITAL = 1
    ELEVATED = 2
    ORDINARY = 3
    MINOR = 4


@dataclass
class ConditionSpec:
    """触发条件描述"""
    spec_id: str = ""
    category: SignalCategory = SignalCategory.CONDITIONAL
    label: str = ""
    summary: str = ""
    weight: SignalWeight = SignalWeight.ORDINARY
    active: bool = True
    cooldown_sec: float = 0.0
    last_fired_ts: float = 0.0
    fire_tally: int = 0
    criteria: Dict[str, Any] = field(default_factory=dict)
    effect_params: Dict[str, Any] = field(default_factory=dict)
    extras: Dict[str, Any] = field(default_factory=dict)
    def is_ready(self) -> bool:
        """条件是否可执行（未禁用且冷却已过）"""
        if not self.active:
            return False
        return (time.time() - self.last_fired_ts) >= self.cooldown_sec
    def mark_fired(self) -> None:
        self.last_fired_ts = time.time()
        self.fire_tally += 1
    def to_dict(self) -> Dict[str, Any]:
        return {
            "spec_id": self.spec_id,
            "category": self.category.value,
            "label": self.label,
            "summary": self.summary,
            "weight": self.weight.value,
            "active": self.active,
            "cooldown_sec": self.cooldown_sec,
            "last_fired_ts": self.last_fired_ts,
            "fire_tally": self.fire_tally,
            "criteria": self.criteria,
            "effect_params": self.effect_params,
        }
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConditionSpec":
        return cls(
            spec_id=data.get("spec_id", ""),
            category=SignalCategory(data.get("category", "conditional")),
            label=data.get("label", ""),
            summary=data.get("summary", ""),
            weight=SignalWeight(data.get("weight", 3)),
            active=data.get("active", True),
            cooldown_sec=float(data.get("cooldown_sec", 300.0)),
            last_fired_ts=float(data.get("last_fired_ts", 0.0)),
            fire_tally=int(data.get("fire_tally", 0)),
            criteria=data.get("criteria", {}),
            effect_params=data.get("effect_params", {}),
            extras=data.get("extras", {}),
        )


@dataclass
class ImpulseCheckResult:
    """冲动因子检查结果"""
    factor_name: str = ""
    matched: bool = False
    bonus: float = 0.0
    detail: str = ""


@dataclass
class ActivationBlueprint:
    """激活调度蓝图"""
    urgency_level: int = 3
    defer_seconds: float = 30.0
    matched_factors: List[str] = field(default_factory=list)
    cumulative_bonus: float = 0.0


class ActivationSentinel:
    """
    激活哨兵
    管理所有触发条件的注册、分类和评估。
    支持四种信号类型的扫描：时间触发、事件触发、条件触发、日历触发。
    提供冲动因子评估和调度蓝图生成。
    """
    _solo: Optional["ActivationSentinel"] = None
    @classmethod
    def instance(cls) -> "ActivationSentinel":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        cls._solo = None
    def __init__(self):
        # 条件注册表
        self._registry: Dict[str, ConditionSpec] = {}
        # 分类索引
        self._category_index: Dict[SignalCategory, List[ConditionSpec]] = {
            cat: [] for cat in SignalCategory
        }
        # 配置缓存
        self._param_cache: Dict[str, Any] = {}
        self._param_ts: float = 0.0
        self._refresh_params()
        logger.info("[哨兵] 激活哨兵初始化完成")
    # ---- 配置 ----
    def _refresh_params(self) -> None:
        now = time.time()
        if now - self._param_ts < 60.0:
            return
        hub = get_core_config()
        thr = hub.trigger_thresholds_block()
        sched = hub.proactive_schedule_block()
        self._param_cache = {
            # 冲动因子权重
            "bonus_high_rapport": float(thr.get("high_rapport_bonus", 0.05)),
            "bonus_mood_surge": float(thr.get("mood_surge_bonus", 0.06)),
            "bonus_prolonged_quiet": float(thr.get("prolonged_quiet_bonus", 0.08)),
            "bonus_solitude": float(thr.get("solitude_bonus", 0.07)),
            "bonus_ennui": float(thr.get("ennui_bonus", 0.04)),
            # 冲动因子阈值
            "rapport_threshold": float(thr.get("rapport_activation_threshold", 35.0)),
            "mood_intensity_floor": float(thr.get("mood_intensity_floor", 0.55)),
            "prolonged_quiet_sec": float(thr.get("prolonged_quiet_seconds", 1200.0)),
            "solitude_floor": float(thr.get("solitude_accumulation_floor", 0.35)),
            "ennui_floor": float(thr.get("ennui_accumulation_floor", 0.40)),
            "unanswered_cap": int(thr.get("unanswered_trigger_count", 2)),
            # 调度参数
            "high_silence_sec": float(sched.get("high_priority_silence_seconds", 1800.0)),
            "mid_silence_sec": float(sched.get("mid_priority_silence_seconds", 900.0)),
            "delay_long": float(sched.get("delay_after_long_silence_seconds", 5.0)),
            "delay_mid": float(sched.get("delay_after_mid_silence_seconds", 15.0)),
            "delay_short": float(sched.get("delay_after_short_silence_seconds", 30.0)),
        }
        self._param_ts = now
    def _cp(self, key: str) -> Any:
        self._refresh_params()
        return self._param_cache[key]
    # ---- 条件注册/注销 ----
    def enroll_condition(self, spec: ConditionSpec) -> None:
        """注册一个触发条件"""
        self._registry[spec.spec_id] = spec
        bucket = self._category_index[spec.category]
        if spec not in bucket:
            bucket.append(spec)
            bucket.sort(key=lambda s: s.weight.value)
        logger.debug(f"[哨兵] 注册条件: {spec.spec_id} [{spec.category.value}]")
    def withdraw_condition(self, spec_id: str) -> bool:
        """注销一个触发条件"""
        spec = self._registry.pop(spec_id, None)
        if not spec:
            return False
        bucket = self._category_index.get(spec.category, [])
        if spec in bucket:
            bucket.remove(spec)
        return True
    def toggle_condition(self, spec_id: str, active: bool) -> bool:
        spec = self._registry.get(spec_id)
        if not spec:
            return False
        spec.active = active
        return True
    # ---- 时间信号扫描 ----
    async def scan_temporal_signals(
        self,
        channel_id: str,
        llm_caller: Optional[Callable] = None,
    ) -> List[ConditionSpec]:
        """扫描所有时间类型条件，返回应触发的列表"""
        hits: List[ConditionSpec] = []
        for spec in self._category_index[SignalCategory.TEMPORAL]:
            if not spec.is_ready():
                continue
            should_fire = await self._judge_temporal(spec, channel_id, llm_caller)
            if should_fire:
                spec.mark_fired()
                hits.append(spec)
        return hits
    async def _judge_temporal(
        self,
        spec: ConditionSpec,
        channel_id: str,
        llm_caller: Optional[Callable],
    ) -> bool:
        """判断时间条件是否满足（优先 LLM，回退规则）"""
        if llm_caller:
            try:
                prompt = (
                    f"触发条件: {spec.label}\n"
                    f"条件参数: {json.dumps(spec.criteria, ensure_ascii=False)}\n"
                    f"频道: {channel_id}\n"
                    f"已触发次数: {spec.fire_tally}\n"
                    f"请判断是否应该触发。回答 JSON: {{\"should_trigger\": true/false}}"
                )
                raw = await llm_caller(prompt)
                parsed = json.loads(raw)
                if bool(parsed.get("should_trigger", False)):
                    return True
            except Exception as exc:
                logger.debug(f"[哨兵] TEMPORAL LLM 判定失败: {exc}")
        return self._fallback_temporal(spec, channel_id)
    def _fallback_temporal(self, spec: ConditionSpec, channel_id: str) -> bool:
        """时间条件规则回退"""
        criteria = dict(spec.criteria or {})
        target_ch = criteria.get("channel_id")
        target_list = criteria.get("channel_ids")
        if target_ch and str(target_ch) != str(channel_id):
            return False
        if isinstance(target_list, list) and target_list:
            if str(channel_id) not in {str(c) for c in target_list}:
                return False
        min_quiet = float(criteria.get("min_silence_seconds", 0.0) or 0.0)
        if min_quiet > 0:
            from src.chat.proactive.silence_watcher import get_quiet_monitor
            actual = get_quiet_monitor().measure_silence_sec(channel_id)
            if actual < min_quiet:
                return False
        return bool(target_ch or target_list or min_quiet > 0)
    # ---- 事件信号扫描 ----
    async def scan_reactive_signals(
        self,
        event_tag: str,
        event_payload: Dict[str, Any],
        llm_caller: Optional[Callable] = None,
    ) -> List[ConditionSpec]:
        """扫描所有事件类型条件"""
        hits: List[ConditionSpec] = []
        for spec in self._category_index[SignalCategory.REACTIVE]:
            if not spec.is_ready():
                continue
            should_fire = await self._judge_reactive(spec, event_tag, event_payload, llm_caller)
            if should_fire:
                spec.mark_fired()
                hits.append(spec)
        return hits
    async def _judge_reactive(
        self,
        spec: ConditionSpec,
        event_tag: str,
        event_payload: Dict[str, Any],
        llm_caller: Optional[Callable],
    ) -> bool:
        if llm_caller:
            try:
                prompt = (
                    f"事件: {event_tag}\n"
                    f"钩子: {spec.label}\n"
                    f"匹配条件: {json.dumps(spec.criteria, ensure_ascii=False)}\n"
                    f"事件数据: {json.dumps(event_payload, ensure_ascii=False, default=str)[:300]}\n"
                    f"请判断是否应该触发。回答 JSON: {{\"should_trigger\": true/false}}"
                )
                raw = await llm_caller(prompt)
                parsed = json.loads(raw)
                if bool(parsed.get("should_trigger", False)):
                    return True
            except Exception as exc:
                logger.debug(f"[哨兵] REACTIVE LLM 判定失败: {exc}")
        return self._fallback_reactive(spec, event_tag, event_payload)
    def _fallback_reactive(self, spec: ConditionSpec, event_tag: str, event_payload: Dict[str, Any]) -> bool:
        """事件条件规则回退"""
        criteria = dict(spec.criteria or {})
        allowed_tags = criteria.get("event_types")
        single_tag = criteria.get("event_type")
        if isinstance(allowed_tags, list) and allowed_tags:
            if event_tag not in {str(t) for t in allowed_tags}:
                return False
        elif single_tag is not None and str(single_tag) != str(event_tag):
            return False
        must_have_keys = criteria.get("required_keys")
        if isinstance(must_have_keys, list):
            for k in must_have_keys:
                if str(k) not in event_payload:
                    return False
        reserved_keys = {"event_type", "event_types", "required_keys"}
        for k, expected in criteria.items():
            if k in reserved_keys:
                continue
            if k not in event_payload:
                return False
            if event_payload.get(k) != expected:
                return False
        return bool(allowed_tags or single_tag is not None or must_have_keys or len(criteria) > 0)
    # ---- 日历信号扫描 ----
    async def scan_calendar_signals(
        self,
        current_hour: Optional[int] = None,
        llm_caller: Optional[Callable] = None,
    ) -> List[ConditionSpec]:
        """扫描所有日历/定时条件"""
        if current_hour is None:
            current_hour = time.localtime().tm_hour
        hits: List[ConditionSpec] = []
        for spec in self._category_index[SignalCategory.CALENDAR]:
            if not spec.is_ready():
                continue
            should_fire = await self._judge_calendar(spec, current_hour, llm_caller)
            if should_fire:
                spec.mark_fired()
                hits.append(spec)
        return hits
    async def _judge_calendar(
        self,
        spec: ConditionSpec,
        current_hour: int,
        llm_caller: Optional[Callable],
    ) -> bool:
        if llm_caller:
            try:
                prompt = (
                    f"日历条件: {spec.label}\n"
                    f"当前小时: {current_hour}\n"
                    f"条件参数: {json.dumps(spec.criteria, ensure_ascii=False)}\n"
                    f"请判断是否应该触发。回答 JSON: {{\"should_trigger\": true/false}}"
                )
                raw = await llm_caller(prompt)
                parsed = json.loads(raw)
                if bool(parsed.get("should_trigger", False)):
                    return True
            except Exception as exc:
                logger.debug(f"[哨兵] CALENDAR LLM 判定失败: {exc}")
        return self._fallback_calendar(spec, current_hour)
    def _fallback_calendar(self, spec: ConditionSpec, current_hour: int) -> bool:
        """日历条件规则回退"""
        criteria = dict(spec.criteria or {})
        allowed_hours = criteria.get("hours")
        single_hour = criteria.get("hour")
        if isinstance(allowed_hours, list) and allowed_hours:
            if current_hour not in {int(h) for h in allowed_hours}:
                return False
        elif single_hour is not None and int(single_hour) != int(current_hour):
            return False
        weekdays = criteria.get("weekdays")
        single_weekday = criteria.get("weekday")
        now_weekday = time.localtime().tm_wday
        if isinstance(weekdays, list) and weekdays:
            if now_weekday not in {int(w) for w in weekdays}:
                return False
        elif single_weekday is not None and int(single_weekday) != int(now_weekday):
            return False
        return bool(allowed_hours or single_hour is not None or weekdays or single_weekday is not None)
    # ---- 冲动因子评估 ----
    def gauge_engagement_impulse(
        self,
        silence_sec: float,
        rapport_value: Optional[float],
        emotion_label: str,
        emotion_intensity: float,
        ennui_accumulation: float,
        solitude_accumulation: float,
        unanswered_streak: int,
    ) -> List[ImpulseCheckResult]:
        """
        评估多维冲动因子
        综合好感度、情绪、静默、孤独感、无聊值等指标。
        """
        emo = (emotion_label or "neutral").lower()
        inten = max(0.0, min(1.0, float(emotion_intensity)))
        ennui = max(0.0, min(1.0, float(ennui_accumulation)))
        solitude = max(0.0, min(1.0, float(solitude_accumulation)))
        streak = max(0, int(unanswered_streak))
        results: List[ImpulseCheckResult] = []
        # 好感度因子
        high_rapport = rapport_value is not None and float(rapport_value) >= self._cp("rapport_threshold")
        results.append(ImpulseCheckResult(
            factor_name="high_rapport",
            matched=bool(high_rapport),
            bonus=self._cp("bonus_high_rapport") if high_rapport else 0.0,
            detail=f"rapport={rapport_value}" if high_rapport else "",
        ))
        # 情绪驱动因子
        mood_surge = emo in {"excited", "curious"} and inten >= self._cp("mood_intensity_floor")
        results.append(ImpulseCheckResult(
            factor_name="mood_surge",
            matched=bool(mood_surge),
            bonus=self._cp("bonus_mood_surge") if mood_surge else 0.0,
            detail=f"{emo}:{inten:.2f}" if mood_surge else "",
        ))
        # 长时间静默因子
        prolonged = float(silence_sec) >= self._cp("prolonged_quiet_sec")
        results.append(ImpulseCheckResult(
            factor_name="prolonged_quiet",
            matched=bool(prolonged),
            bonus=self._cp("bonus_prolonged_quiet") if prolonged else 0.0,
            detail=f"silence={silence_sec:.1f}s" if prolonged else "",
        ))
        # 孤独驱动因子
        lonely = solitude >= self._cp("solitude_floor") or streak >= self._cp("unanswered_cap")
        results.append(ImpulseCheckResult(
            factor_name="solitude_driven",
            matched=bool(lonely),
            bonus=self._cp("bonus_solitude") if lonely else 0.0,
            detail=f"solitude={solitude:.2f},streak={streak}" if lonely else "",
        ))
        # 无聊驱动因子
        bored = ennui >= self._cp("ennui_floor")
        results.append(ImpulseCheckResult(
            factor_name="ennui_driven",
            matched=bool(bored),
            bonus=self._cp("bonus_ennui") if bored else 0.0,
            detail=f"ennui={ennui:.2f}" if bored else "",
        ))
        return results
    # ---- 调度蓝图 ----
    def draft_activation_plan(
        self,
        silence_sec: float,
        impulse_factors: Optional[List[ImpulseCheckResult]] = None,
    ) -> ActivationBlueprint:
        """
        根据静默时长和冲动因子结果，生成激活调度蓝图。
        包含紧急度等级和建议延迟。
        """
        active_factors = [f for f in (impulse_factors or []) if f.matched]
        total_bonus = sum(f.bonus for f in active_factors)
        urgency = self._compute_urgency(silence_sec)
        defer = self._compute_defer(silence_sec)
        # 因子越多，延迟越短，紧急度越高
        if active_factors:
            shrink_ratio = min(0.7, total_bonus)
            defer = max(1.0, defer * (1.0 - shrink_ratio))
            if len(active_factors) >= 2:
                urgency = max(1, urgency - 1)
        return ActivationBlueprint(
            urgency_level=urgency,
            defer_seconds=round(defer, 2),
            matched_factors=[f.factor_name for f in active_factors],
            cumulative_bonus=round(total_bonus, 4),
        )
    def _compute_urgency(self, silence_sec: float) -> int:
        if silence_sec > self._cp("high_silence_sec"):
            return 1
        if silence_sec > self._cp("mid_silence_sec"):
            return 2
        return 3
    def _compute_defer(self, silence_sec: float) -> float:
        if silence_sec > self._cp("high_silence_sec"):
            return self._cp("delay_long")
        if silence_sec > self._cp("mid_silence_sec"):
            return self._cp("delay_mid")
        return self._cp("delay_short")
    # ---- 消息装饰钩子转发 ----
    async def relay_decorating_hooks(
        self,
        stream_id: str,
        content: str,
        platform: str = "qq",
    ) -> str:
        """
        转发消息到装饰钩子链
        使主动消息也能被其他插件（如 TTS、尾巴）处理。
        """
        try:
            from src.plugin_system.core.events_manager import events_manager
            from src.plugin_system.base.component_types import EventType
            continue_flag, modified = await events_manager.handle_mai_events(
                EventType.POST_SEND_PRE_PROCESS, stream_id=stream_id
            )
            if not continue_flag:
                logger.debug(f"[哨兵] 消息被插件取消: {stream_id[:8]}")
                return ""
            if modified and hasattr(modified, "_modify_flags") and modified._modify_flags.modify_plain_text:
                return modified.plain_text
            return content
        except Exception as exc:
            logger.debug(f"[哨兵] 装饰钩子转发跳过: {exc}")
            return content
    async def process_outgoing_message(
        self,
        stream_id: str,
        content: str,
        user_id: str = "",
    ) -> Optional[str]:
        """处理主动发出的消息（过装饰钩子后返回）"""
        try:
            processed = await self.relay_decorating_hooks(stream_id, content)
            if not processed:
                return None
            return processed
        except Exception as exc:
            logger.error(f"[哨兵] 外发消息处理失败: {exc}")
            return content
    # ---- 查询 ----
    def lookup_condition(self, spec_id: str) -> Optional[ConditionSpec]:
        return self._registry.get(spec_id)
    def list_all_conditions(self) -> List[ConditionSpec]:
        return list(self._registry.values())
    def list_active_conditions(self) -> List[ConditionSpec]:
        return [s for s in self._registry.values() if s.active]
    def summarize(self) -> Dict[str, Any]:
        return {
            "total_conditions": len(self._registry),
            "active_conditions": len(self.list_active_conditions()),
            "by_category": {
                cat.value: len(specs)
                for cat, specs in self._category_index.items()
            },
            "total_fires": sum(s.fire_tally for s in self._registry.values()),
        }


def get_activation_sentinel() -> ActivationSentinel:
    """获取全局激活哨兵实例"""
    return ActivationSentinel.instance()
