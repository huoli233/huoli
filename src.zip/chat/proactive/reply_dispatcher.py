import random
import re
from typing import Any, Dict, List, Optional, Tuple
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config
from src.common.data_models.proactive_models import (
    JournalKind, MindJournalEntry,
)

logger = get_logger("reply_dispatch")

# 情境标签 → 人类可读描述
_OCCASION_LABELS: Dict[str, str] = {
    "fresh_incoming": "用户发来了新消息",
    "timely_return": "用户在期待的时间内回复了",
    "belated_return": "用户超出预期时间才回复",
    "chase_timeout": "等待超时，你决定追问",
    "self_initiative": "你主动发起对话",
}

# 用于清除 LLM 输出中常见废话前缀
_NOISE_PREFIXES = [
    "你说：", "你说:", "回复：", "回复:",
    "我说：", "我说:", "消息：", "消息:",
    "回复内容：", "回复内容:", "我的回复：",
    "我的回复:", "输出：", "输出:",
]


async def craft_response(
    memoir: Any,
    speaker_name: str,
    monologue: str,
    occasion: str = "fresh_incoming",
    extras: Optional[Dict[str, Any]] = None,
) -> Tuple[bool, str]:
    """
    从思考独白生成一条自然语言回复

    Args:
        memoir: DialogueMemoir 实例
        speaker_name: 对话对象昵称
        monologue: 规划器产出的内心独白
        occasion: 情境标签 (fresh_incoming / timely_return / belated_return / chase_timeout / self_initiative)
        extras: 补充参数（关系描述、人格提示等）

    Returns:
        (是否成功, 回复文本)
    """
    extras = extras or {}
    try:
        prompt = _compose_dialogue_prompt(
            memoir=memoir,
            speaker_name=speaker_name,
            monologue=monologue,
            occasion=occasion,
            extras=extras,
        )
        raw = await _invoke_language_model(prompt)
        if not raw:
            logger.error("[回复分发] 模型响应为空")
            return False, "(回复生成失败)"
        polished = _polish_output(raw)
        logger.info(f"[回复分发] {polished[:60]}...")
        return True, polished
    except Exception as exc:
        logger.error(f"[回复分发] 生成异常: {exc}")
        return False, "(回复生成失败)"


async def craft_initiative_message(
    plan_data: Dict[str, Any],
    scene_info: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    主动发起场景的回复生成

    如果 plan_data 的 actions 中已有内容则直接采用；
    否则调用 LLM 生成，失败时返回预设兜底。
    """
    scene_info = scene_info or {}
    try:
        if not plan_data or not plan_data.get("success", False):
            return {"success": False, "reason": "invalid_plan"}
        # 检查 plan 里是否已经带了文本
        actions = plan_data.get("actions", [])
        for act in actions:
            if isinstance(act, dict) and act.get("type") in ("respond", "miao_reply"):
                existing = act.get("content", "").strip()
                if existing:
                    return {"success": True, "reply_text": existing, "source": "plan_content"}
        # 需要 LLM 生成
        prompt = _compose_initiative_prompt(plan_data, scene_info)
        raw = await _invoke_language_model(prompt)
        if not raw or len(raw.strip()) < 2:
            logger.warning("[回复分发] 主动消息LLM响应不足")
            return _fallback_utterance(scene_info)
        cleaned = _polish_output(raw)
        if not cleaned or len(cleaned.strip()) < 2:
            return _fallback_utterance(scene_info)
        return {"success": True, "reply_text": cleaned, "source": "llm_generated"}
    except Exception as exc:
        logger.error(f"[回复分发] 主动消息异常: {exc}")
        return _fallback_utterance(scene_info)


# ---- 提示词构建 ----
def _compose_dialogue_prompt(
    memoir: Any,
    speaker_name: str,
    monologue: str,
    occasion: str,
    extras: Dict[str, Any],
) -> str:
    """构建常规对话回复提示词"""
    # 拼装对话记录片段
    history_block = "(暂无对话记录)"
    if memoir and hasattr(memoir, "latest_entries"):
        try:
            recent = memoir.latest_entries(5)
            history_block = _render_condensed_history(recent, speaker_name)
        except Exception:
            history_block = "(暂无对话记录)"
    # 情境描述
    occasion_desc = _describe_occasion(occasion, extras)
    # 可选：关系补充
    relation_hint = ""
    if extras.get("relation_summary"):
        relation_hint = f"\n对方与你的关系：{extras['relation_summary']}\n请据此调整语气。"
    # 可选：人格补充
    persona_hint = ""
    if extras.get("persona_name"):
        persona_hint = f"\n你当前的人格特征：{extras['persona_name']}"
        if extras.get("persona_tone"):
            persona_hint += f"，语调：{extras['persona_tone']}"
    prompt = f"""你正在和 {speaker_name} 聊天。

{history_block}

当前情况：{occasion_desc}{relation_hint}{persona_hint}

你的内心想法：{monologue}

请根据以上信息生成一条自然的回复。

要求：
- 直接输出回复文本，不加额外说明或前缀
- 语气要自然、口语化
- 内容要符合你的内心想法
- 如果场景合适可以使用表情符号

直接输出："""
    return prompt


def _compose_initiative_prompt(
    plan_data: Dict[str, Any],
    scene_info: Dict[str, Any],
) -> str:
    """构建主动发起回复提示词"""
    thought = plan_data.get("thought", plan_data.get("inner_thought", ""))
    silence_sec = scene_info.get("silence_duration", 0)
    if silence_sec > 3600:
        duration_desc = f"{silence_sec / 3600:.1f} 小时"
    elif silence_sec > 60:
        duration_desc = f"{int(silence_sec / 60)} 分钟"
    else:
        duration_desc = f"{int(silence_sec)} 秒"
    persona_block = ""
    persona = scene_info.get("current_persona", {})
    if persona.get("name"):
        persona_block = f"你是 {persona['name']}"
        if persona.get("tone"):
            persona_block += f"，{persona['tone']}"
    topics_block = ""
    recent_topics = scene_info.get("recent_topics", "")
    if recent_topics:
        topics_block = f"你们最近聊过：{recent_topics}"
    prompt = f"""你和对方已经 {duration_desc} 没聊天了。
{persona_block}

你的内心想法：{thought}

{topics_block}

请生成一条自然的主动消息。

要求：
- 直接输出消息内容
- 语气要自然，不要太刻意
- 内容可以是打招呼、分享事情、或延续之前的话题
- 一两句话即可，不要太长

直接输出："""
    return prompt


def _render_condensed_history(
    entries: List[MindJournalEntry],
    speaker_name: str,
) -> str:
    """将心理日志条目渲染为简短对话片段"""
    if not entries:
        return "(这是你们的第一段对话)"
    fragments: List[str] = ["近期对话："]
    for entry in entries[-3:]:
        if entry.kind == JournalKind.USER_UTTERANCE:
            snippet = entry.body_text[:50]
            if len(entry.body_text) > 50:
                snippet += "..."
            fragments.append(f"  {speaker_name}: {snippet}")
        elif entry.kind == JournalKind.BOT_VERDICT:
            for act in entry.action_list:
                if isinstance(act, dict) and act.get("type") in ("respond", "miao_reply"):
                    content = act.get("content", "")[:50]
                    if len(act.get("content", "")) > 50:
                        content += "..."
                    fragments.append(f"  你: {content}")
                    break
    if len(fragments) <= 1:
        return "(暂无有效对话记录)"
    return "\n".join(fragments)


def _describe_occasion(occasion: str, extras: Dict[str, Any]) -> str:
    """将情境标签转化为自然语言"""
    return _OCCASION_LABELS.get(occasion, occasion)


# ---- LLM 调用 ----
async def _invoke_language_model(
    prompt: str,
    ceiling: int = 500,
) -> Optional[str]:
    """调用语言模型生成回复"""
    try:
        from src.llm_models.utils_model import LLMRequest
        from src.config.config import model_config
        req = LLMRequest(model_config.focus_chat, request_type="reply_dispatcher")
        text, _ = await req.generate_response_async(prompt, max_tokens=ceiling)
        return text or None
    except Exception as exc:
        logger.error(f"[回复分发] LLM调用失败: {exc}")
        return None


# ---- 文本清洗 ----
def _polish_output(raw: str) -> str:
    """清洗 LLM 输出：去除 markdown、引号、废话前缀、重复标点"""
    text = raw.strip()
    # 去除 markdown 代码块
    if text.startswith("```") and text.endswith("```"):
        lines = text.split("\n")
        if len(lines) >= 3:
            text = "\n".join(lines[1:-1]).strip()
    # 去除整体引号包裹
    if len(text) >= 2:
        if (text[0] == '"' and text[-1] == '"') or (text[0] == "'" and text[-1] == "'"):
            text = text[1:-1].strip()
    # 去除常见废话前缀
    for prefix in _NOISE_PREFIXES:
        if text.startswith(prefix):
            text = text[len(prefix):].strip()
            break
    # 去除连续重复标点
    text = re.sub(r'([。！？])\1+', r'\1', text)
    return text


def _fallback_utterance(scene_info: Dict[str, Any]) -> Dict[str, Any]:
    """兜底回复工厂"""
    persona = scene_info.get("current_persona", {})
    tone = persona.get("tone", "")
    if "温柔" in tone or "gentle" in tone.lower():
        pool = ["在吗~", "好久没聊了呢", "最近怎么样呀"]
    elif "活泼" in tone or "energetic" in tone.lower():
        pool = ["嘿！", "你在干嘛呀", "好无聊啊"]
    else:
        pool = ["在吗", "好久没聊了", "最近还好吗"]
    chosen = random.choice(pool)
    return {"success": True, "reply_text": chosen, "source": "fallback"}
