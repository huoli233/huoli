import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config
from src.common.data_models.proactive_models import (
    ThinkOutcome, MindJournalEntry, JournalKind,
)

logger = get_logger("intention_forge")


@dataclass
class ReadinessGauge:
    """多维就绪度评分（由 LLM 或规则产出）"""
    spirit_score: float = 5.0
    stamina_score: float = 5.0
    eagerness_score: float = 5.0
    quiet_fitness: float = 5.0
    topic_readiness: float = 5.0
    shield_integrity: float = 10.0
    timing_score: float = 5.0
    audience_openness: float = 5.0
    recheck_delay_sec: int = 0
    certainty: float = 0.0
    custom_weights: Optional[Dict[str, float]] = None
    def overall(self, scope: str = "group") -> float:
        """计算加权综合分（0~1）"""
        if self.custom_weights:
            w = self.custom_weights
        elif scope == "private":
            w = {
                "spirit_score": 0.20, "stamina_score": 0.15, "eagerness_score": 0.25,
                "quiet_fitness": 0.10, "topic_readiness": 0.05,
                "timing_score": 0.10, "audience_openness": 0.15,
            }
        else:
            w = {
                "spirit_score": 0.25, "stamina_score": 0.20, "eagerness_score": 0.20,
                "quiet_fitness": 0.15, "topic_readiness": 0.10,
                "shield_integrity": 0.05, "timing_score": 0.05,
            }
        total = sum(getattr(self, k, 5.0) * v for k, v in w.items())
        return total / 10.0
    def audience_summary(self, user_state: Dict) -> Dict:
        """获取受众状态摘要"""
        return {
            "favor": user_state.get("favor", user_state.get("affection", 0)),
            "annoyance": user_state.get("annoyance", 0),
            "trauma": user_state.get("trauma", user_state.get("trauma_score", 0)),
            "audience_openness": self.audience_openness,
            "shield_active": self.shield_integrity < 5.0,
            "spirit_score": self.spirit_score,
            "stamina_score": self.stamina_score,
        }


def _estimate_audience_openness(user_state: Dict, context_info: Dict) -> float:
    """根据好感度和烦躁度估算受众接受程度（0-10）"""
    baseline = 5.0
    favor = user_state.get("favor", user_state.get("affection", 0))
    annoyance = user_state.get("annoyance", 0)
    favor_shift = favor / 50.0
    annoyance_shift = -annoyance / 33.3
    return max(0.0, min(10.0, baseline + favor_shift + annoyance_shift))


class IntentionForge:
    """
    意图锻造器
    根据会话上下文和评分系统，构建提示词并调用 LLM 生成行为蓝图。
    支持对话规划和主动发起两种模式。
    """
    _solo: Optional["IntentionForge"] = None
    @classmethod
    def instance(cls) -> "IntentionForge":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        cls._solo = None
    def __init__(self):
        self._param_cache: Dict[str, Any] = {}
        self._param_ts: float = 0.0
        self._refresh_params()
        self._metrics = {
            "total_forges": 0,
            "ok_forges": 0,
            "fail_forges": 0,
            "llm_calls": 0,
        }
    # ---- 配置 ----
    def _refresh_params(self) -> None:
        now = time.time()
        if now - self._param_ts < 60.0:
            return
        hub = get_core_config()
        sched = hub.proactive_schedule_block()
        self._param_cache = {
            "max_llm_tokens": int(sched.get("planner_max_tokens", 1000)),
        }
        self._param_ts = now
    # ---- 对话规划入口 ----
    async def forge_blueprint(
        self,
        session: Any,
        speaker_name: str,
        occasion: str = "new_message",
        available_actions: Optional[Dict] = None,
        addon_params: Optional[Dict] = None,
    ) -> ThinkOutcome:
        """
        生成对话行动蓝图

        参数:
            session: 会话对象（DialogueMemoir 或兼容对象）
            speaker_name: 用户名称
            occasion: 情境类型（new_message / reply_in_time / reply_late / timeout / proactive）
            available_actions: 可用行为字典
            addon_params: 额外参数

        返回:
            ThinkOutcome 对象
        """
        self._metrics["total_forges"] += 1
        try:
            prompt = self._assemble_blueprint_prompt(
                session, speaker_name, occasion, available_actions, addon_params,
            )
            raw = await self._invoke_llm(prompt)
            self._metrics["llm_calls"] += 1
            if not raw:
                logger.error("[锻造器] LLM 响应空白")
                self._metrics["fail_forges"] += 1
                return ThinkOutcome.make_fallback("LLM 响应空白")
            logger.debug(f"[锻造器] LLM 原始输出:\n{raw[:200]}...")
            result = self._distill_blueprint_response(raw)
            self._metrics["ok_forges"] += 1
            return result
        except Exception as exc:
            logger.error(f"[锻造器] 蓝图锻造失败: {exc}")
            self._metrics["fail_forges"] += 1
            return ThinkOutcome.make_fallback(str(exc))
    # ---- 主动发起规划 ----
    async def forge_initiative_blueprint(
        self,
        channel_id: str,
        occasion_desc: str,
        context_info: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """
        为主动发起场景生成行动蓝图

        参数:
            channel_id: 频道ID
            occasion_desc: 触发描述
            context_info: 上下文（情感、人格、用户状态等）

        返回:
            蓝图字典（含 success / thought / scores / actions 等）
        """
        context_info = context_info or {}
        scope = context_info.get("channel_type", "group")
        # 私聊走专用分支
        if scope == "private":
            return await self._forge_private_initiative(channel_id, occasion_desc, context_info)
        # 群聊走完整流程
        return await self._forge_group_initiative(channel_id, occasion_desc, context_info)
    # ---- 私聊主动 ----
    async def _forge_private_initiative(
        self,
        channel_id: str,
        occasion_desc: str,
        ctx: Dict,
    ) -> Dict[str, Any]:
        emotion_info = ctx.get("emotion_state", {})
        user_info = ctx.get("user_state", {})
        favor = user_info.get("favor", user_info.get("affection", 0))
        annoyance = user_info.get("annoyance", 0)
        trauma = user_info.get("trauma", user_info.get("trauma_score", 0))
        avg_mood = emotion_info.get("average_mood_score", 0.5)
        stamina = emotion_info.get("energy", 50)
        shield_on = emotion_info.get("global_shield_active", False)
        logger.info(
            f"[锻造器-私聊] 用户特征 | 好感={favor} 烦躁={annoyance} 创伤={trauma:.1f} "
            f"心情={avg_mood:.2f} 体力={stamina} 盾={'开' if shield_on else '关'}"
        )
        ctx["audience_openness"] = _estimate_audience_openness(user_info, ctx)
        prompt = self._assemble_private_initiative_prompt(occasion_desc, ctx)
        raw = await self._invoke_llm(prompt)
        if not raw:
            logger.error("[锻造器-私聊] LLM 空响应")
            return {"success": False, "reason": "llm_empty", "recheck_delay_sec": 600}
        parsed = self._distill_initiative_response(raw, ctx)
        # 生成评分
        scores_data = parsed.get("scores", {})
        recheck = parsed.get("recheck_delay_sec", 600)
        certainty = parsed.get("certainty", 0.5)
        if scores_data:
            gauge = ReadinessGauge(
                spirit_score=scores_data.get("spirit_score", 5.0),
                stamina_score=scores_data.get("stamina_score", 5.0),
                eagerness_score=scores_data.get("eagerness_score", 5.0),
                quiet_fitness=scores_data.get("quiet_fitness", 5.0),
                topic_readiness=scores_data.get("topic_readiness", 5.0),
                shield_integrity=10.0 if not shield_on else 0.0,
                timing_score=scores_data.get("timing_score", 5.0),
                audience_openness=scores_data.get("audience_openness", ctx["audience_openness"]),
                recheck_delay_sec=recheck,
                certainty=certainty,
            )
            parsed["overall_score"] = gauge.overall("private")
            logger.info(
                f"[锻造器-私聊] 就绪度 | 综合={parsed['overall_score']:.2f} "
                f"确信={certainty:.2f} 下次={recheck}s"
            )
        parsed["recheck_delay_sec"] = max(60, min(recheck, 86400))
        parsed["certainty"] = certainty
        return parsed
    # ---- 群聊主动 ----
    async def _forge_group_initiative(
        self,
        channel_id: str,
        occasion_desc: str,
        ctx: Dict,
    ) -> Dict[str, Any]:
        emotion_info = ctx.get("emotion_state", {})
        avg_mood = emotion_info.get("average_mood_score", 0.5)
        stamina = ctx.get("energy", 50)
        shield_on = emotion_info.get("global_shield_active", False)
        silence_sec = ctx.get("silence_duration", 0)
        silence_hr = silence_sec / 3600
        logger.info(
            f"[锻造器-群聊] {channel_id[:8]} | 心情={avg_mood:.2f} 体力={stamina} "
            f"盾={'开' if shield_on else '关'} 静默={silence_sec/60:.0f}分钟"
        )
        # 前置过滤
        if shield_on:
            return {"success": False, "reason": "shield_active", "skipped": True}
        if avg_mood < 0.3:
            return {"success": False, "reason": f"心情低迷({avg_mood:.2f})", "skipped": True}
        if stamina < 30:
            return {"success": False, "reason": f"体力不足({stamina})", "skipped": True}
        if silence_sec < 60:
            return {"success": False, "reason": "刚发过言", "skipped": True}
        if silence_hr < 0.5 and avg_mood < 0.7:
            return {"success": False, "reason": "静默太短且心情一般", "skipped": True}
        # 推断行为策略
        persona_info = ctx.get("current_persona", {})
        approach = self._deduce_approach_style(emotion_info, persona_info, silence_sec)
        enriched_desc = self._enrich_occasion(occasion_desc, ctx, approach)
        raw = await self._invoke_llm(self._assemble_group_initiative_prompt(enriched_desc, ctx))
        if not raw:
            return {"success": False, "reason": "llm_empty"}
        plan = self._distill_initiative_response(raw, ctx)
        if plan.get("skipped") or not plan.get("success"):
            logger.info(f"[锻造器-群聊] {channel_id[:8]} LLM 决定不主动: {plan.get('reason', '')}")
            return plan
        plan = self._tune_plan_by_approach(plan, approach, ctx)
        logger.info(f"[锻造器-群聊] {channel_id[:8]} 决定主动 | 策略={approach}")
        return plan
    # ---- 策略推断 ----
    def _deduce_approach_style(
        self,
        emotion_info: Dict,
        persona_info: Dict,
        silence_sec: float,
    ) -> str:
        avg_mood = emotion_info.get("average_mood_score", 0.5)
        shield_on = emotion_info.get("global_shield_active", False)
        tone = (persona_info.get("tone", "") or "").lower()
        silence_hr = silence_sec / 3600
        if shield_on:
            return "guarded"
        if silence_hr > 2 and avg_mood < 0.3:
            return "soft_nudge"
        if silence_hr < 1 and avg_mood > 0.7:
            return "upbeat_chat"
        tone_map = {
            "活泼": "spirited", "开朗": "spirited", "热情": "spirited",
            "温和": "cordial", "友好": "cordial",
            "冷静": "cerebral", "理性": "cerebral",
        }
        for keyword, style in tone_map.items():
            if keyword in tone:
                return style
        return "neutral"
    def _enrich_occasion(self, base: str, ctx: Dict, approach: str) -> str:
        guide_map = {
            "guarded": "当前处于保护状态，需要谨慎处理。",
            "soft_nudge": "需要温和安抚，可能需要安慰或鼓励。",
            "upbeat_chat": "适合轻松快乐的聊天，可以分享有趣的事情。",
            "spirited": "可以更加活跃和充满能量地互动。",
            "cordial": "保持友好温和的气氛。",
            "cerebral": "可以分享有趣的知识或观点。",
            "neutral": "保持平衡，根据情况灵活处理。",
        }
        parts = [base, "", guide_map.get(approach, "")]
        persona = ctx.get("current_persona", {})
        if persona.get("name"):
            line = f"当前人格: {persona['name']}"
            if persona.get("tone"):
                line += f"（{persona['tone']}语调）"
            parts.append(line)
        topics = ctx.get("recent_topics", "")
        if isinstance(topics, str) and topics.strip():
            parts.append(f"近期话题:\n{topics[:200]}")
        return "\n".join(parts)
    def _tune_plan_by_approach(self, plan: Dict, approach: str, ctx: Dict) -> Dict:
        wait_map = {
            "guarded": 1200, "soft_nudge": 900, "upbeat_chat": 300,
            "spirited": 180, "cordial": 600, "cerebral": 900, "neutral": 600,
        }
        if approach in wait_map:
            plan["max_wait_seconds"] = wait_map[approach]
        return plan
    # ---- 提示词组装 ----
    def _assemble_blueprint_prompt(
        self,
        session: Any,
        speaker_name: str,
        occasion: str,
        actions: Optional[Dict],
        addon: Optional[Dict],
    ) -> str:
        addon = addon or {}
        history_text = self._render_recent_dialogue(session, speaker_name)
        actions_text = self._render_action_menu(actions)
        occasion_text = self._render_occasion_context(session, occasion, addon)
        return (
            f"你是一个聊天机器人，正在与 {speaker_name} 对话。\n\n"
            f"{history_text}\n\n"
            f"{occasion_text}\n\n"
            f"可用的行为：\n{actions_text}\n\n"
            f"请分析当前情况，决定下一步行动，并直接生成回复内容。\n\n"
            f"回复格式（JSON）：\n"
            f'{{"thought": "你的内心想法", '
            f'"actions": [{{"type": "respond", "content": "回复内容"}}], '
            f'"expected_reaction": "你期待对方的回应", '
            f'"max_wait_seconds": 300, '
            f'"mood": "当前心情"}}\n\n'
            f"注意：\n"
            f"- thought 是内心独白，真实自然\n"
            f"- actions 列表中 respond 的 content 是完整回复\n"
            f"- 如果不回复，使用 {{\"type\": \"idle\"}}\n"
            f"请只输出 JSON："
        )
    def _render_recent_dialogue(self, session: Any, speaker_name: str) -> str:
        if not session:
            return "（暂无对话历史）"
        try:
            entries = session.latest_entries(8) if hasattr(session, "latest_entries") else []
        except Exception:
            entries = []
        if not entries:
            return "（这是你们的第一次对话）"
        lines = ["最近的对话："]
        for ent in entries:
            kind = getattr(ent, "kind", None)
            if kind == JournalKind.USER_SPEAK:
                text = getattr(ent, "text_body", "")[:100]
                name = getattr(ent, "author_name", speaker_name)
                lines.append(f"  {name}: {text}")
            elif kind == JournalKind.BOT_DECISION:
                actions = getattr(ent, "action_list", [])
                for act in actions:
                    if isinstance(act, dict) and act.get("type") in ("respond", "miao_reply"):
                        content = act.get("content", "")[:100]
                        lines.append(f"  你: {content}")
                        break
            elif kind == JournalKind.REFLECTION_SHIFT:
                thought = getattr(ent, "reflection_text", "")
                if thought:
                    lines.append(f"  （你的内心：{thought[:50]}...）")
        return "\n".join(lines)
    def _render_action_menu(self, actions: Optional[Dict]) -> str:
        if not actions:
            return (
                "- respond: 发送文字回复 (参数: content)\n"
                "- idle: 保持沉默\n"
                "- nudge_user: 轻戳对方\n"
                "- send_sticker: 发送表情 (参数: sticker)"
            )
        lines = []
        for name, info in actions.items():
            if isinstance(info, dict):
                desc = info.get("description", "")
                params = info.get("params", [])
                p_str = f" (参数: {', '.join(params)})" if params else ""
                lines.append(f"- {name}: {desc}{p_str}")
            else:
                lines.append(f"- {name}: {info}")
        return "\n".join(lines) if lines else "- respond: 回复\n- idle: 沉默"
    def _render_occasion_context(self, session: Any, occasion: str, addon: Dict) -> str:
        if occasion == "new_message":
            user_msg = addon.get("user_message", "")
            return f"用户刚发了一条新消息：\n「{user_msg}」" if user_msg else "用户刚发了一条新消息。"
        if occasion == "reply_in_time":
            elapsed = addon.get("elapsed_seconds", 0)
            anticipated = addon.get("anticipated_reply", "")
            return f"用户在 {elapsed:.0f} 秒内回复了。你之前期待的回应：{anticipated}"
        if occasion == "reply_late":
            elapsed = addon.get("elapsed_seconds", 0)
            return f"用户回复了，但已经过了 {elapsed:.0f} 秒（较慢）。"
        if occasion == "timeout":
            elapsed = addon.get("elapsed_seconds", 0)
            chase = addon.get("chase_count", 0)
            return f"用户超时 {elapsed:.0f} 秒未回复。已追问 {chase} 次。"
        if occasion == "proactive":
            silence = addon.get("silence_duration", "一段时间")
            trigger = addon.get("trigger_reason", "")
            return f"频道已沉默 {silence}。触发原因：{trigger}"
        return f"当前情境：{occasion}"
    # ---- 主动提示词 ----
    def _assemble_private_initiative_prompt(self, occasion_desc: str, ctx: Dict) -> str:
        silence_sec = ctx.get("silence_duration", 0)
        emotion = ctx.get("emotion_state", {})
        persona = ctx.get("current_persona", {})
        user_state = ctx.get("user_state", {})
        recent_msgs = ctx.get("recent_messages", [])
        history = self._format_recent_msgs(recent_msgs)
        persona_name = persona.get("name", "我")
        persona_tone = persona.get("tone", "随意")
        return (
            f"[我的身份] {persona_name}（{persona_tone}语调）\n\n"
            f"你正在与一位用户私聊。\n"
            f"频道已沉默 {silence_sec/60:.0f} 分钟。\n\n"
            f"用户特征:\n"
            f"- 好感度: {user_state.get('favor', user_state.get('affection', 0))}\n"
            f"- 烦躁度: {user_state.get('annoyance', 0)}\n"
            f"- 受众接受度: {ctx.get('audience_openness', 5.0):.1f}\n\n"
            f"我的状态:\n"
            f"- 心情: {emotion.get('average_mood_score', 0.5):.2f}\n"
            f"- 体力: {emotion.get('energy', 50)}\n\n"
            f"最近对话:\n{history}\n\n"
            f"背景: {occasion_desc}\n\n"
            f"请判断是否应该主动发消息。回答 JSON:\n"
            f'{{"should_speak": true/false, "thought": "想法", "reason": "理由", '
            f'"suggested_content": "建议内容", "confidence": 0.5, '
            f'"recheck_delay_sec": 600, "scores": {{}}}}'
        )
    def _assemble_group_initiative_prompt(self, occasion_desc: str, ctx: Dict) -> str:
        silence_sec = ctx.get("silence_duration", 0)
        emotion = ctx.get("emotion_state", {})
        persona = ctx.get("current_persona", {})
        recent_msgs = ctx.get("recent_messages", [])
        topics = ctx.get("recent_topics", "")
        history = self._format_recent_msgs(recent_msgs)
        persona_name = persona.get("name", "我")
        persona_tone = persona.get("tone", "随意")
        topic_line = f"近期话题：{topics[:200]}" if isinstance(topics, str) and topics.strip() else "近期话题：无明显话题"
        return (
            f"[我的身份] {persona_name}（{persona_tone}语调）\n\n"
            f"你在一个群聊中。\n"
            f"群已沉默 {silence_sec/60:.0f} 分钟。\n"
            f"{topic_line}\n\n"
            f"我的状态:\n"
            f"- 心情: {emotion.get('average_mood_score', 0.5):.2f}\n"
            f"- 体力: {ctx.get('energy', 50)}\n\n"
            f"最近对话:\n{history}\n\n"
            f"背景:\n{occasion_desc}\n\n"
            f"请判断是否应该主动发消息。回答 JSON:\n"
            f'{{"should_speak": true/false, "thought": "想法", "reason": "理由", '
            f'"suggested_content": "建议内容", "confidence": 0.5, '
            f'"recheck_delay_sec": 600, "scores": {{}}}}'
        )
    def _format_recent_msgs(self, messages: List) -> str:
        if not messages:
            return "（无最近对话记录）"
        lines = []
        for msg in messages[-10:]:
            if isinstance(msg, dict):
                who = msg.get("sender", "未知")
                text = msg.get("content", "")[:50]
                lines.append(f"- [{who}] {text}")
        return "\n".join(lines) if lines else "（无最近对话记录）"
    # ---- 响应解析 ----
    def _distill_blueprint_response(self, raw: str) -> ThinkOutcome:
        """从 LLM 原始输出中提取 ThinkOutcome"""
        cleaned = raw.strip()
        json_match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not json_match:
            logger.warning("[锻造器] 响应中未找到 JSON")
            return ThinkOutcome.make_fallback("no_json_found")
        json_str = json_match.group()
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            # 尝试修复尾逗号
            try:
                fixed = re.sub(r",\s*}", "}", json_str)
                fixed = re.sub(r",\s*]", "]", fixed)
                data = json.loads(fixed)
            except Exception:
                return ThinkOutcome.make_fallback("json_parse_error")
        if not isinstance(data, dict):
            return ThinkOutcome.make_fallback("not_a_dict")
        thought = data.get("thought", "")
        actions = data.get("actions", [])
        expected = data.get("expected_reaction", "")
        wait_sec = data.get("max_wait_seconds", 0)
        mood = data.get("mood", "")
        return ThinkOutcome(
            reflection=thought,
            action_list=actions if isinstance(actions, list) else [],
            anticipated_reply=expected,
            patience_sec=int(wait_sec),
            spirit_tag=mood,
        )
    def _distill_initiative_response(self, raw: str, ctx: Dict) -> Dict[str, Any]:
        """从主动规划 LLM 输出中提取结构化结果"""
        cleaned = raw.strip()
        json_match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not json_match:
            logger.warning("[锻造器] 主动响应中未找到 JSON")
            return {"success": False, "reason": "invalid_format"}
        json_str = json_match.group()
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            try:
                fixed = re.sub(r",\s*}", "}", json_str)
                fixed = re.sub(r",\s*]", "]", fixed)
                data = json.loads(fixed)
            except Exception:
                return {"success": False, "reason": "json_parse_error"}
        if not isinstance(data, dict):
            return {"success": False, "reason": "invalid_format"}
        thought = data.get("thought", "")
        should_speak = data.get("should_speak", False)
        certainty = data.get("confidence", 0.5)
        recheck = data.get("recheck_delay_sec", data.get("next_check_delay", 600))
        reason = data.get("reason", "")
        content = data.get("suggested_content", "")
        scores = data.get("scores", {})
        decision_label = data.get("decision", "wait")
        if not should_speak and decision_label.lower() not in ("proactive", "积极主动", "谨慎主动"):
            logger.info(f"[锻造器] 模型决定不主动 | {thought[:50]}... | {reason}")
            return {
                "success": False, "thought": thought, "reason": reason,
                "scores": scores, "recheck_delay_sec": recheck,
                "certainty": certainty, "skipped": True,
            }
        logger.info(f"[锻造器] 模型决定主动 | {thought[:50]}... | 确信={certainty:.2f}")
        return {
            "success": True, "thought": thought, "reason": reason,
            "scores": scores, "recheck_delay_sec": recheck,
            "certainty": certainty, "suggested_content": content,
            "actions": [{"type": "respond", "content": content}],
            "expected_reaction": "希望有人回应并开启对话",
            "max_wait_seconds": 600,
        }
    # ---- LLM 调用 ----
    async def _invoke_llm(self, prompt: str) -> Optional[str]:
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            self._refresh_params()
            req = LLMRequest(model_config.focus_chat, request_type="intention_forge")
            text, _ = await req.generate_response_async(
                prompt, max_tokens=self._param_cache["max_llm_tokens"],
            )
            return text
        except Exception as exc:
            logger.error(f"[锻造器] LLM 调用失败: {exc}")
            return None
    # ---- 就绪度组装 ----
    def assemble_readiness(self, raw_scores: Dict, shield_active: bool = False) -> ReadinessGauge:
        """从原始评分字典组装 ReadinessGauge"""
        return ReadinessGauge(
            spirit_score=float(raw_scores.get("spirit_score", raw_scores.get("mood_score", 5.0))),
            stamina_score=float(raw_scores.get("stamina_score", raw_scores.get("energy_score", 5.0))),
            eagerness_score=float(raw_scores.get("eagerness_score", raw_scores.get("willingness_score", 5.0))),
            quiet_fitness=float(raw_scores.get("quiet_fitness", raw_scores.get("silence_appropriateness", 5.0))),
            topic_readiness=float(raw_scores.get("topic_readiness", raw_scores.get("topic_availability", 5.0))),
            shield_integrity=10.0 if not shield_active else 0.0,
            timing_score=float(raw_scores.get("timing_score", 5.0)),
            audience_openness=float(raw_scores.get("audience_openness", raw_scores.get("user_receptiveness", 5.0))),
            recheck_delay_sec=int(raw_scores.get("recheck_delay_sec", raw_scores.get("next_check_delay", 600))),
            certainty=float(raw_scores.get("certainty", raw_scores.get("confidence", 0.5))),
            custom_weights=raw_scores.get("dynamic_weights"),
        )
    # ---- 统计 ----
    def collect_metrics(self) -> Dict[str, Any]:
        return dict(self._metrics)


def get_intention_forge() -> IntentionForge:
    """获取全局意图锻造器实例"""
    return IntentionForge.instance()
