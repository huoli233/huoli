import asyncio
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config

logger = get_logger("cognitive_dispatch")


class JobUrgency(Enum):
    """任务紧急度枚举"""
    CRITICAL = 1
    ELEVATED = 2
    STANDARD = 3
    DEFERRED = 4
    BACKGROUND = 5


class JobDomain(Enum):
    """任务领域枚举"""
    TIMEOUT_RESOLVE = "timeout_resolve"
    PONDER_REFRESH = "ponder_refresh"
    IMPULSE_LAUNCH = "impulse_launch"
    GENERIC_WORK = "generic_work"


@dataclass
class CognitiveJob:
    """认知任务数据模型"""
    job_id: str = ""
    domain: JobDomain = JobDomain.GENERIC_WORK
    urgency: JobUrgency = JobUrgency.STANDARD
    target_user: str = ""
    target_channel: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    born_at: float = field(default_factory=time.time)
    fire_at: float = 0.0
    began_at: float = 0.0
    ended_at: float = 0.0
    phase: str = "queued"
    attempt: int = 0
    max_attempts: int = 0
    outcome: Optional[Any] = None
    fault_msg: Optional[str] = None
    def is_ripe(self) -> bool:
        """任务是否已就绪"""
        return time.time() >= self.fire_at and self.phase == "queued"
    def is_stale(self, max_age: float = 3600.0) -> bool:
        """任务是否已过期"""
        return time.time() - self.born_at > max_age
    def __lt__(self, other: "CognitiveJob") -> bool:
        """优先级比较，用于排序"""
        if self.urgency.value != other.urgency.value:
            return self.urgency.value < other.urgency.value
        return self.born_at < other.born_at
    def to_dict(self) -> Dict[str, Any]:
        return {
            "job_id": self.job_id,
            "domain": self.domain.value,
            "urgency": self.urgency.value,
            "target_user": self.target_user,
            "target_channel": self.target_channel,
            "born_at": self.born_at,
            "fire_at": self.fire_at,
            "began_at": self.began_at,
            "ended_at": self.ended_at,
            "phase": self.phase,
            "attempt": self.attempt,
            "fault_msg": self.fault_msg,
        }


class CognitiveDispatcher:
    """
    认知任务调度器
    后台循环轮询就绪任务并通过注册的处理器执行。
    支持优先级排序、任务去重、超时取消和失败重试。
    """
    _solo: Optional["CognitiveDispatcher"] = None
    @classmethod
    def instance(cls) -> "CognitiveDispatcher":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        if cls._solo is not None:
            cls._solo._active = False
        cls._solo = None
    def __init__(self):
        self._cfg_cache: Dict[str, Any] = {}
        self._cfg_ts: float = 0.0
        self._reload_params()
        self._registry: Dict[str, CognitiveJob] = {}
        self._wait_line: List[CognitiveJob] = []
        self._in_flight: Set[str] = set()
        self._archive: List[CognitiveJob] = []
        self._handlers: Dict[JobDomain, Callable] = {}
        self._active = False
        self._loop_handle: Optional[asyncio.Task] = None
        self._bg_tasks: Set[asyncio.Task] = set()
        self._seq = 0
        # 去重映射：(target_user, domain_value) -> job_id
        self._dedup_index: Dict[str, str] = {}
    # ---- 配置 ----
    def _reload_params(self) -> None:
        now = time.time()
        if now - self._cfg_ts < 60.0:
            return
        hub = get_core_config()
        blk = hub.proactive_schedule_block()
        self._cfg_cache = {
            "capacity": int(blk.get("queue_capacity", 20)),
            "timeout": float(blk.get("think_timeout_seconds", 30.0)),
            "max_retries": int(blk.get("retry_max_count", 2)),
            "concurrency": int(blk.get("max_concurrent_thinks", 3)),
            "cooldown": float(blk.get("min_cooldown_seconds", 60.0)),
        }
        self._cfg_ts = now
    def _cp(self, key: str) -> Any:
        self._reload_params()
        return self._cfg_cache[key]
    # ---- 处理器注册 ----
    def bind_handler(self, domain: JobDomain, handler: Callable) -> None:
        """注册某个领域的任务处理器"""
        self._handlers[domain] = handler
        logger.debug(f"[调度器] 绑定处理器: {domain.value}")
    # ---- 任务入队 ----
    def enqueue_job(
        self,
        domain: JobDomain,
        target_user: str,
        target_channel: str,
        urgency: JobUrgency = JobUrgency.STANDARD,
        payload: Optional[Dict[str, Any]] = None,
        delay_sec: float = 0.0,
    ) -> Optional[str]:
        """
        提交任务到队列
        自动去重：同一用户同一领域只保留一个排队任务
        返回 job_id 或 None(队列满/被去重)
        """
        cap = self._cp("capacity")
        if len(self._wait_line) >= cap:
            logger.warning("[调度器] 队列已满，丢弃任务")
            return None
        # 去重检查
        dedup_key = f"{target_user}:{domain.value}"
        if dedup_key in self._dedup_index:
            existing_id = self._dedup_index[dedup_key]
            existing = self._registry.get(existing_id)
            if existing and existing.phase == "queued":
                logger.debug(f"[调度器] 去重跳过: {dedup_key}")
                return None
        self._seq += 1
        job_id = f"cj_{int(time.time())}_{self._seq}"
        job = CognitiveJob(
            job_id=job_id,
            domain=domain,
            urgency=urgency,
            target_user=target_user,
            target_channel=target_channel,
            payload=payload or {},
            fire_at=time.time() + delay_sec,
            max_attempts=self._cp("max_retries"),
        )
        self._registry[job_id] = job
        self._wait_line.append(job)
        self._wait_line.sort()
        self._dedup_index[dedup_key] = job_id
        logger.debug(f"[调度器] 入队: {job_id} ({domain.value}) urgency={urgency.value}")
        return job_id
    # ---- 取消任务 ----
    def revoke_job(self, job_id: str) -> bool:
        """取消一个排队中的任务"""
        job = self._registry.get(job_id)
        if not job or job.phase != "queued":
            return False
        job.phase = "cancelled"
        if job in self._wait_line:
            self._wait_line.remove(job)
        dedup_key = f"{job.target_user}:{job.domain.value}"
        self._dedup_index.pop(dedup_key, None)
        return True
    def revoke_user_jobs(self, target_user: str) -> int:
        """取消某用户的全部排队任务"""
        revoked = 0
        for jid, job in list(self._registry.items()):
            if job.target_user == target_user and job.phase == "queued":
                if self.revoke_job(jid):
                    revoked += 1
        return revoked
    # ---- 启停 ----
    async def start(self) -> None:
        """启动后台调度循环"""
        if self._active:
            return
        self._active = True
        self._loop_handle = asyncio.ensure_future(self._polling_loop())
        logger.info("[调度器] 已启动")
    async def stop(self) -> None:
        """停止调度循环并取消所有后台任务"""
        self._active = False
        if self._loop_handle and not self._loop_handle.done():
            self._loop_handle.cancel()
            try:
                await self._loop_handle
            except asyncio.CancelledError:
                pass
        for task in list(self._bg_tasks):
            if not task.done():
                task.cancel()
        self._bg_tasks.clear()
        logger.info("[调度器] 已停止")
    # ---- 调度循环 ----
    async def _polling_loop(self) -> None:
        """每秒轮询就绪任务"""
        while self._active:
            try:
                await self._process_ripe_jobs()
                await asyncio.sleep(1.0)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error(f"[调度器] 循环异常: {exc}")
                await asyncio.sleep(2.0)
    async def _process_ripe_jobs(self) -> None:
        """扫描并执行就绪任务"""
        concurrency_cap = self._cp("concurrency")
        ripe = [j for j in self._wait_line if j.is_ripe()]
        for job in ripe:
            if job.job_id in self._in_flight:
                continue
            if len(self._in_flight) >= concurrency_cap:
                break
            self._wait_line.remove(job)
            # 检查过期
            if job.is_stale():
                job.phase = "expired"
                self._archive.append(job)
                continue
            task = asyncio.ensure_future(self._run_job(job))
            self._bg_tasks.add(task)
            task.add_done_callback(self._bg_tasks.discard)
    async def _run_job(self, job: CognitiveJob) -> None:
        """执行单个任务"""
        self._in_flight.add(job.job_id)
        job.phase = "running"
        job.began_at = time.time()
        try:
            handler = self._handlers.get(job.domain)
            if not handler:
                job.phase = "failed"
                job.fault_msg = f"无处理器: {job.domain.value}"
                return
            timeout = self._cp("timeout")
            if asyncio.iscoroutinefunction(handler):
                result = await asyncio.wait_for(handler(job), timeout=timeout)
            else:
                result = handler(job)
            job.outcome = result
            job.phase = "done"
            job.ended_at = time.time()
        except asyncio.TimeoutError:
            job.phase = "timeout"
            job.fault_msg = "执行超时"
        except Exception as exc:
            job.phase = "failed"
            job.fault_msg = str(exc)
            if job.attempt < job.max_attempts:
                job.attempt += 1
                job.phase = "queued"
                job.fire_at = time.time() + 5.0
                self._wait_line.append(job)
                self._wait_line.sort()
                return
        finally:
            self._in_flight.discard(job.job_id)
            if job.phase in ("done", "failed", "timeout", "expired"):
                self._archive.append(job)
                dedup_key = f"{job.target_user}:{job.domain.value}"
                self._dedup_index.pop(dedup_key, None)
                if len(self._archive) > 100:
                    self._archive = self._archive[-50:]
    # ---- 查询接口 ----
    def lookup_job(self, job_id: str) -> Optional[CognitiveJob]:
        return self._registry.get(job_id)
    def aggregate_stats(self) -> Dict[str, Any]:
        return {
            "active": self._active,
            "total_registered": len(self._registry),
            "queued": len(self._wait_line),
            "in_flight": len(self._in_flight),
            "archived": len(self._archive),
        }


def get_cognitive_dispatcher() -> CognitiveDispatcher:
    """获取认知调度器单例"""
    return CognitiveDispatcher.instance()
