import asyncio
import json
import math
import os
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Deque, Dict, List, Optional, Set, Tuple
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config

logger = get_logger("kinship_weaver")


class BondPhase(Enum):
    """关系阶段（7 级）"""
    STRANGER = "stranger"
    PASSERBY = "passerby"
    ACQUAINTANCE = "acquaintance"
    COMPANION = "companion"
    CONFIDANT = "confidant"
    TRUSTED = "trusted"
    HOSTILE = "hostile"
    BLOCKED = "blocked"


@dataclass
class StreakLedger:
    """连续性追踪账本"""
    positive_run: int = 0
    negative_run: int = 0
    bias_offset: float = 0.0
    last_touch_ts: float = 0.0
    def decay_bias(self, half_life_sec: float = 3600.0) -> None:
        if self.last_touch_ts <= 0 or self.bias_offset == 0.0:
            return
        elapsed = time.time() - self.last_touch_ts
        if elapsed <= 0:
            return
        factor = math.pow(0.5, elapsed / max(half_life_sec, 1.0))
        self.bias_offset *= factor


@dataclass
class TrendSample:
    """趋势采样点"""
    value: float = 0.0
    timestamp: float = 0.0


@dataclass
class PhaseShift:
    """阶段跃迁记录"""
    prior: BondPhase = BondPhase.STRANGER
    landed: BondPhase = BondPhase.STRANGER
    shifted_at: float = 0.0
    social_val: float = 0.0


@dataclass
class Milestone:
    """里程碑"""
    tag: str = ""
    achieved_at: float = 0.0
    value_at: float = 0.0


@dataclass
class MutualityProfile:
    """单用户关系档案"""
    uid: str = ""
    channel_id: str = ""
    current_phase: BondPhase = BondPhase.STRANGER
    trend_tag: str = "stable"
    trend_samples: List[TrendSample] = field(default_factory=list)
    phase_log: List[PhaseShift] = field(default_factory=list)
    milestones: List[Milestone] = field(default_factory=list)
    pair_bonds: Dict[str, float] = field(default_factory=dict)
    last_phase_shift_ts: float = 0.0
    _MAX_TREND: int = 100
    _MAX_LOG: int = 30
    def to_dict(self) -> Dict[str, Any]:
        return {
            "uid": self.uid,
            "channel_id": self.channel_id,
            "current_phase": self.current_phase.value,
            "trend_tag": self.trend_tag,
            "milestones": [{"tag": m.tag, "at": m.achieved_at, "val": m.value_at} for m in self.milestones],
            "pair_bonds": dict(self.pair_bonds),
        }
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MutualityProfile":
        obj = cls(
            uid=str(data.get("uid", "")),
            channel_id=str(data.get("channel_id", "")),
            trend_tag=str(data.get("trend_tag", "stable")),
        )
        try:
            obj.current_phase = BondPhase(data.get("current_phase", "stranger"))
        except ValueError:
            obj.current_phase = BondPhase.STRANGER
        obj.pair_bonds = dict(data.get("pair_bonds", {}))
        for m_data in data.get("milestones", []):
            obj.milestones.append(Milestone(
                tag=str(m_data.get("tag", "")),
                achieved_at=float(m_data.get("at", 0.0)),
                value_at=float(m_data.get("val", 0.0)),
            ))
        return obj


@dataclass
class TraitSnapshot:
    """用户特征快照"""
    personality_traits: List[str] = field(default_factory=list)
    topic_preferences: Dict[str, float] = field(default_factory=dict)
    behavior_distribution: Dict[str, int] = field(default_factory=dict)
    active_hours: List[int] = field(default_factory=list)
    interaction_count: int = 0
    refreshed_ts: float = 0.0


class KinshipWeaver:
    """
    社交编织引擎

    将社交值计算（四层映射 + 渐进限制 + 阈值加速）、
    关系阶段追踪（7 阶段 + 趋势 + 里程碑）、
    活跃窗口（分配因子 + 厌恶惩罚）、
    用户印象（模型特征提取）串联为一体。
    """
    _solo: Optional["KinshipWeaver"] = None
    @classmethod
    def instance(cls) -> "KinshipWeaver":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        if cls._solo:
            cls._solo._flush_all()
            cls._solo._profiles.clear()
            cls._solo._streaks.clear()
            cls._solo._traits.clear()
            cls._solo._active_slots.clear()
        cls._solo = None
    def __init__(self):
        self._profiles: Dict[str, MutualityProfile] = {}
        self._streaks: Dict[str, StreakLedger] = {}
        self._traits: Dict[str, TraitSnapshot] = {}
        self._active_slots: Dict[str, OrderedDict] = {}
        self._active_refresh_ts: float = 0.0
        self._conf: Dict[str, Any] = {}
        self._conf_ts: float = 0.0
        self._disk_dir: str = "data/huoli/kinship"
        self._fetch_conf()
        self._load_profiles()
    # ---- 配置 ----
    def _fetch_conf(self) -> None:
        now = time.time()
        if now - self._conf_ts < 60.0:
            return
        hub = get_core_config()
        ps = hub.personality_sliders_block()
        self._conf = {
            # 计算参数
            "max_single_step": float(ps.get("social_max_single_step", 8.0)),
            "time_decay_per_day": float(ps.get("social_time_decay_per_day", 0.3)),
            "damping_factor": float(ps.get("social_damping_factor", 0.85)),
            "positive_streak_coeff": float(ps.get("social_positive_streak_coeff", 0.08)),
            "negative_streak_coeff": float(ps.get("social_negative_streak_coeff", 0.12)),
            "streak_bonus_cap": float(ps.get("social_streak_bonus_cap", 0.5)),
            "streak_half_life": float(ps.get("social_streak_half_life_sec", 3600.0)),
            "acceleration_multiplier": float(ps.get("social_acceleration_multiplier", 1.4)),
            "acceleration_threshold_base": float(ps.get("social_acceleration_threshold_base", 60.0)),
            "new_user_factor": float(ps.get("social_new_user_factor", 1.3)),
            "new_user_threshold_encounters": int(ps.get("social_new_user_threshold_encounters", 5)),
            # 关系阈值（阶段: [下限, 上限)）
            "phase_bounds": {
                "stranger": [
                    float(ps.get("phase_stranger_low", -30.0)),
                    float(ps.get("phase_stranger_high", 10.0)),
                ],
                "passerby": [
                    float(ps.get("phase_passerby_low", 10.0)),
                    float(ps.get("phase_passerby_high", 25.0)),
                ],
                "acquaintance": [
                    float(ps.get("phase_acquaintance_low", 25.0)),
                    float(ps.get("phase_acquaintance_high", 45.0)),
                ],
                "companion": [
                    float(ps.get("phase_companion_low", 45.0)),
                    float(ps.get("phase_companion_high", 65.0)),
                ],
                "confidant": [
                    float(ps.get("phase_confidant_low", 65.0)),
                    float(ps.get("phase_confidant_high", 85.0)),
                ],
                "trusted": [
                    float(ps.get("phase_trusted_low", 85.0)),
                    float(ps.get("phase_trusted_high", 101.0)),
                ],
                "hostile": [
                    float(ps.get("phase_hostile_low", -100.0)),
                    float(ps.get("phase_hostile_high", -30.0)),
                ],
            },
            # 趋势
            "trend_window_sec": float(ps.get("social_trend_window_sec", 86400.0)),
            "trend_improving_threshold": float(ps.get("social_trend_improving", 5.0)),
            "trend_declining_threshold": float(ps.get("social_trend_declining", -5.0)),
            # 阶段跃迁
            "phase_cooldown_sec": float(ps.get("social_phase_cooldown_sec", 600.0)),
            "protection_ratio": float(ps.get("social_protection_ratio", 0.3)),
            # 里程碑
            "milestone_thresholds": {
                "first_chat": float(ps.get("milestone_first_chat", 5.0)),
                "warming_up": float(ps.get("milestone_warming_up", 20.0)),
                "good_friend": float(ps.get("milestone_good_friend", 50.0)),
                "deep_bond": float(ps.get("milestone_deep_bond", 80.0)),
            },
            # 活跃窗口
            "window_duration_sec": float(ps.get("active_window_duration_sec", 1200.0)),
            "window_max_slots": int(ps.get("active_window_max_slots", 20)),
            "dist_tier1_count": int(ps.get("dist_tier1_count", 3)),
            "dist_tier2_count": int(ps.get("dist_tier2_count", 10)),
            "dist_tier1_factor": float(ps.get("dist_tier1_factor", 1.0)),
            "dist_tier2_base": float(ps.get("dist_tier2_base", 0.8)),
            "dist_tier2_slope": float(ps.get("dist_tier2_slope", 0.04)),
            "dist_min_factor": float(ps.get("dist_min_factor", 0.3)),
            "dist_tier3_base": float(ps.get("dist_tier3_base", 0.52)),
            "dist_tier3_slope": float(ps.get("dist_tier3_slope", 0.022)),
        }
        self._conf_ts = now
    # ---- 社交值计算 ----
    def reckon_social_delta(
        self,
        uid: str,
        channel_id: str,
        base_score: float,
        severity: float,
        current_value: float,
        encounter_count: int = 0,
        fatigue: float = 0.0,
        pressure: float = 0.0,
        annoyance: float = 0.0,
    ) -> float:
        """
        完整社交值变化计算流水线

        步骤:
          1. 单步限幅
          2. 阻尼
          3. 新用户加成
          4. 连续性偏移 + 阈值加速
          5. 活跃窗口分配因子 + 厌恶惩罚
          6. 累积效率衰减
        """
        self._fetch_conf()
        c = self._conf
        ceil = c["max_single_step"]
        # 限幅
        clamped = max(-ceil, min(ceil, base_score))
        # 阻尼
        clamped *= c["damping_factor"]
        # 新用户放大
        if encounter_count < c["new_user_threshold_encounters"]:
            clamped *= c["new_user_factor"]
        # 连续性偏移
        sk = self._get_streak(uid)
        sk.decay_bias(c["streak_half_life"])
        dynamic_threshold = c["acceleration_threshold_base"] + sk.bias_offset
        if abs(current_value) > dynamic_threshold:
            clamped *= c["acceleration_multiplier"]
        # 记录连续
        self._log_streak(sk, clamped, severity)
        # 活跃窗口修正
        dist_factor = self._compute_distribution(channel_id)
        dislike_penalty = self._compute_annoyance_penalty(annoyance)
        clamped = clamped * dist_factor + dislike_penalty
        # 累积效率衰减
        efficiency = self._accumulation_efficiency(fatigue, pressure, current_value)
        clamped *= efficiency
        return round(clamped, 4)
    def _log_streak(self, sk: StreakLedger, delta: float, severity: float) -> None:
        c = self._conf
        cap = c["streak_bonus_cap"]
        intensity = max(0.0, min(1.0, severity))
        if delta > 0:
            sk.positive_run += 1
            sk.negative_run = 0
            bonus = min(cap, (sk.positive_run - 1) * 0.1)
            sk.bias_offset += c["positive_streak_coeff"] * intensity * (1.0 + bonus)
        elif delta < 0:
            sk.negative_run += 1
            sk.positive_run = 0
            bonus = min(cap, (sk.negative_run - 1) * 0.1)
            sk.bias_offset += c["negative_streak_coeff"] * intensity * (1.0 + bonus)
        else:
            sk.positive_run = 0
            sk.negative_run = 0
        sk.bias_offset = max(-30.0, min(30.0, sk.bias_offset))
        sk.last_touch_ts = time.time()
    def _accumulation_efficiency(self, fatigue: float, pressure: float, current: float) -> float:
        fatigue_drain = max(0.0, fatigue / 100.0) * 0.3
        pressure_drain = max(0.0, pressure / 100.0) * 0.2
        saturation_drain = (abs(current) / 100.0) * 0.15
        return max(0.1, 1.0 - fatigue_drain - pressure_drain - saturation_drain)
    def _get_streak(self, uid: str) -> StreakLedger:
        if uid not in self._streaks:
            self._streaks[uid] = StreakLedger()
        return self._streaks[uid]
    # ---- 活跃窗口 ----
    def ping_active_slot(self, channel_id: str, uid: str) -> None:
        """刷新活跃窗口"""
        key = f"ch_{channel_id}"
        if key not in self._active_slots:
            self._active_slots[key] = OrderedDict()
        slot = self._active_slots[key]
        slot[uid] = time.time()
        # 过期清理
        cutoff = time.time() - self._conf.get("window_duration_sec", 1200.0)
        expired = [u for u, ts in slot.items() if ts < cutoff]
        for u in expired:
            del slot[u]
        cap = self._conf.get("window_max_slots", 20)
        if len(slot) > cap:
            sorted_slot = OrderedDict(sorted(slot.items(), key=lambda x: x[1], reverse=True))
            self._active_slots[key] = OrderedDict(list(sorted_slot.items())[:cap])
    def active_count(self, channel_id: str) -> int:
        key = f"ch_{channel_id}"
        return len(self._active_slots.get(key, {}))
    def _compute_distribution(self, channel_id: str) -> float:
        count = max(1, self.active_count(channel_id))
        c = self._conf
        t1 = c["dist_tier1_count"]
        t2 = c["dist_tier2_count"]
        if count <= t1:
            return c["dist_tier1_factor"]
        if count <= t2:
            return c["dist_tier2_base"] - (count - t1) * c["dist_tier2_slope"]
        return max(c["dist_min_factor"], c["dist_tier3_base"] - (count - t2) * c["dist_tier3_slope"])
    @staticmethod
    def _compute_annoyance_penalty(annoyance: float) -> float:
        if annoyance < 10:
            return 0.0
        if annoyance >= 80:
            return -0.08
        if annoyance >= 50:
            return -0.05
        if annoyance >= 30:
            return -0.03
        return -0.01
    # ---- 关系阶段 ----
    def refresh_phase(self, uid: str, channel_id: str, social_value: float) -> Optional[PhaseShift]:
        """根据社交值更新用户关系阶段"""
        self._fetch_conf()
        prof = self._ensure_profile(uid, channel_id)
        now = time.time()
        # 趋势采样
        prof.trend_samples.append(TrendSample(value=social_value, timestamp=now))
        if len(prof.trend_samples) > prof._MAX_TREND:
            prof.trend_samples = prof.trend_samples[-prof._MAX_TREND:]
        prof.trend_tag = self._evaluate_trend(prof)
        # 里程碑检查
        self._scan_milestones(prof, social_value, now)
        # 阶段判定
        candidate = self._infer_phase(social_value)
        shift: Optional[PhaseShift] = None
        if candidate != prof.current_phase and self._transition_allowed(prof, social_value, candidate, now):
            shift = PhaseShift(
                prior=prof.current_phase,
                landed=candidate,
                shifted_at=now,
                social_val=social_value,
            )
            prof.phase_log.append(shift)
            if len(prof.phase_log) > prof._MAX_LOG:
                prof.phase_log = prof.phase_log[-prof._MAX_LOG:]
            prof.current_phase = candidate
            prof.last_phase_shift_ts = now
            logger.info(f"[编织] 阶段跃迁 | {uid}@{channel_id} {shift.prior.value}→{shift.landed.value}")
        self._persist_profile(uid, channel_id)
        return shift
    def note_pair_interaction(self, uid: str, channel_id: str, partner_uid: str, weight: float = 1.0) -> None:
        prof = self._ensure_profile(uid, channel_id)
        prof.pair_bonds[partner_uid] = prof.pair_bonds.get(partner_uid, 0.0) + weight
    def closest_partners(self, uid: str, channel_id: str, cap: int = 5) -> List[Tuple[str, float]]:
        prof = self._ensure_profile(uid, channel_id)
        return sorted(prof.pair_bonds.items(), key=lambda kv: kv[1], reverse=True)[:cap]
    def current_phase(self, uid: str, channel_id: str) -> BondPhase:
        return self._ensure_profile(uid, channel_id).current_phase
    def current_trend(self, uid: str, channel_id: str) -> str:
        return self._ensure_profile(uid, channel_id).trend_tag
    def recent_shifts(self, uid: str, channel_id: str, cap: int = 5) -> List[PhaseShift]:
        return self._ensure_profile(uid, channel_id).phase_log[-cap:]
    def all_milestones(self, uid: str, channel_id: str) -> List[Milestone]:
        return list(self._ensure_profile(uid, channel_id).milestones)
    def _infer_phase(self, social_value: float) -> BondPhase:
        bounds = self._conf.get("phase_bounds", {})
        for phase_str, rng in bounds.items():
            if not isinstance(rng, list) or len(rng) != 2:
                continue
            low, high = float(rng[0]), float(rng[1])
            if low <= social_value < high:
                try:
                    return BondPhase(phase_str)
                except ValueError:
                    continue
        if social_value <= -100.0:
            return BondPhase.HOSTILE
        return BondPhase.TRUSTED
    def _evaluate_trend(self, prof: MutualityProfile) -> str:
        if len(prof.trend_samples) < 2:
            return "stable"
        cutoff = time.time() - self._conf.get("trend_window_sec", 86400.0)
        recent = [s for s in prof.trend_samples if s.timestamp >= cutoff]
        if len(recent) < 2:
            return "stable"
        diff = recent[-1].value - recent[0].value
        if diff >= self._conf.get("trend_improving_threshold", 5.0):
            return "improving"
        if diff <= self._conf.get("trend_declining_threshold", -5.0):
            return "declining"
        return "stable"
    def _scan_milestones(self, prof: MutualityProfile, social_value: float, now: float) -> None:
        reached_tags = {m.tag for m in prof.milestones}
        for tag, threshold in self._conf.get("milestone_thresholds", {}).items():
            if tag in reached_tags:
                continue
            if social_value >= float(threshold):
                prof.milestones.append(Milestone(tag=tag, achieved_at=now, value_at=social_value))
    def _transition_allowed(self, prof: MutualityProfile, sv: float, candidate: BondPhase, now: float) -> bool:
        cooldown = self._conf.get("phase_cooldown_sec", 600.0)
        if prof.last_phase_shift_ts > 0 and (now - prof.last_phase_shift_ts) < cooldown:
            return False
        # 敌对/封锁不受保护
        if candidate in (BondPhase.HOSTILE, BondPhase.BLOCKED):
            return True
        # 防抖：当前阶段中心保护
        cur_bounds = self._conf.get("phase_bounds", {}).get(prof.current_phase.value)
        if not isinstance(cur_bounds, list) or len(cur_bounds) != 2:
            return True
        low, high = float(cur_bounds[0]), float(cur_bounds[1])
        width = max(1.0, high - low)
        center = (low + high) / 2.0
        ratio = self._conf.get("protection_ratio", 0.3)
        if sv < center and (center - sv) < width * ratio:
            return False
        return True
    # ---- 用户印象 ----
    async def absorb_impression(
        self,
        uid: str,
        content: str,
        context: Dict[str, Any],
    ) -> Optional[TraitSnapshot]:
        """通过 LLM 提取用户特征并更新快照"""
        snap = self._ensure_trait(uid)
        if len(content.strip()) < 5:
            return snap
        traits = await self._extract_traits_llm(content, context)
        topics = await self._extract_topics_llm(content, context)
        if traits:
            existing = set(snap.personality_traits)
            existing.update(traits)
            snap.personality_traits = list(existing)[:20]
        if topics:
            for t in topics:
                snap.topic_preferences[t] = min(1.0, snap.topic_preferences.get(t, 0.0) + 0.1)
        snap.interaction_count += 1
        hour = time.localtime().tm_hour
        if hour not in snap.active_hours:
            snap.active_hours.append(hour)
            snap.active_hours.sort()
        snap.refreshed_ts = time.time()
        return snap
    def get_trait_snapshot(self, uid: str) -> TraitSnapshot:
        return self._ensure_trait(uid)
    def _ensure_trait(self, uid: str) -> TraitSnapshot:
        if uid not in self._traits:
            self._traits[uid] = TraitSnapshot()
        return self._traits[uid]
    async def _extract_traits_llm(self, content: str, ctx: Dict) -> List[str]:
        prompt = (
            f"[性格特征提取]\n用户发言：{content[:1500]}\n上下文：{str(ctx)[:500]}\n\n"
            f'输出 JSON：{{"traits": ["特征1","特征2"]}}'
        )
        raw = await self._call_llm(prompt)
        if not raw:
            return []
        parsed = self._parse_json(raw)
        if parsed and "traits" in parsed:
            return [str(t) for t in parsed["traits"][:5]]
        return []
    async def _extract_topics_llm(self, content: str, ctx: Dict) -> List[str]:
        if len(content.strip()) < 10:
            return []
        prompt = (
            f"[话题检测]\n用户发言：{content[:1500]}\n上下文：{str(ctx)[:300]}\n\n"
            f'输出 JSON：{{"topics": ["话题1","话题2"]}}'
        )
        raw = await self._call_llm(prompt)
        if not raw:
            return []
        parsed = self._parse_json(raw)
        if parsed and "topics" in parsed:
            return [str(t) for t in parsed["topics"][:5]]
        return []
    # ---- 持久化 ----
    def _ensure_profile(self, uid: str, channel_id: str) -> MutualityProfile:
        key = f"{uid}:{channel_id}"
        if key not in self._profiles:
            self._profiles[key] = MutualityProfile(uid=uid, channel_id=channel_id)
        return self._profiles[key]
    def _persist_profile(self, uid: str, channel_id: str) -> None:
        prof = self._profiles.get(f"{uid}:{channel_id}")
        if not prof:
            return
        try:
            os.makedirs(self._disk_dir, exist_ok=True)
            import re as _re
            safe_name = _re.sub(r'[^\w\-]', '_', f"{uid}_{channel_id}")
            path = os.path.join(self._disk_dir, f"{safe_name}.json")
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(prof.to_dict(), fh, ensure_ascii=False, indent=2)
        except (OSError, TypeError) as exc:
            logger.debug(f"[编织] 持久化失败 | {uid}@{channel_id}: {exc}")
    def _load_profiles(self) -> None:
        if not os.path.isdir(self._disk_dir):
            return
        try:
            for fname in os.listdir(self._disk_dir):
                if not fname.endswith(".json"):
                    continue
                path = os.path.join(self._disk_dir, fname)
                try:
                    with open(path, "r", encoding="utf-8") as fh:
                        data = json.load(fh)
                    prof = MutualityProfile.from_dict(data)
                    key = f"{prof.uid}:{prof.channel_id}"
                    if prof.uid:
                        self._profiles[key] = prof
                except (json.JSONDecodeError, TypeError, KeyError) as exc:
                    logger.debug(f"[编织] 加载失败 | {fname}: {exc}")
        except OSError as exc:
            logger.debug(f"[编织] 读取目录失败: {exc}")
    def _flush_all(self) -> None:
        for key, prof in self._profiles.items():
            self._persist_profile(prof.uid, prof.channel_id)
    # ---- LLM / JSON ----
    async def _call_llm(self, prompt: str) -> Optional[str]:
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            req = LLMRequest(model_config.utils, request_type="kinship_weaver")
            text, _ = await req.generate_response_async(prompt, max_tokens=400)
            return text
        except Exception as exc:
            logger.error(f"[编织] LLM 调用失败: {exc}")
            return None
    @staticmethod
    def _parse_json(raw: str) -> Optional[Dict]:
        import re
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return None
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            try:
                fixed = re.sub(r",\s*}", "}", match.group())
                return json.loads(fixed)
            except Exception:
                return None
    def collect_metrics(self) -> Dict[str, Any]:
        return {
            "profile_count": len(self._profiles),
            "streak_count": len(self._streaks),
            "trait_snapshots": len(self._traits),
            "active_channels": len(self._active_slots),
        }


def get_kinship_weaver() -> KinshipWeaver:
    """获取全局社交编织引擎实例"""
    return KinshipWeaver.instance()
