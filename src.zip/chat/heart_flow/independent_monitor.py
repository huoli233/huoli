import asyncio
import time as _tm
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config

import src.chat.prompts.catalog  # noqa: F401 注册提示词
from src.chat.utils.prompt_builder import global_prompt_manager

logger = get_logger("indep_monitor")

def _cfg() -> Dict[str, Any]:
    """从核心配置中枢读取独立监控参数"""
    try:
        return get_core_config().assemble_monitor_config()
    except RuntimeError:
        return {}

# ---------------------------------------------------------------------------
#  待处理消息载体 & 缓冲区
# ---------------------------------------------------------------------------

@dataclass
class _InboundNote:
    """单条待处理消息"""
    stream_id: str
    sender_id: str
    body: str
    arrived_at: float

class _NoteBuffer:
    """按频道分桶的消息蓄洪池"""
    def __init__(self):
        self._buckets: Dict[str, List[_InboundNote]] = {}
    def deposit(self, note: _InboundNote) -> None:
        cap = int(_cfg().get("buffer_capacity", 50))
        bucket = self._buckets.setdefault(note.stream_id, [])
        if len(bucket) >= cap:
            bucket.pop(0)
        bucket.append(note)
    def withdraw(self, stream_id: str) -> List[_InboundNote]:
        batch_size = int(_cfg().get("drain_batch", 10))
        bucket = self._buckets.get(stream_id, [])
        batch = bucket[:batch_size]
        self._buckets[stream_id] = bucket[batch_size:]
        return batch
    def occupied_streams(self) -> Set[str]:
        return {s for s, notes in self._buckets.items() if notes}
    def depth(self, stream_id: str) -> int:
        return len(self._buckets.get(stream_id, []))

# ---------------------------------------------------------------------------
#  聚合窗口：合并短时间内密集到达的消息
# ---------------------------------------------------------------------------

class _AggregationGate:
    """消息聚合闸门，在 settle 窗口内收集完整批次"""
    def __init__(self):
        self._pending_events: Dict[str, asyncio.Event] = {}
        self._last_deposit_ts: Dict[str, float] = {}
    def notify(self, stream_id: str) -> None:
        self._last_deposit_ts[stream_id] = _tm.time()
        evt = self._pending_events.get(stream_id)
        if evt is None:
            self._pending_events[stream_id] = asyncio.Event()
            self._pending_events[stream_id].set()
        else:
            evt.set()
    async def wait_settled(self, stream_id: str) -> None:
        """等待消息流稳定（无新消息超过 settle 窗口）"""
        c = _cfg()
        initial = float(c.get("agg_initial", 0.5))
        settle = float(c.get("agg_settle", 1.5))
        ceiling = float(c.get("agg_max", 5.0))
        await asyncio.sleep(initial)
        deadline = _tm.time() + ceiling
        while _tm.time() < deadline:
            last = self._last_deposit_ts.get(stream_id, 0.0)
            gap = _tm.time() - last
            if gap >= settle:
                break
            await asyncio.sleep(min(settle - gap, 0.3))
        self._pending_events.pop(stream_id, None)
    def has_pending(self, stream_id: str) -> bool:
        evt = self._pending_events.get(stream_id)
        return evt is not None and evt.is_set()

# ---------------------------------------------------------------------------
#  频道健康档案
# ---------------------------------------------------------------------------

@dataclass
class ChannelVitalRecord:
    """单频道运行时健康指标"""
    stream_id: str
    last_user_msg_at: float = 0.0
    last_bot_reply_at: float = 0.0
    consecutive_silence_ticks: int = 0
    total_decisions: int = 0
    total_replies: int = 0
    user_msg_ring: deque = field(default_factory=lambda: deque(maxlen=100))
    proactive_cooldown_until: float = 0.0
    last_proactive_eval_at: float = 0.0
    def silence_duration(self) -> float:
        ref = max(self.last_user_msg_at, self.last_bot_reply_at)
        return _tm.time() - ref if ref > 0 else 0.0
    def recent_user_msg_count(self, window_sec: float = 300.0) -> int:
        cutoff = _tm.time() - window_sec
        return sum(1 for ts in self.user_msg_ring if ts > cutoff)
    def mark_user_message(self) -> None:
        self.last_user_msg_at = _tm.time()
        self.user_msg_ring.append(_tm.time())
        self.consecutive_silence_ticks = 0
    def mark_bot_reply(self) -> None:
        self.last_bot_reply_at = _tm.time()
        self.total_replies += 1

# ---------------------------------------------------------------------------
#  脑力追踪器
# ---------------------------------------------------------------------------

class _StaminaTracker:
    """脑力值追踪器，支持消耗、恢复与持久化"""
    def __init__(self):
        c = _cfg()
        self._ceiling = float(c.get("stamina_ceil", 100.0))
        self._current = self._ceiling
        self._recovery_per_min = float(c.get("stamina_recovery", 2.0))
        self._last_recover_ts = _tm.time()
    def refresh_params(self) -> None:
        c = _cfg()
        self._ceiling = float(c.get("stamina_ceil", 100.0))
        self._recovery_per_min = float(c.get("stamina_recovery", 2.0))
    def level(self) -> float:
        self._tick_recovery()
        return self._current
    def try_consume(self, cost: float) -> bool:
        c = _cfg()
        floor = float(c.get("stamina_min_think", 10.0))
        self._tick_recovery()
        if self._current < floor:
            return False
        self._current = max(0.0, self._current - cost)
        return True
    def is_low(self) -> bool:
        c = _cfg()
        threshold = float(c.get("stamina_low", 20.0))
        self._tick_recovery()
        return self._current < threshold
    def _tick_recovery(self) -> None:
        now = _tm.time()
        elapsed_min = (now - self._last_recover_ts) / 60.0
        if elapsed_min <= 0:
            return
        gain = elapsed_min * self._recovery_per_min
        self._current = min(self._ceiling, self._current + gain)
        self._last_recover_ts = now
    def snapshot(self) -> Dict[str, float]:
        self._tick_recovery()
        return {
            "current": round(self._current, 1),
            "ceiling": self._ceiling,
            "ratio": round(self._current / max(1.0, self._ceiling), 3),
        }

# ---------------------------------------------------------------------------
#  社交压力计算
# ---------------------------------------------------------------------------

def compute_social_pressure(
    fatigue: float, trauma: float, annoyance: float,
    interaction_count: int,
) -> Tuple[float, bool]:
    """计算综合社交压力分（0~100）和是否急需休息"""
    c = _cfg()
    w_f = float(c.get("sp_fatigue_w", 0.4))
    w_t = float(c.get("sp_trauma_w", 0.3))
    w_a = float(c.get("sp_annoy_w", 0.2))
    w_i = float(c.get("sp_interact_w", 0.1))
    rest_thr = float(c.get("sp_rest_thr", 75.0))
    score = (
        fatigue * w_f
        + trauma * 10.0 * w_t
        + annoyance * w_a
        + min(interaction_count * 2.0, 20.0) * w_i
    )
    score = min(100.0, score)
    return (score, score > rest_thr)

# ---------------------------------------------------------------------------
#  主监控器
# ---------------------------------------------------------------------------

class IndependentMonitor:
    """后台独立监控器

    通过 start() 启动后台循环，stop() 优雅停止。
    每个 tick 依次：
      1. 检查状态超时
      2. 聚合并处理消息缓冲
      3. 检查脑力/疲劳
      4. 评估主动发言意愿
      5. 周期性心跳日志
    """
    def __init__(self):
        self._note_buffer = _NoteBuffer()
        self._agg_gate = _AggregationGate()
        self._stamina = _StaminaTracker()
        self._vitals: Dict[str, ChannelVitalRecord] = {}
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._reply_hook: Optional[Callable[..., Any]] = None
        self._watched_streams: Set[str] = set()
        self._last_decision_ts: float = 0.0
        self._heartbeat_ts: float = 0.0
        self._heartbeat_ticks: int = 0
    # ---- 频道健康档案 ----
    def _vital(self, stream_id: str) -> ChannelVitalRecord:
        if stream_id not in self._vitals:
            self._vitals[stream_id] = ChannelVitalRecord(stream_id=stream_id)
        return self._vitals[stream_id]
    # ---- 生命周期 ----
    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.get_event_loop().create_task(self._run_forever())
        logger.info("[独立监控] 已启动")
    def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
        logger.info("[独立监控] 已停止")
    @property
    def is_alive(self) -> bool:
        return self._running and self._task is not None and not self._task.done()
    # ---- 注册 ----
    def register_channel(self, channel_id: str) -> None:
        self._watched_streams.add(channel_id)
    def unregister_channel(self, channel_id: str) -> None:
        self._watched_streams.discard(channel_id)
    def set_reply_callback(self, callback: Callable[..., Any]) -> None:
        self._reply_hook = callback
    # ---- 消息入口 ----
    def feed_message(self, channel_id: str, user_id: str, text: str) -> None:
        self.register_channel(channel_id)
        note = _InboundNote(
            stream_id=channel_id, sender_id=user_id,
            body=text, arrived_at=_tm.time(),
        )
        self._note_buffer.deposit(note)
        self._agg_gate.notify(channel_id)
        self._vital(channel_id).mark_user_message()
        self._relay_user_activity(channel_id)
    # ---- 永久运行外壳（崩溃自动重启） ----
    async def _run_forever(self) -> None:
        while self._running:
            try:
                await self._tick_loop()
            except asyncio.CancelledError:
                logger.info("[独立监控] 循环取消")
                raise
            except Exception as exc:
                c = _cfg()
                delay = float(c.get("crash_delay", 3.0))
                logger.error(f"[独立监控] 循环崩溃，{delay}秒后重启: {exc}")
                await asyncio.sleep(delay)
                if self._running:
                    logger.info("[独立监控] 循环重启")
    async def _tick_loop(self) -> None:
        while self._running:
            c = _cfg()
            interval = float(c.get("tick_interval", 5.0))
            try:
                await self._single_tick()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.error(f"[独立监控] tick异常: {exc}")
            await asyncio.sleep(interval)
    async def _single_tick(self) -> None:
        streams_snap = set(self._watched_streams)
        for sid in streams_snap:
            await self._examine_stream(sid)
        self._heartbeat_ticks += 1
        self._maybe_heartbeat_log()
    # ---- 单频道处理 ----
    async def _examine_stream(self, stream_id: str) -> None:
        vital = self._vital(stream_id)
        self._inspect_phase_expiry(stream_id)
        depth = self._note_buffer.depth(stream_id)
        if depth > 0:
            if self._agg_gate.has_pending(stream_id):
                await self._agg_gate.wait_settled(stream_id)
            await self._digest_pending(stream_id)
        self._inspect_stamina(stream_id)
        await self._evaluate_proactive_desire(stream_id, vital)
        vital.consecutive_silence_ticks += 1
    def _inspect_phase_expiry(self, stream_id: str) -> None:
        try:
            from src.chat.heart_flow.phase_governor import acquire_phase_governor
            gov = acquire_phase_governor(stream_id)
            c = _cfg()
            timeout = float(c.get("idle_timeout", 300.0))
            if gov.check_expiration(timeout):
                logger.info(f"[独立监控] {stream_id} 状态过期，已回落")
                self._relay_state_shift(stream_id)
        except Exception as exc:
            logger.debug(f"[独立监控] 状态超时检查异常: {exc}")
    async def _digest_pending(self, stream_id: str) -> None:
        batch = self._note_buffer.withdraw(stream_id)
        if not batch:
            return
        merged_body = "\n".join(n.body for n in batch)
        verdict = await self._invoke_quick_verdict(stream_id, merged_body)
        vital = self._vital(stream_id)
        vital.total_decisions += 1
        if verdict and self._reply_hook:
            try:
                sent = await self._invoke_reply_hook(
                    stream_id,
                    merged_body,
                    {"kind": "reactive", "batch_size": len(batch)},
                )
                if sent:
                    vital.mark_bot_reply()
            except Exception as exc:
                logger.error(f"[独立监控] 回复回调异常: {exc}")
    async def _invoke_quick_verdict(self, stream_id: str, body: str) -> bool:
        c = _cfg()
        min_iv = float(c.get("min_decision_iv", 1.0))
        now = _tm.time()
        if now - self._last_decision_ts < min_iv:
            return False
        cost = float(c.get("stamina_cost_think", 3.0))
        if not self._stamina.try_consume(cost):
            logger.debug("[独立监控] 脑力不足，跳过决策")
            return False
        try:
            from src.chat.heart_flow.heartflow_decision import acquire_decision_maker
            maker = acquire_decision_maker()
            result = await maker.evaluate(stream_id, body)
            self._last_decision_ts = _tm.time()
            return result
        except Exception as exc:
            logger.debug(f"[独立监控] 快速决策异常: {exc}")
            return False
    def _inspect_stamina(self, stream_id: str) -> None:
        if not self._stamina.is_low():
            return
        try:
            from src.chat.heart_flow.phase_governor import acquire_phase_governor
            gov = acquire_phase_governor(stream_id)
            c = _cfg()
            threshold = float(c.get("stamina_low", 20.0))
            if gov.check_rest_trigger(threshold):
                from src.common.data_models.heartflow_models import FlowPhase
                gov.apply_decision(FlowPhase.DORMANT, "脑力不足，进入休眠")
        except Exception as exc:
            logger.debug(f"[独立监控] 脑力检查异常: {exc}")
    # ---- 主动发言评估 ----
    async def _evaluate_proactive_desire(self, stream_id: str, vital: ChannelVitalRecord) -> None:
        now = _tm.time()
        if now < vital.proactive_cooldown_until:
            return
        c = _cfg()
        min_silence = float(c.get("proactive_min_silence", 30.0))
        silence_sec = vital.silence_duration()
        if silence_sec < min_silence:
            vital.last_proactive_eval_at = now
            return
        silence_min = silence_sec / 60.0
        required_interval = self._proactive_eval_interval(silence_min)
        if (now - vital.last_proactive_eval_at) < required_interval:
            return
        vital.last_proactive_eval_at = now
        should_speak = await self._ask_proactive_verdict(stream_id, silence_min, vital)
        if should_speak:
            logger.info(f"[独立监控] {stream_id} 沉默{int(silence_min)}分钟，主动发言")
            vital.proactive_cooldown_until = now + required_interval
            await self._trigger_proactive(stream_id, silence_min, vital)
        else:
            logger.debug(f"[独立监控] {stream_id} 沉默{int(silence_min)}分钟，继续观望")
    def _proactive_eval_interval(self, silence_min: float) -> float:
        c = _cfg()
        short_min = int(c.get("proactive_silence_short", 10))
        mid_min = int(c.get("proactive_silence_mid", 30))
        long_min = int(c.get("proactive_silence_long", 60))
        iv_short = int(c.get("proactive_iv_short", 60))
        iv_mid = int(c.get("proactive_iv_mid", 300))
        iv_long = int(c.get("proactive_iv_long", 1200))
        iv_vlong = int(c.get("proactive_iv_vlong", 3600))
        if silence_min < short_min:
            return float(iv_short)
        if silence_min < mid_min:
            return float(iv_mid)
        if silence_min < long_min:
            return float(iv_long)
        return float(iv_vlong)
    async def _ask_proactive_verdict(self, stream_id: str, silence_min: float,
                                      vital: ChannelVitalRecord) -> bool:
        """请求LLM判断是否主动发言"""
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            from datetime import datetime
            now_str = datetime.now().strftime("%H:%M")
            hour = datetime.now().hour
            time_hint = ""
            if 0 <= hour <= 6:
                time_hint = "（深夜，大家可能在睡）"
            elif 23 <= hour <= 24:
                time_hint = "（很晚了）"
            recent_count = vital.recent_user_msg_count(3600)
            stamina_snap = self._stamina.snapshot()
            prompt = await global_prompt_manager.format_prompt(
                "monitor_proactive_verdict",
                now_str=now_str,
                time_hint=time_hint,
                silence_min=str(int(silence_min)),
                recent_count=str(recent_count),
                stamina_current=f"{stamina_snap['current']:.0f}",
                stamina_ceiling=f"{stamina_snap['ceiling']:.0f}",
            )
            req = LLMRequest(
                model=model_config.utils_small,
                temperature=0.2,
                max_tokens=80,
            )
            raw_resp = await req.generate_response_async(prompt)
            text = self._extract_text(raw_resp)
            return self._parse_speak_flag(text)
        except Exception as exc:
            logger.debug(f"[独立监控] 主动发言评估异常: {exc}")
            return False
    async def _trigger_proactive(self, stream_id: str, silence_min: float,
                                  vital: ChannelVitalRecord) -> None:
        """触发主动发言流程"""
        if self._reply_hook is None:
            return
        hint = f"频道已沉默约{int(silence_min)}分钟，可以自然地说点什么或继续潜水。"
        try:
            sent = await self._invoke_reply_hook(
                stream_id,
                hint,
                {
                    "kind": "proactive",
                    "silence_seconds": round(silence_min * 60.0, 1),
                    "recent_user_count": vital.recent_user_msg_count(3600),
                },
            )
            if sent:
                vital.mark_bot_reply()
        except Exception as exc:
            logger.error(f"[独立监控] 主动发言回调异常: {exc}")

    async def _invoke_reply_hook(
        self,
        stream_id: str,
        text: str,
        meta: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """统一调用外部回调，兼容同步/异步并返回是否真的发送。"""
        if self._reply_hook is None:
            return False
        result = self._reply_hook(stream_id, text, meta or {})
        if asyncio.iscoroutine(result):
            result = await result
        return bool(result)
    @staticmethod
    def _extract_text(raw_resp) -> str:
        if raw_resp is None:
            return ""
        if isinstance(raw_resp, tuple):
            return str(raw_resp[0] or "").strip() if raw_resp else ""
        if isinstance(raw_resp, dict):
            for k in ("content", "text", "message"):
                if k in raw_resp:
                    return str(raw_resp[k] or "").strip()
        return str(raw_resp).strip()
    @staticmethod
    def _parse_speak_flag(text: str) -> bool:
        import json as _json
        import re
        if not text:
            return False
        try:
            candidates = re.findall(r"\{[\s\S]*?\}", text)
            for blob in candidates:
                obj = _json.loads(blob)
                if isinstance(obj, dict) and "speak" in obj:
                    val = obj["speak"]
                    if isinstance(val, str):
                        return val.strip().lower() in {"true", "yes", "1", "是"}
                    return bool(val)
        except (ValueError, KeyError):
            pass
        lower = text.lower()
        if "true" in lower or "主动" in lower:
            return True
        return False
    # ---- 心跳日志 ----
    def _maybe_heartbeat_log(self) -> None:
        c = _cfg()
        iv = float(c.get("heartbeat_iv", 300.0))
        now = _tm.time()
        if now - self._heartbeat_ts < iv:
            return
        self._heartbeat_ts = now
        channels = len(self._watched_streams)
        stamina = self._stamina.snapshot()
        logger.info(
            f"[独立监控] 心跳: {channels}频道, "
            f"脑力{stamina['current']:.0f}/{stamina['ceiling']:.0f}, "
            f"tick#{self._heartbeat_ticks}"
        )
        self._heartbeat_ticks = 0
    # ---- 信号桥 ----
    @staticmethod
    def _relay_user_activity(stream_id: str) -> None:
        try:
            from src.chat.heart_flow.reply_decision_gateway import acquire_reply_gateway
            acquire_reply_gateway().notify_user_spoke(stream_id)
        except Exception:
            pass
    @staticmethod
    def _relay_state_shift(stream_id: str) -> None:
        try:
            from src.chat.heart_flow.heartflow_decision import acquire_decision_maker
            acquire_decision_maker().signal_activity_change(stream_id)
        except Exception:
            pass
    # ---- 诊断 ----
    def get_status(self) -> Dict[str, Any]:
        return {
            "alive": self.is_alive,
            "watched": len(self._watched_streams),
            "stamina": self._stamina.snapshot(),
            "vitals": {
                sid: {
                    "silence_sec": round(v.silence_duration(), 1),
                    "decisions": v.total_decisions,
                    "replies": v.total_replies,
                }
                for sid, v in self._vitals.items()
            },
        }

# ---------------------------------------------------------------------------
#  单例
# ---------------------------------------------------------------------------

_monitor_ref: Optional[IndependentMonitor] = None

def acquire_independent_monitor() -> IndependentMonitor:
    global _monitor_ref
    if _monitor_ref is None:
        _monitor_ref = IndependentMonitor()
    return _monitor_ref
