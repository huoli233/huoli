import asyncio
import random
import re
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple

from src.common.logger import get_logger

logger = get_logger("focus_patrol")


class FocusPatrol:
    """专注模式的消息巡查与召回技能"""

    _REVIEW_DELAY_LO: float = 1.0
    _REVIEW_DELAY_HI: float = 115.0

    def __init__(self):
        self._controller_ref = None
        self._adaptive_ref = None

    # ---- 外部模块懒加载 ----

    def _lazy_controller(self):
        if self._controller_ref is None:
            try:
                from src.modules.modcore.recall_system.recall_controller import get_recall_controller
                self._controller_ref = get_recall_controller()
            except Exception:
                self._controller_ref = False
        return self._controller_ref if self._controller_ref is not False else None

    def _lazy_adaptive(self):
        if self._adaptive_ref is None:
            try:
                from src.modules.modcore.recall_system.adaptive_recall_integrator import (
                    get_adaptive_recall_integrator,
                )
                self._adaptive_ref = get_adaptive_recall_integrator()
            except Exception:
                self._adaptive_ref = False
        return self._adaptive_ref if self._adaptive_ref is not False else None

    # ----------------------------------------------------------------
    #  预发送：是否触发召回
    # ----------------------------------------------------------------

    def should_trigger_with_psychology(
        self,
        surface_mask: float = 10.0,
        inner_chaos: float = 0.0,
        mental_fatigue: float = 0.0,
        trauma_score: float = 0.0,
    ) -> Tuple[bool, Optional[str], Dict[str, Any]]:
        """综合心理指标判断是否应触发召回机制

        返回 (是否触发, 错误类型, 附加信息)。
        """
        adapter = self._lazy_adaptive()
        if adapter:
            return adapter.should_trigger_recall(
                surface_mask, inner_chaos, mental_fatigue, trauma_score,
            )
        ctl = self._lazy_controller()
        if ctl:
            flag, err_kind = ctl.should_trigger()
            return flag, err_kind, {}
        return False, None, {}

    # ----------------------------------------------------------------
    #  预发送：执行召回流程
    # ----------------------------------------------------------------

    async def process_with_recall(
        self,
        original_text: str,
        group_id: str,
        stream_id: str,
        send_func: Callable[[str, str], Awaitable[str]],
        delete_func: Callable[[str], Awaitable[bool]],
        surface_mask: float = 10.0,
        inner_chaos: float = 0.0,
        mental_fatigue: float = 0.0,
        trauma_score: float = 0.0,
    ) -> Tuple[str, bool]:
        """在发送前走召回分支，返回 (最终文本, 是否触发了召回)"""
        adapter = self._lazy_adaptive()
        if adapter:
            text, recalled, _extra = await adapter.process_with_adaptive_recall(
                original_text=original_text,
                surface_mask=surface_mask,
                inner_chaos=inner_chaos,
                mental_fatigue=mental_fatigue,
                trauma_score=trauma_score,
                group_id=group_id,
                stream_id=stream_id,
                send_func=send_func,
                delete_func=delete_func,
            )
            return text, recalled
        ctl = self._lazy_controller()
        if ctl:
            should, err_kind = ctl.should_trigger()
            if not should or not err_kind:
                return original_text, False
            err_text, _ = await ctl.generate_error_text(original_text, err_kind, stream_id)
            msg_id = await send_func(group_id, err_text)
            await ctl.schedule_recall(
                msg_id=msg_id, group_id=group_id, original_text=original_text,
                delete_func=delete_func, send_func=send_func,
                stream_id=stream_id, error_text=err_text, error_type=err_kind,
            )
            return err_text, True
        return original_text, False

    # ----------------------------------------------------------------
    #  发送后审查
    # ----------------------------------------------------------------

    async def launch_post_send_audit(
        self,
        msg_id: str,
        channel_id: str,
        content: str,
        delete_func: Callable[[str], Awaitable[bool]],
        send_func: Optional[Callable[[str, str], Awaitable[str]]] = None,
    ):
        """在后台延迟审阅已发送的消息，必要时撤回并重写"""
        delay = random.uniform(self._REVIEW_DELAY_LO, self._REVIEW_DELAY_HI)

        async def _audit_task():
            try:
                await asyncio.sleep(delay)
                should_retract, reason = await self._audit_content(content)
                if not should_retract:
                    return
                logger.info(f"[专注巡查] {delay:.1f}s后决定撤回: {reason}")
                ok = await delete_func(msg_id)
                if ok and send_func:
                    replacement = await self._rewrite_content(content, reason)
                    if replacement:
                        await asyncio.sleep(random.uniform(1.0, 4.0))
                        await send_func(channel_id, replacement)
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.error(f"[专注巡查] 审查异常: {exc}")

        asyncio.create_task(_audit_task())

    # ---- 内部 LLM 调用 ----

    async def _audit_content(self, content: str) -> Tuple[bool, str]:
        """用 LLM 审阅内容，判断是否应该撤回"""
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            stimulus = (
                "审阅以下已发送的消息，判断是否需要撤回。\n"
                "第一行回答'是'或'否'，第二行以'理由：'开头写明原因。\n"
                f"消息内容: {content}"
            )
            req = LLMRequest(model_config.utils, request_type="focus_audit")
            raw, _ = await req.generate_response_async(stimulus)
            if not raw:
                return False, ""
            lines = raw.strip().split("\n")
            should = "是" in lines[0]
            reason = ""
            for ln in lines:
                if ln.startswith("理由"):
                    reason = ln.split("：", 1)[-1].strip()
                    break
            return should, reason
        except Exception:
            return False, ""

    async def _rewrite_content(self, original: str, reason: str) -> Optional[str]:
        """撤回后用 LLM 重写内容"""
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            stimulus = (
                "请根据撤回理由重写以下消息（50字以内）。\n"
                f"原消息: {original[:120]}\n撤回理由: {reason}"
            )
            req = LLMRequest(model_config.utils, request_type="focus_rewrite")
            raw, _ = await req.generate_response_async(stimulus, max_tokens=60, temperature=0.7)
            if not raw:
                return None
            cleaned = raw.strip()
            # 移除 <think>...</think> 标签
            think_hit = re.search(r"</think>\s*(.+)", cleaned, re.DOTALL)
            if think_hit:
                cleaned = think_hit.group(1).strip()
            return cleaned[:50] if cleaned else None
        except Exception:
            return None


# ---------------------------------------------------------------------------
#  模块单例
# ---------------------------------------------------------------------------

_patrol: Optional[FocusPatrol] = None


def acquire_focus_patrol() -> FocusPatrol:
    """获取全局 FocusPatrol 单例"""
    global _patrol
    if _patrol is None:
        _patrol = FocusPatrol()
    return _patrol
