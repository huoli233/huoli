import json
import math
import os
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Deque, Dict, List, Optional, Tuple
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config

logger = get_logger("wound_network")


class DisorderGrade(Enum):
    """心理状态等级（9 + 4 特殊）"""
    TRANQUIL = "tranquil"
    MILD_RIPPLE = "mild_ripple"
    FACADE_CRACK = "facade_crack"
    FORCED_CALM = "forced_calm"
    FACADE_TREMOR = "facade_tremor"
    PARTIAL_FRACTURE = "partial_fracture"
    HANGING_THREAD = "hanging_thread"
    EDGE_OF_ABYSS = "edge_of_abyss"
    FULL_COLLAPSE = "full_collapse"
    FLASHBACK_SURGE = "flashback_surge"
    WITHDRAWAL_SHELL = "withdrawal_shell"
    ERUPTION_BURST = "eruption_burst"
    FROZEN_VOID = "frozen_void"


@dataclass
class PsycheShard:
    """创伤碎片"""
    shard_id: str = ""
    inception_context: str = ""
    emotional_voltage: float = 0.0
    distortion_factor: float = 0.0
    recall_clarity: float = 5.0
    forged_ts: float = field(default_factory=time.time)


@dataclass
class WorldviewDamage:
    """世界观受损指标"""
    trust_quotient: float = 10.0
    reality_warp: float = 0.0
    meaning_erosion: float = 0.0
    cognitive_scatter: float = 0.0
    compromised_beliefs: List[str] = field(default_factory=list)


@dataclass
class TurmoilLedger:
    """完整创伤状态账本"""
    inner_chaos: float = 0.0
    mask_wear: float = 0.0
    surface_armor: float = 8.0
    active_grade: DisorderGrade = DisorderGrade.TRANQUIL
    shards: List[PsycheShard] = field(default_factory=list)
    worldview: WorldviewDamage = field(default_factory=WorldviewDamage)
    chaos_worldview_contrib: float = 0.0
    chaos_shard_contrib: float = 0.0
    def to_dict(self) -> Dict[str, Any]:
        return {
            "inner_chaos": round(self.inner_chaos, 4),
            "mask_wear": round(self.mask_wear, 4),
            "surface_armor": round(self.surface_armor, 4),
            "active_grade": self.active_grade.value,
            "shard_count": len(self.shards),
            "worldview": {
                "trust_quotient": round(self.worldview.trust_quotient, 2),
                "reality_warp": round(self.worldview.reality_warp, 2),
                "meaning_erosion": round(self.worldview.meaning_erosion, 2),
                "cognitive_scatter": round(self.worldview.cognitive_scatter, 2),
            },
        }


@dataclass
class MindProfile:
    """多层心理描写"""
    exterior_mask: str = ""
    aware_layer: str = ""
    buried_layer: str = ""
    echo_fragments: List[str] = field(default_factory=list)
    silent_monologue: str = ""
    somatic_signs: str = ""
    worldview_distort: str = ""
    flight_impulse: str = ""
    composed_ts: float = field(default_factory=time.time)
    source_grade: str = ""
    def to_dict(self) -> Dict[str, Any]:
        return {
            "exterior_mask": self.exterior_mask,
            "aware_layer": self.aware_layer,
            "buried_layer": self.buried_layer,
            "echo_fragments": list(self.echo_fragments),
            "silent_monologue": self.silent_monologue,
            "somatic_signs": self.somatic_signs,
            "worldview_distort": self.worldview_distort,
            "flight_impulse": self.flight_impulse,
            "source_grade": self.source_grade,
        }
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MindProfile":
        return cls(
            exterior_mask=str(data.get("exterior_mask", data.get("surface_layer", ""))),
            aware_layer=str(data.get("aware_layer", data.get("conscious_layer", ""))),
            buried_layer=str(data.get("buried_layer", data.get("subconscious_layer", ""))),
            echo_fragments=list(data.get("echo_fragments", data.get("trauma_echoes", []))),
            silent_monologue=str(data.get("silent_monologue", data.get("inner_monologue", ""))),
            somatic_signs=str(data.get("somatic_signs", data.get("physical_symptoms", ""))),
            worldview_distort=str(data.get("worldview_distort", data.get("worldview_distortion", ""))),
            flight_impulse=str(data.get("flight_impulse", data.get("escape_urge", ""))),
            source_grade=str(data.get("source_grade", data.get("source_state", ""))),
        )


@dataclass
class TriggerVerdict:
    """特殊状态触发判定"""
    fired: bool = False
    target_grade: Optional[DisorderGrade] = None
    confidence: float = 0.0
    explanation: str = ""
    judged_ts: float = field(default_factory=time.time)


@dataclass
class _TrendSample:
    chaos: float
    armor: float
    grade: DisorderGrade
    ts: float


class WoundNetwork:
    """
    创伤心理网络

    整合混乱度合成、状态映射、多层心理描写生成、
    特殊状态触发检测、碎片刺激评估、世界观冲击及趋势衰减。
    """
    _solo: Optional["WoundNetwork"] = None
    @classmethod
    def instance(cls) -> "WoundNetwork":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        if cls._solo:
            cls._solo._flush_disk()
        cls._solo = None
    def __init__(self):
        self._ledger = TurmoilLedger()
        self._timeline: Deque[_TrendSample] = deque(maxlen=500)
        self._profile_cache: Dict[str, MindProfile] = {}
        self._cooldown_map: Dict[str, float] = {}
        self._shard_eval_ts: Dict[str, float] = {}
        self._conf_cache: Dict[str, Any] = {}
        self._conf_ts: float = 0.0
        self._storage_path: str = "data/huoli/wound_state.json"
        self._refresh_conf()
        self._read_disk()
    # ---- 配置 ----
    def _refresh_conf(self) -> None:
        now = time.time()
        if now - self._conf_ts < 60.0:
            return
        hub = get_core_config()
        ps = hub.personality_sliders_block()
        self._conf_cache = {
            "chaos_sensitivity": float(ps.get("chaos_sensitivity", 0.8)),
            "mask_fatigue_rate": float(ps.get("mask_fatigue_rate", 0.3)),
            "mask_recovery_rate": float(ps.get("mask_recovery_rate", 0.05)),
            "mask_base_armor": float(ps.get("mask_base_armor", 8.0)),
            "natural_decay_per_hour": float(ps.get("chaos_natural_decay_per_hour", 0.1)),
            "profile_cache_sec": float(ps.get("profile_cache_seconds", 60.0)),
            "shard_eval_interval": float(ps.get("shard_eval_interval_sec", 120.0)),
            "trigger_confidence_floor": float(ps.get("trigger_confidence_floor", 0.6)),
            "trigger_cooldown_sec": float(ps.get("trigger_cooldown_sec", 300.0)),
            # 混乱度到等级的映射阈值
            "grade_thresholds": {
                "tranquil": float(ps.get("grade_tranquil_cap", 1.0)),
                "mild_ripple": float(ps.get("grade_mild_ripple_cap", 2.0)),
                "facade_crack": float(ps.get("grade_facade_crack_cap", 3.0)),
                "forced_calm": float(ps.get("grade_forced_calm_cap", 4.5)),
                "facade_tremor": float(ps.get("grade_facade_tremor_cap", 5.5)),
                "partial_fracture": float(ps.get("grade_partial_fracture_cap", 6.5)),
                "hanging_thread": float(ps.get("grade_hanging_thread_cap", 7.5)),
                "edge_of_abyss": float(ps.get("grade_edge_of_abyss_cap", 8.5)),
            },
            # 特殊触发阈值
            "flashback_min_chaos": float(ps.get("flashback_min_chaos", 5.0)),
            "flashback_min_shards": int(ps.get("flashback_min_shards", 1)),
            "withdrawal_min_chaos": float(ps.get("withdrawal_min_chaos", 3.0)),
            "eruption_min_chaos": float(ps.get("eruption_min_chaos", 6.0)),
            "eruption_max_armor": float(ps.get("eruption_max_armor", 4.0)),
            "frozen_min_chaos": float(ps.get("frozen_min_chaos", 9.0)),
            "frozen_max_armor": float(ps.get("frozen_max_armor", 1.5)),
        }
        self._conf_ts = now
    # ---- 状态读取 ----
    def ledger(self) -> TurmoilLedger:
        return self._ledger
    def current_grade(self) -> DisorderGrade:
        return self._ledger.active_grade
    def chaos_level(self) -> float:
        return self._ledger.inner_chaos
    # ---- 混乱度合成 ----
    def absorb_stimulus(
        self,
        severity: float,
        sentiment: str,
        sentiment_intensity: float,
        is_harassment: bool,
    ) -> TurmoilLedger:
        """
        将外部刺激的定性信号合成为混乱度变化

        参数:
            severity: 严重度 0~1
            sentiment: 情感极性 (negative/positive/neutral)
            sentiment_intensity: 情感强度 0~1
            is_harassment: 是否为骚扰
        """
        self._refresh_conf()
        sens = self._conf_cache["chaos_sensitivity"]
        fatigue_rate = self._conf_cache["mask_fatigue_rate"]
        recovery = self._conf_cache["mask_recovery_rate"]
        sev = max(0.0, min(1.0, float(severity)))
        sint = max(0.0, min(1.0, float(sentiment_intensity)))
        neg_portion = sint if sentiment == "negative" else sint * 0.15
        harass_portion = 1.0 if is_harassment else 0.0
        # 世界观贡献
        wv = self._ledger.worldview
        wv_dist = float(wv.reality_warp) + float(wv.meaning_erosion) * 0.6
        wv_scatter = float(wv.cognitive_scatter) * 0.4
        self._ledger.chaos_worldview_contrib = min(5.0, (wv_dist + wv_scatter) * 0.35)
        # 混乱度变化公式
        delta = sens * (
            0.45 * sev
            + 0.30 * harass_portion
            + 0.13 * neg_portion
            + 0.12 * self._ledger.chaos_worldview_contrib
        )
        self._ledger.inner_chaos = max(
            0.0, min(10.0, self._ledger.inner_chaos + delta - recovery * 0.02),
        )
        # 面具疲劳
        self._ledger.mask_wear = min(
            10.0, self._ledger.mask_wear + fatigue_rate * 0.01 * self._ledger.inner_chaos,
        )
        base_armor = self._conf_cache["mask_base_armor"]
        self._ledger.surface_armor = max(
            0.0, min(10.0, base_armor - self._ledger.mask_wear + recovery),
        )
        # 映射等级
        self._ledger.active_grade = self._resolve_grade(self._ledger.inner_chaos)
        # 记录时间线  
        self._timeline.append(_TrendSample(
            chaos=self._ledger.inner_chaos,
            armor=self._ledger.surface_armor,
            grade=self._ledger.active_grade,
            ts=time.time(),
        ))
        # 自然衰减
        decayed = self._compute_natural_decay(self._ledger.inner_chaos)
        if decayed != self._ledger.inner_chaos:
            self._ledger.inner_chaos = decayed
            self._ledger.active_grade = self._resolve_grade(decayed)
        self._flush_disk()
        return self._ledger
    def soothe(self, intensity: float = 0.1) -> None:
        """外部积极事件触发的冷却"""
        recovery = self._conf_cache.get("mask_recovery_rate", 0.05)
        a = max(0.0, min(1.0, intensity))
        self._ledger.inner_chaos = max(
            0.0, self._ledger.inner_chaos - a * recovery * 2.0,
        )
        self._ledger.active_grade = self._resolve_grade(self._ledger.inner_chaos)
        self._flush_disk()
    def attach_shard(self, shard: PsycheShard) -> None:
        """附加创伤碎片"""
        self._ledger.shards.append(shard)
        bonus = min(3.0, float(shard.emotional_voltage) * 0.1)
        self._ledger.chaos_shard_contrib = min(5.0, self._ledger.chaos_shard_contrib + bonus)
        self._flush_disk()
    def _resolve_grade(self, chaos: float) -> DisorderGrade:
        th = self._conf_cache.get("grade_thresholds", {})
        c = max(0.0, min(10.0, chaos))
        if c < th.get("tranquil", 1.0):
            return DisorderGrade.TRANQUIL
        if c < th.get("mild_ripple", 2.0):
            return DisorderGrade.MILD_RIPPLE
        if c < th.get("facade_crack", 3.0):
            return DisorderGrade.FACADE_CRACK
        if c < th.get("forced_calm", 4.5):
            return DisorderGrade.FORCED_CALM
        if c < th.get("facade_tremor", 5.5):
            return DisorderGrade.FACADE_TREMOR
        if c < th.get("partial_fracture", 6.5):
            return DisorderGrade.PARTIAL_FRACTURE
        if c < th.get("hanging_thread", 7.5):
            return DisorderGrade.HANGING_THREAD
        if c < th.get("edge_of_abyss", 8.5):
            return DisorderGrade.EDGE_OF_ABYSS
        return DisorderGrade.FULL_COLLAPSE
    def _compute_natural_decay(self, chaos: float) -> float:
        if not self._timeline or chaos <= 0:
            return chaos
        latest = self._timeline[-1]
        hours = (time.time() - latest.ts) / 3600.0
        if hours <= 0:
            return chaos
        rate = self._conf_cache.get("natural_decay_per_hour", 0.1)
        return max(0.0, chaos - rate * hours)
    # ---- 多层心理描写 ----
    async def compose_mind_profile(self) -> MindProfile:
        """生成当前状态的完整心理层描写"""
        cache_key = f"{self._ledger.active_grade.value}_{self._ledger.inner_chaos:.0f}_{self._ledger.surface_armor:.0f}"
        limit = self._conf_cache.get("profile_cache_sec", 60.0)
        cached = self._profile_cache.get(cache_key)
        if cached and (time.time() - cached.composed_ts) < limit:
            return cached
        shard_digest = self._condense_shards()
        wv_digest = self._condense_worldview()
        prompt = (
            f"[心理层描写任务]\n"
            f"当前状态：{self._ledger.active_grade.value}\n"
            f"混乱度：{self._ledger.inner_chaos:.1f}/10\n"
            f"面具强度：{self._ledger.surface_armor:.1f}/10\n"
            f"创伤碎片：{shard_digest}\n"
            f"世界观受损：{wv_digest}\n\n"
            f"请输出 JSON，包含以下 8 个维度的自然语言描写：\n"
            f'{{"exterior_mask": "表面伪装", "aware_layer": "意识层描写", '
            f'"buried_layer": "潜意识层描写", "echo_fragments": ["创伤回声1","创伤回声2"], '
            f'"silent_monologue": "内心独白", "somatic_signs": "躯体症状", '
            f'"worldview_distort": "世界观扭曲", "flight_impulse": "逃避冲动"}}'
        )
        raw = await self._call_llm(prompt)
        if raw:
            parsed = self._extract_json(raw)
            if parsed:
                profile = MindProfile.from_dict(parsed)
                profile.composed_ts = time.time()
                profile.source_grade = self._ledger.active_grade.value
                self._profile_cache[cache_key] = profile
                return profile
        # 兜底
        fallback = MindProfile(
            exterior_mask=f"当前状态：{self._ledger.active_grade.value}",
            source_grade=self._ledger.active_grade.value,
        )
        return fallback
    def _condense_shards(self) -> str:
        if not self._ledger.shards:
            return "无活跃碎片"
        parts = []
        for s in self._ledger.shards[:5]:
            v_tag = "低" if s.emotional_voltage < 3 else ("中" if s.emotional_voltage < 7 else "高")
            parts.append(f"[电压:{v_tag}] {s.inception_context[:60]}")
        return "；".join(parts)
    def _condense_worldview(self) -> str:
        wv = self._ledger.worldview
        parts = []
        if wv.trust_quotient < 8.0:
            parts.append(f"信任降至{wv.trust_quotient:.1f}/10")
        if wv.reality_warp > 2.0:
            parts.append(f"现实扭曲{wv.reality_warp:.1f}")
        if wv.meaning_erosion > 2.0:
            parts.append(f"意义侵蚀{wv.meaning_erosion:.1f}")
        if wv.cognitive_scatter > 2.0:
            parts.append(f"认知碎散{wv.cognitive_scatter:.1f}")
        return "；".join(parts) if parts else "世界观基本完好"
    # ---- 特殊状态触发检测 ----
    async def probe_special_trigger(
        self,
        recent_dialogue: str = "",
    ) -> TriggerVerdict:
        """检测是否应触发特殊创伤状态"""
        empty = TriggerVerdict(fired=False)
        shard_count = len(self._ledger.shards)
        if not self._precheck_trigger_eligible(shard_count):
            return empty
        prompt = (
            f"[特殊创伤状态评估]\n"
            f"混乱度：{self._ledger.inner_chaos:.1f}/10\n"
            f"面具强度：{self._ledger.surface_armor:.1f}/10\n"
            f"基准等级：{self._ledger.active_grade.value}\n"
            f"碎片数量：{shard_count}\n"
            f"最近对话：{recent_dialogue[:1000]}\n\n"
            f"可能触发的特殊状态：闪回发作、回避退缩、应激爆发、冻结虚空\n"
            f"请判断是否应触发。输出 JSON：\n"
            f'{{"should_trigger": true/false, "target_state": "状态名", '
            f'"confidence": 0.0到1.0, "rationale": "理由"}}'
        )
        raw = await self._call_llm(prompt)
        if not raw:
            return empty
        parsed = self._extract_json(raw)
        if not parsed:
            return empty
        should = parsed.get("should_trigger", False)
        confidence = max(0.0, min(1.0, float(parsed.get("confidence", 0.0))))
        floor = self._conf_cache.get("trigger_confidence_floor", 0.6)
        if not should or confidence < floor:
            return TriggerVerdict(
                fired=False, confidence=confidence,
                explanation=parsed.get("rationale", ""),
            )
        target_name = str(parsed.get("target_state", ""))
        target_grade = self._map_special_name(target_name)
        if not target_grade:
            return empty
        cooldown = self._conf_cache.get("trigger_cooldown_sec", 300.0)
        if self._on_cooldown(target_grade.value, cooldown):
            return TriggerVerdict(fired=False, explanation="冷却中")
        self._cooldown_map[target_grade.value] = time.time()
        logger.info(
            f"[伤网] 触发特殊状态 {target_grade.value} | 置信={confidence:.2f}"
        )
        return TriggerVerdict(
            fired=True,
            target_grade=target_grade,
            confidence=confidence,
            explanation=parsed.get("rationale", ""),
        )
    def _precheck_trigger_eligible(self, shard_count: int) -> bool:
        chaos = self._ledger.inner_chaos
        armor = self._ledger.surface_armor
        c = self._conf_cache
        if chaos >= c["flashback_min_chaos"] and shard_count >= c["flashback_min_shards"]:
            return True
        if chaos >= c["withdrawal_min_chaos"]:
            return True
        if chaos >= c["eruption_min_chaos"] and armor <= c["eruption_max_armor"]:
            return True
        if chaos >= c["frozen_min_chaos"] and armor <= c["frozen_max_armor"]:
            return True
        return False
    def _on_cooldown(self, key: str, limit: float) -> bool:
        last = self._cooldown_map.get(key, 0.0)
        return (time.time() - last) < limit
    @staticmethod
    def _map_special_name(name: str) -> Optional[DisorderGrade]:
        mapping = {
            "闪回发作": DisorderGrade.FLASHBACK_SURGE,
            "flashback": DisorderGrade.FLASHBACK_SURGE,
            "回避退缩": DisorderGrade.WITHDRAWAL_SHELL,
            "avoidance": DisorderGrade.WITHDRAWAL_SHELL,
            "应激爆发": DisorderGrade.ERUPTION_BURST,
            "outbreak": DisorderGrade.ERUPTION_BURST,
            "冻结虚空": DisorderGrade.FROZEN_VOID,
            "dazed": DisorderGrade.FROZEN_VOID,
        }
        return mapping.get(name.lower().strip())
    # ---- 碎片刺激评估 ----
    async def evaluate_shard_stimulus(
        self,
        content: str,
        context: Dict[str, Any],
    ) -> Optional[PsycheShard]:
        """评估内容是否构成新的创伤碎片"""
        stream_key = str(context.get("stream_id", "global"))
        interval = self._conf_cache.get("shard_eval_interval", 120.0)
        now = time.time()
        last = self._shard_eval_ts.get(stream_key, 0.0)
        if interval > 0 and (now - last) < interval:
            return None
        self._shard_eval_ts[stream_key] = now
        prompt = (
            f"[碎片刺激评估]\n"
            f"输入内容：{content[:2000]}\n"
            f"上下文：{str(context)[:500]}\n\n"
            f"请判断此内容是否构成可记录的创伤刺激。输出 JSON：\n"
            f'{{"should_record": true/false, "emotional_charge": 0到10, '
            f'"distortion_level": 0到10, "memory_clarity": 0到10, '
            f'"semantic_context": "语义描述"}}'
        )
        raw = await self._call_llm(prompt)
        if not raw:
            return None
        parsed = self._extract_json(raw)
        if not parsed or not parsed.get("should_record", False):
            return None
        shard = PsycheShard(
            shard_id=uuid.uuid4().hex[:16],
            inception_context=str(parsed.get("semantic_context", ""))[:800],
            emotional_voltage=max(0.0, min(10.0, float(parsed.get("emotional_charge", 0.0)))),
            distortion_factor=max(0.0, min(10.0, float(parsed.get("distortion_level", 0.0)))),
            recall_clarity=max(0.0, min(10.0, float(parsed.get("memory_clarity", 5.0)))),
        )
        self.attach_shard(shard)
        logger.info(f"[伤网] 新碎片 | 电压={shard.emotional_voltage:.1f} 扭曲={shard.distortion_factor:.1f}")
        return shard
    # ---- 世界观冲击 ----
    def apply_worldview_impact(
        self,
        trust_delta: float = 0.0,
        warp_delta: float = 0.0,
        erosion_delta: float = 0.0,
        scatter_delta: float = 0.0,
        belief_damage: Optional[str] = None,
    ) -> None:
        """更新世界观受损指标"""
        wv = self._ledger.worldview
        wv.trust_quotient = max(0.0, min(10.0, wv.trust_quotient + trust_delta))
        wv.reality_warp = max(0.0, min(10.0, wv.reality_warp + warp_delta))
        wv.meaning_erosion = max(0.0, min(10.0, wv.meaning_erosion + erosion_delta))
        wv.cognitive_scatter = max(0.0, min(10.0, wv.cognitive_scatter + scatter_delta))
        if belief_damage and belief_damage not in wv.compromised_beliefs:
            wv.compromised_beliefs.append(belief_damage)
            if len(wv.compromised_beliefs) > 10:
                wv.compromised_beliefs = wv.compromised_beliefs[-10:]
        self._flush_disk()
    # ---- 趋势分析 ----
    def recent_trend(self, window_sec: float = 3600.0) -> str:
        """分析近期混乱度趋势"""
        cutoff = time.time() - window_sec
        recent = [s for s in self._timeline if s.ts > cutoff]
        if len(recent) < 2:
            return "stable"
        first_half = recent[:len(recent)//2]
        second_half = recent[len(recent)//2:]
        avg_first = sum(s.chaos for s in first_half) / len(first_half)
        avg_second = sum(s.chaos for s in second_half) / len(second_half)
        diff = avg_second - avg_first
        if diff > 1.5:
            return "escalating"
        if diff < -1.5:
            return "recovering"
        return "stable"
    # ---- 持久化 ----
    def _flush_disk(self) -> None:
        try:
            os.makedirs(os.path.dirname(self._storage_path) or ".", exist_ok=True)
            payload = {
                "inner_chaos": self._ledger.inner_chaos,
                "mask_wear": self._ledger.mask_wear,
                "surface_armor": self._ledger.surface_armor,
                "active_grade": self._ledger.active_grade.value,
                "worldview": {
                    "trust_quotient": self._ledger.worldview.trust_quotient,
                    "reality_warp": self._ledger.worldview.reality_warp,
                    "meaning_erosion": self._ledger.worldview.meaning_erosion,
                    "cognitive_scatter": self._ledger.worldview.cognitive_scatter,
                    "compromised_beliefs": self._ledger.worldview.compromised_beliefs,
                },
                "shard_count": len(self._ledger.shards),
                "flushed_at": time.time(),
            }
            with open(self._storage_path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, indent=2)
        except (OSError, TypeError) as exc:
            logger.debug(f"[伤网] 磁盘写入失败: {exc}")
    def _read_disk(self) -> None:
        if not os.path.exists(self._storage_path):
            return
        try:
            with open(self._storage_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            self._ledger.inner_chaos = float(data.get("inner_chaos", 0.0))
            self._ledger.mask_wear = float(data.get("mask_wear", 0.0))
            self._ledger.surface_armor = float(data.get("surface_armor", 8.0))
            grade_str = data.get("active_grade", "tranquil")
            try:
                self._ledger.active_grade = DisorderGrade(grade_str)
            except ValueError:
                self._ledger.active_grade = DisorderGrade.TRANQUIL
            wv_data = data.get("worldview", {})
            if isinstance(wv_data, dict):
                self._ledger.worldview.trust_quotient = float(wv_data.get("trust_quotient", 10.0))
                self._ledger.worldview.reality_warp = float(wv_data.get("reality_warp", 0.0))
                self._ledger.worldview.meaning_erosion = float(wv_data.get("meaning_erosion", 0.0))
                self._ledger.worldview.cognitive_scatter = float(wv_data.get("cognitive_scatter", 0.0))
                self._ledger.worldview.compromised_beliefs = list(wv_data.get("compromised_beliefs", []))
        except (json.JSONDecodeError, OSError, TypeError) as exc:
            logger.debug(f"[伤网] 磁盘读取失败: {exc}")
    # ---- LLM ----
    async def _call_llm(self, prompt: str) -> Optional[str]:
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            req = LLMRequest(model_config.focus_chat, request_type="wound_network")
            text, _ = await req.generate_response_async(prompt, max_tokens=800)
            return text
        except Exception as exc:
            logger.error(f"[伤网] LLM 失败: {exc}")
            return None
    @staticmethod
    def _extract_json(raw: str) -> Optional[Dict]:
        import re
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return None
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            try:
                fixed = re.sub(r",\s*}", "}", match.group())
                return json.loads(fixed)
            except Exception:
                return None
    def collect_metrics(self) -> Dict[str, Any]:
        return {
            "chaos": round(self._ledger.inner_chaos, 2),
            "armor": round(self._ledger.surface_armor, 2),
            "grade": self._ledger.active_grade.value,
            "shard_count": len(self._ledger.shards),
            "trend": self.recent_trend(),
            "timeline_samples": len(self._timeline),
        }


def get_wound_network() -> WoundNetwork:
    """获取全局创伤心理网络实例"""
    return WoundNetwork.instance()
