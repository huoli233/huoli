import asyncio
import time as _tm
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from src.common.logger import get_logger

logger = get_logger("flow_planner")


# ---------------------------------------------------------------------------
#  校准快照（由 system_calibration 回调注入）
# ---------------------------------------------------------------------------

@dataclass
class _CalibrationSnapshot:
    """flow_planner 侧保存的最近一次校准结果"""
    offline_hours: float = 0.0
    calibration_level: str = "无"
    intimacy_after: float = 50.0
    emotion_after: float = 50.0
    fatigue_after: float = 0.0
    forget_prob: float = 0.0
    updated_at: float = 0.0

    def is_recent(self, max_age_sec: float = 600.0) -> bool:
        """10分钟内的校准视为有效"""
        return self.updated_at > 0.0 and (_tm.time() - self.updated_at) < max_age_sec

    @property
    def proactive_penalty(self) -> float:
        """离线回来后主动发言应更保守，返回一个 0~1 的惩罚系数"""
        if self.calibration_level == "重度":
            return 0.7
        if self.calibration_level == "中度":
            return 0.3
        return 0.0


# ---------------------------------------------------------------------------
#  情境分类
# ---------------------------------------------------------------------------

class SituationKind(Enum):
    """对话情境大类"""
    CASUAL = "闲聊"
    QUESTION = "提问"
    EMOTIONAL = "情感倾诉"
    REQUEST = "请求帮助"
    GROUP_TOPIC = "群聊热议"
    GREETING = "寒暄"
    FAREWELL = "告别"
    OFFENSIVE = "攻击性"
    UNKNOWN = "未知"


# ---------------------------------------------------------------------------
#  规划结果
# ---------------------------------------------------------------------------

@dataclass
class PlannerOutput:
    """规划器输出"""
    situation: SituationKind = SituationKind.UNKNOWN
    reply_strategy: str = ""
    emotion_hint: str = ""
    should_recall_memory: bool = False
    suggested_length: int = 100
    extra_notes: str = ""


# ---------------------------------------------------------------------------
#  情境快速分类（关键词预判）
# ---------------------------------------------------------------------------

_KEYWORD_RULES: Dict[SituationKind, List[str]] = {
    SituationKind.GREETING: ["你好", "hi", "hello", "早", "晚安", "嗨"],
    SituationKind.FAREWELL: ["再见", "拜拜", "bye", "下线", "走了"],
    SituationKind.QUESTION: ["吗", "？", "怎么", "为什么", "什么", "如何", "能不能"],
    SituationKind.OFFENSIVE: ["傻", "滚", "垃圾", "sb", "nmsl"],
}


def _quick_classify(text: str) -> Optional[SituationKind]:
    """基于关键词做粗粒度预判"""
    lower = text.lower().strip()
    for kind, keywords in _KEYWORD_RULES.items():
        for kw in keywords:
            if kw in lower:
                return kind
    return None


# ---------------------------------------------------------------------------
#  LLM 规划 Prompt — 从统一目录取用
# ---------------------------------------------------------------------------

import src.chat.prompts.catalog  # noqa: F401 注册提示词
from src.chat.utils.prompt_builder import global_prompt_manager


# ---------------------------------------------------------------------------
#  规划器
# ---------------------------------------------------------------------------

class FlowPlanner:
    """心流规划器

    两种路径:
      generate_reactive_plan  — 被动回复规划
      generate_proactive_plan — 主动发言规划
    """

    def __init__(self):
        self._invoke_lock = asyncio.Lock()
        self._cal_snapshot = _CalibrationSnapshot()

    # ---- 校准联动 ----

    def apply_calibration(self, summary) -> None:
        """由 system_calibration 回调注入校准结果。

        summary 应具备 offline_seconds, level, intimacy_delta,
        emotion_delta, fatigue_delta, memory_forget_probability 属性。
        """
        hours = getattr(summary, "offline_seconds", 0.0) / 3600.0
        self._cal_snapshot = _CalibrationSnapshot(
            offline_hours=hours,
            calibration_level=getattr(summary, "level", "无"),
            intimacy_after=50.0 + getattr(summary, "intimacy_delta", 0.0),
            emotion_after=50.0 + getattr(summary, "emotion_delta", 0.0),
            fatigue_after=getattr(summary, "fatigue_delta", 0.0),
            forget_prob=getattr(summary, "memory_forget_probability", 0.0),
            updated_at=_tm.time(),
        )
        logger.info(
            f"[流程规划] 收到校准快照: "
            f"离线{hours:.1f}h 级别={self._cal_snapshot.calibration_level} "
            f"亲密度={self._cal_snapshot.intimacy_after:.1f} "
            f"情绪={self._cal_snapshot.emotion_after:.1f}"
        )

    # ---- 被动规划 ----

    async def generate_reactive_plan(
        self,
        channel_id: str,
        recent_messages: str,
        *,
        extra_context: str = "",
    ) -> PlannerOutput:
        """根据最近消息生成被动回复策略"""
        quick_kind = _quick_classify(recent_messages[-200:] if recent_messages else "")
        if quick_kind in (SituationKind.GREETING, SituationKind.FAREWELL):
            return PlannerOutput(
                situation=quick_kind,
                reply_strategy="礼貌回应" if quick_kind == SituationKind.GREETING else "友好告别",
                emotion_hint="温和",
                suggested_length=30,
            )
        return await self._llm_plan(channel_id, recent_messages, quick_kind)

    async def _llm_plan(
        self,
        channel_id: str,
        messages: str,
        quick_kind: Optional[SituationKind],
    ) -> PlannerOutput:
        """调用LLM规划"""
        import json as _json
        from datetime import datetime
        prompt = await global_prompt_manager.format_prompt(
            "flow_planner_plan",
            time=datetime.now().strftime("%H:%M"),
            channel=channel_id,
            quick_kind=quick_kind.value if quick_kind else "未知",
            messages=messages[:2500],
        )
        raw = await self._invoke_model(prompt)
        return self._parse_plan(raw)

    # ---- 主动规划 ----

    async def generate_proactive_plan(
        self,
        channel_id: str,
        quiet_seconds: float,
        recent_topic: str = "",
        mood: str = "平静",
    ) -> Optional[PlannerOutput]:
        """判断是否适合主动发言并生成策略

        校准后亲密度过低时主动发言概率降低。
        """
        import json as _json
        from datetime import datetime

        # 校准惩罚：亲密度低于 30 时直接拒绝主动发言
        snap = self._cal_snapshot
        if snap.is_recent() and snap.intimacy_after < 30.0:
            logger.info(
                f"[流程规划] {channel_id} 亲密度过低"
                f"({snap.intimacy_after:.1f})，拒绝主动发言"
            )
            return None

        calibration_hint = ""
        if snap.is_recent() and snap.calibration_level != "无":
            calibration_hint = (
                f"机器人刚刚离线了 {snap.offline_hours:.1f} 小时，"
                f"当前亲密度 {snap.intimacy_after:.0f}，"
                f"情绪指数 {snap.emotion_after:.0f}。\n"
            )

        prompt = await global_prompt_manager.format_prompt(
            "flow_planner_proactive",
            quiet_sec=quiet_seconds,
            channel=channel_id,
            topic=recent_topic or "无",
            mood=mood,
            calibration_hint=calibration_hint,
        )
        raw = await self._invoke_model(prompt)
        return self._parse_proactive(raw)

    # ---- LLM 调用 ----

    async def _invoke_model(self, prompt: str) -> str:
        """调用轻量模型"""
        async with self._invoke_lock:
            try:
                from src.llm_models.utils_model import LLMRequest
                from src.config.config import model_config
                req = LLMRequest(
                    model=model_config.utils_small,
                    temperature=0.3,
                    max_tokens=200,
                )
                result = await req.generate_response_async(prompt)
                return result.strip() if result else ""
            except Exception as exc:
                logger.error(f"[流程规划] LLM调用异常: {exc}")
                return ""

    # ---- 解析 ----

    @staticmethod
    def _extract_json(raw: str) -> Optional[dict]:
        """从LLM文本中提取JSON对象"""
        import json as _json
        if not raw:
            return None
        left = raw.find("{")
        right = raw.rfind("}") + 1
        if left < 0 or right <= left:
            return None
        try:
            return _json.loads(raw[left:right])
        except (ValueError, KeyError):
            return None

    def _parse_plan(self, raw: str) -> PlannerOutput:
        """解析被动规划结果"""
        obj = self._extract_json(raw)
        if not obj:
            return PlannerOutput(reply_strategy="通用回复", emotion_hint="中性")
        kind_map = {k.value: k for k in SituationKind}
        sit_str = obj.get("situation", "未知")
        return PlannerOutput(
            situation=kind_map.get(sit_str, SituationKind.UNKNOWN),
            reply_strategy=str(obj.get("strategy", "")),
            emotion_hint=str(obj.get("emotion_hint", "")),
            should_recall_memory=bool(obj.get("recall_memory", False)),
            suggested_length=int(obj.get("suggested_length", 100)),
        )

    def _parse_proactive(self, raw: str) -> Optional[PlannerOutput]:
        """解析主动规划结果"""
        obj = self._extract_json(raw)
        if not obj:
            return None
        if not obj.get("should_speak", False):
            return None
        return PlannerOutput(
            situation=SituationKind.CASUAL,
            reply_strategy=str(obj.get("opening", "")),
            emotion_hint=str(obj.get("emotion_hint", "平静")),
            extra_notes=str(obj.get("topic", "")),
            suggested_length=80,
        )

    # ---- 情境分类快捷方法 ----

    def classify_situation(self, text: str) -> SituationKind:
        """纯关键词分类（不调用LLM）"""
        kind = _quick_classify(text)
        return kind if kind else SituationKind.UNKNOWN


# ---------------------------------------------------------------------------
#  单例
# ---------------------------------------------------------------------------

_planner_ref: Optional[FlowPlanner] = None


def acquire_flow_planner() -> FlowPlanner:
    global _planner_ref
    if _planner_ref is None:
        _planner_ref = FlowPlanner()
    return _planner_ref
