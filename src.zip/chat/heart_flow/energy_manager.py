import time
from typing import Any, Dict, Optional, Tuple
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config
from src.common.data_models.heartflow_models import EnergySnapshot

logger = get_logger("vitality_pool")


class VitalityPoolManager:
    """
    双池能量管理器
    融合聊天值（chat_pool）与脑力值（brain_pool），统一管理消耗、恢复、疲劳和烦恼。
    所有数值参数来自 CoreSettingsHub，禁止硬编码。
    职责边界：只管能量状态，不决定是否回复。
    """
    _solo: Optional["VitalityPoolManager"] = None
    @classmethod
    def instance(cls) -> "VitalityPoolManager":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        if cls._solo is not None:
            cls._solo._channel_snapshots.clear()
        cls._solo = None
    def __init__(self):
        self._channel_snapshots: Dict[str, EnergySnapshot] = {}
        self._cfg_cache: Optional[Dict[str, Any]] = None
        self._cfg_ts: float = 0.0
    def _load_cfg(self) -> Dict[str, Any]:
        """从核心配置引擎读取双池能量参数，缓存60秒"""
        now = time.time()
        if self._cfg_cache is not None and (now - self._cfg_ts) < 60:
            return self._cfg_cache
        hub = get_core_config()
        block = hub.dual_pool_energy()
        self._cfg_cache = block
        self._cfg_ts = now
        return block
    def _chat_cfg(self) -> Dict[str, Any]:
        return self._load_cfg().get("chat_value", {})
    def _brain_cfg(self) -> Dict[str, Any]:
        return self._load_cfg().get("brain_power", {})
    def _decay_cfg(self) -> Dict[str, Any]:
        return self._load_cfg().get("decay", {})
    def _fatigue_cfg(self) -> Dict[str, Any]:
        hub = get_core_config()
        return hub.fatigue_penalty()
    def _ensure_channel(self, channel_id: str) -> EnergySnapshot:
        """确保频道有快照，不存在则创建满值"""
        if channel_id not in self._channel_snapshots:
            cc = self._chat_cfg()
            bc = self._brain_cfg()
            ceiling_chat = float(cc.get("max", 0))
            ceiling_brain = float(bc.get("max", 0))
            self._channel_snapshots[channel_id] = EnergySnapshot(
                chat_pool=ceiling_chat,
                chat_ceiling=ceiling_chat,
                brain_pool=ceiling_brain,
                brain_ceiling=ceiling_brain,
                fatigue_level=0.0,
                annoyance_level=0.0,
                captured_at=time.time(),
            )
        return self._channel_snapshots[channel_id]
    def _tick_recovery(self, snap: EnergySnapshot) -> None:
        """按经过时间恢复能量并衰减疲劳/烦恼"""
        now = time.time()
        if snap.captured_at <= 0:
            snap.captured_at = now
            return
        dc = self._decay_cfg()
        min_interval = float(dc.get("min_recovery_interval", 0))
        elapsed_min = (now - snap.captured_at) / 60.0
        if min_interval > 0 and elapsed_min < min_interval / 60.0:
            return
        cc = self._chat_cfg()
        bc = self._brain_cfg()
        chat_recovery_rate = float(cc.get("recovery_rate", 0))
        brain_recovery_rate = float(bc.get("recovery_rate", 0))
        fatigue_decay = float(dc.get("fatigue_rate", 0))
        annoyance_decay = float(dc.get("annoyance_rate", 0))
        snap.chat_pool = min(snap.chat_ceiling, snap.chat_pool + elapsed_min * chat_recovery_rate)
        snap.brain_pool = min(snap.brain_ceiling, snap.brain_pool + elapsed_min * brain_recovery_rate * 60)
        if fatigue_decay > 0:
            snap.fatigue_level = max(0.0, snap.fatigue_level - elapsed_min * fatigue_decay)
        if annoyance_decay > 0:
            snap.annoyance_level = max(0.0, snap.annoyance_level - elapsed_min * annoyance_decay)
        snap.captured_at = now
    def capture_snapshot(self, channel_id: str) -> EnergySnapshot:
        """获取频道的实时能量快照（已计算恢复）"""
        snap = self._ensure_channel(channel_id)
        self._tick_recovery(snap)
        return snap
    def deplete_on_reply(self, channel_id: str, content_length: int = 0) -> Dict[str, Any]:
        """回复消耗：扣 chat_pool 和 brain_pool"""
        snap = self._ensure_channel(channel_id)
        self._tick_recovery(snap)
        cc = self._chat_cfg()
        bc = self._brain_cfg()
        chat_cost = float(cc.get("cost_base", 0))
        brain_cost = float(bc.get("cost_reply", 0))
        if content_length > 100:
            brain_cost += (content_length - 100) * 0.01
        snap.chat_pool = max(0.0, snap.chat_pool - chat_cost)
        snap.brain_pool = max(0.0, snap.brain_pool - brain_cost)
        fc = self._fatigue_cfg()
        fatigue_add = float(fc.get("reply_fatigue_add", 0))
        snap.fatigue_level = min(100.0, snap.fatigue_level + fatigue_add)
        logger.debug(
            f"[{channel_id[:8]}] 回复消耗: chat-{chat_cost:.1f} brain-{brain_cost:.1f}"
        )
        return {
            "chat_pool": snap.chat_pool,
            "brain_pool": snap.brain_pool,
            "chat_cost": chat_cost,
            "brain_cost": brain_cost,
        }
    def deplete_on_think(self, channel_id: str) -> Dict[str, Any]:
        """思考消耗：仅扣 brain_pool"""
        snap = self._ensure_channel(channel_id)
        self._tick_recovery(snap)
        bc = self._brain_cfg()
        brain_cost = float(bc.get("cost_think", 0))
        snap.brain_pool = max(0.0, snap.brain_pool - brain_cost)
        return {"brain_pool": snap.brain_pool, "brain_cost": brain_cost}
    def deplete_on_glance(self, channel_id: str) -> Dict[str, Any]:
        """窥屏消耗：仅扣少量 chat_pool"""
        snap = self._ensure_channel(channel_id)
        self._tick_recovery(snap)
        cc = self._chat_cfg()
        chat_cost = float(cc.get("cost_peek", 0))
        snap.chat_pool = max(0.0, snap.chat_pool - chat_cost)
        return {"chat_pool": snap.chat_pool, "chat_cost": chat_cost}
    def replenish_on_input(self, channel_id: str, is_repeat: bool = False) -> Dict[str, Any]:
        """用户消息后：少量回血 + 可能增烦恼"""
        snap = self._ensure_channel(channel_id)
        self._tick_recovery(snap)
        cc = self._chat_cfg()
        bonus = float(cc.get("cost_base", 0)) * 0.1
        snap.chat_pool = min(snap.chat_ceiling, snap.chat_pool + bonus)
        if is_repeat:
            fc = self._fatigue_cfg()
            annoyance_add = float(fc.get("repeat_annoyance_add", 0))
            fatigue_add = float(fc.get("repeat_fatigue_add", 0))
            snap.annoyance_level = min(100.0, snap.annoyance_level + annoyance_add)
            snap.fatigue_level = min(100.0, snap.fatigue_level + fatigue_add)
        return {"chat_pool": snap.chat_pool, "annoyance": snap.annoyance_level}
    def apply_rest_bonus(self, channel_id: str, rest_minutes: float = 0.0) -> Dict[str, Any]:
        """休息恢复：大量回血并缓解疲劳"""
        snap = self._ensure_channel(channel_id)
        cc = self._chat_cfg()
        recovery_rate = float(cc.get("recovery_rate", 0))
        recovery = rest_minutes * recovery_rate * 2
        snap.chat_pool = min(snap.chat_ceiling, snap.chat_pool + recovery)
        snap.brain_pool = min(snap.brain_ceiling, snap.brain_pool + recovery)
        snap.fatigue_level = max(0.0, snap.fatigue_level - rest_minutes * 5)
        snap.annoyance_level = max(0.0, snap.annoyance_level - rest_minutes * 3)
        snap.captured_at = time.time()
        logger.debug(f"[{channel_id[:8]}] 休息回血: +{recovery:.1f}")
        return {"chat_pool": snap.chat_pool, "brain_pool": snap.brain_pool}
    def compute_eagerness(self, channel_id: str) -> Tuple[float, str]:
        """
        计算回复意愿度（0.05 ~ 1.0）和原因说明。
        综合 chat_ratio、brain_ratio、疲劳、烦恼。
        """
        snap = self.capture_snapshot(channel_id)
        chat_factor = snap.chat_ratio()
        brain_factor = snap.brain_ratio()
        fc = self._fatigue_cfg()
        fatigue_cap = float(fc.get("fatigue_penalty_max", 0))
        annoyance_cap = float(fc.get("annoyance_penalty_max", 0))
        fatigue_penalty = min(snap.fatigue_level / 100.0, fatigue_cap)
        annoyance_penalty = min(snap.annoyance_level / 100.0, annoyance_cap)
        raw = chat_factor * brain_factor - fatigue_penalty - annoyance_penalty
        eagerness = max(0.05, min(1.0, raw))
        reasons = []
        if snap.chat_pool < snap.chat_ceiling * 0.3:
            reasons.append(f"聊天值低({snap.chat_pool:.0f})")
        if snap.brain_pool < snap.brain_ceiling * 0.3:
            reasons.append(f"脑力不足({snap.brain_pool:.0f})")
        if snap.fatigue_level > 50:
            reasons.append(f"疲劳({snap.fatigue_level:.0f})")
        if snap.annoyance_level > 30:
            reasons.append(f"烦躁({snap.annoyance_level:.0f})")
        reason = " | ".join(reasons) if reasons else "状态良好"
        return eagerness, reason
    def suggest_brevity(self, channel_id: str) -> Tuple[str, str]:
        """
        建议回复长度档位。
        压力越大回复越短。
        """
        snap = self.capture_snapshot(channel_id)
        pressure = (
            snap.fatigue_level * 0.6
            + snap.annoyance_level * 0.4
            - snap.chat_pool * 0.2
            - snap.brain_pool * 0.2
        )
        pressure = max(0, min(100, pressure))
        if pressure < 20:
            return "normal", "正常长度(8-20字)"
        elif pressure < 40:
            return "moderate", "适中长度(5-15字)"
        elif pressure < 60:
            return "brief", "简短(3-10字)"
        elif pressure < 80:
            return "minimal", "极简(2-6字)"
        return "ultra_minimal", "超短(1-3字)"
    def force_rest(self, channel_id: str, minutes: float = 0.0) -> None:
        """强制设置休息并立即应用恢复"""
        snap = self._ensure_channel(channel_id)
        if minutes > 0:
            self.apply_rest_bonus(channel_id, rest_minutes=minutes)
        snap.captured_at = time.time()
        logger.info(f"[{channel_id[:8]}] 强制休息 {minutes:.1f}分钟")
    def force_recover(self, channel_id: str, amount: float = 0.0) -> None:
        """强制注入能量"""
        snap = self._ensure_channel(channel_id)
        snap.chat_pool = min(snap.chat_ceiling, snap.chat_pool + amount)
        snap.brain_pool = min(snap.brain_ceiling, snap.brain_pool + amount)
    def status_report(self, channel_id: str) -> Dict[str, Any]:
        """完整状态报告"""
        snap = self.capture_snapshot(channel_id)
        eagerness, reason = self.compute_eagerness(channel_id)
        brevity_level, brevity_desc = self.suggest_brevity(channel_id)
        return {
            "channel_id": channel_id,
            "chat_pool": round(snap.chat_pool, 1),
            "chat_ceiling": round(snap.chat_ceiling, 0),
            "brain_pool": round(snap.brain_pool, 1),
            "brain_ceiling": round(snap.brain_ceiling, 0),
            "chat_ratio": round(snap.chat_ratio(), 2),
            "brain_ratio": round(snap.brain_ratio(), 2),
            "fatigue": round(snap.fatigue_level, 1),
            "annoyance": round(snap.annoyance_level, 1),
            "eagerness": round(eagerness, 2),
            "eagerness_reason": reason,
            "brevity_level": brevity_level,
            "brevity_desc": brevity_desc,
            "exhausted": snap.is_exhausted(),
        }
    def bulk_status(self) -> Dict[str, Dict[str, Any]]:
        return {cid: self.status_report(cid) for cid in self._channel_snapshots}
    def on_long_message_sent(self, channel_id: str, content: str = "") -> None:
        """长消息额外脑力消耗"""
        if len(content) <= 100:
            return
        snap = self._ensure_channel(channel_id)
        extra_cost = (len(content) - 100) * 0.01
        snap.brain_pool = max(0.0, snap.brain_pool - extra_cost)
    def compute_fatigue_penalty(self, channel_id: str) -> float:
        """
        综合疲劳惩罚系数 0~1。
        融合频率疲劳 + 烦恼 + 能量缺口。
        """
        snap = self.capture_snapshot(channel_id)
        fc = self._fatigue_cfg()
        fatigue_max = float(fc.get("fatigue_penalty_max", 0))
        annoyance_max = float(fc.get("annoyance_penalty_max", 0))
        fatigue_norm = min(1.0, snap.fatigue_level / 100.0)
        annoyance_norm = min(1.0, snap.annoyance_level / 100.0)
        energy_gap = 1.0 - min(snap.chat_ratio(), snap.brain_ratio())
        f_penalty = fatigue_max * fatigue_norm
        a_penalty = annoyance_max * annoyance_norm
        gap_penalty = energy_gap * 0.2
        total = f_penalty + a_penalty + gap_penalty
        return max(0.0, min(1.0, total))

    def persist_channel_energy(self, channel_id: str) -> None:
        """将指定频道的能量快照持久化到 persistent_state_db"""
        snap = self._channel_snapshots.get(channel_id)
        if snap is None:
            return
        payload = {
            "chat_pool": snap.chat_pool,
            "chat_ceiling": snap.chat_ceiling,
            "brain_pool": snap.brain_pool,
            "brain_ceiling": snap.brain_ceiling,
            "fatigue": snap.fatigue_level,
            "annoyance": snap.annoyance_level,
            "saved_at": time.time(),
        }
        try:
            from src.chat.heart_flow.persistent_state_db import acquire_persistent_store
            acquire_persistent_store().set_state("energy", channel_id, payload)
        except Exception as exc:
            logger.debug(f"[{channel_id[:8]}] 能量持久化失败: {exc}")

    def restore_channel_energy(self, channel_id: str) -> bool:
        """从 persistent_state_db 恢复频道能量快照，成功返回 True"""
        try:
            from src.chat.heart_flow.persistent_state_db import acquire_persistent_store
            data = acquire_persistent_store().get_state("energy", channel_id)
            if not data or not isinstance(data, dict):
                return False
            cc = self._chat_cfg()
            bc = self._brain_cfg()
            ceiling_chat = float(cc.get("max", 0))
            ceiling_brain = float(bc.get("max", 0))
            snap = EnergySnapshot(
                chat_pool=min(float(data.get("chat_pool", ceiling_chat)), ceiling_chat),
                chat_ceiling=ceiling_chat,
                brain_pool=min(float(data.get("brain_pool", ceiling_brain)), ceiling_brain),
                brain_ceiling=ceiling_brain,
                fatigue_level=float(data.get("fatigue", 0.0)),
                annoyance_level=float(data.get("annoyance", 0.0)),
                captured_at=time.time(),
            )
            self._channel_snapshots[channel_id] = snap
            logger.debug(f"[{channel_id[:8]}] 能量快照已恢复")
            return True
        except Exception as exc:
            logger.debug(f"[{channel_id[:8]}] 能量恢复失败: {exc}")
            return False

    def persist_all_channels(self) -> int:
        """批量持久化所有频道能量状态"""
        count = 0
        for cid in list(self._channel_snapshots.keys()):
            self.persist_channel_energy(cid)
            count += 1
        return count


def get_vitality_pool() -> VitalityPoolManager:
    """获取全局能量管理器"""
    return VitalityPoolManager.instance()
