import asyncio
import hashlib
import json
import math
import os
import re
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config

logger = get_logger("bond_settler")


@dataclass
class SettlementSummary:
    """单次结算的完整报告"""
    raw_delta: float = 0.0
    saturation_factor: float = 1.0
    reversal_bonus: float = 0.0
    dampened_delta: float = 0.0
    final_value: float = 0.0
    capped: bool = False
    direction: str = ""


@dataclass
class ResonanceRecord:
    """单用户的记忆与情感档案"""
    anchor_id: str = ""
    display_alias: str = ""
    custom_label: str = ""
    label_reason: str = ""
    origin_platform: str = ""
    origin_uid: str = ""
    recognized: bool = False
    first_encounter_ts: float = 0.0
    latest_encounter_ts: float = 0.0
    encounter_tally: int = 0
    memory_entries: List[str] = field(default_factory=list)
    channel_aliases: List[Dict[str, str]] = field(default_factory=list)
    favor_score: float = 0.0
    annoyance_score: float = 0.0
    last_delta_sign: int = 0
    consecutive_same_sign: int = 0
    def to_dict(self) -> Dict[str, Any]:
        return {
            "anchor_id": self.anchor_id,
            "display_alias": self.display_alias,
            "custom_label": self.custom_label,
            "label_reason": self.label_reason,
            "origin_platform": self.origin_platform,
            "origin_uid": self.origin_uid,
            "recognized": self.recognized,
            "first_encounter_ts": self.first_encounter_ts,
            "latest_encounter_ts": self.latest_encounter_ts,
            "encounter_tally": self.encounter_tally,
            "memory_entries": list(self.memory_entries),
            "channel_aliases": list(self.channel_aliases),
            "favor_score": round(self.favor_score, 4),
            "annoyance_score": round(self.annoyance_score, 4),
        }
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ResonanceRecord":
        obj = cls(
            anchor_id=str(data.get("anchor_id", "")),
            display_alias=str(data.get("display_alias", "")),
            custom_label=str(data.get("custom_label", "")),
            label_reason=str(data.get("label_reason", "")),
            origin_platform=str(data.get("origin_platform", "")),
            origin_uid=str(data.get("origin_uid", "")),
            recognized=bool(data.get("recognized", False)),
            first_encounter_ts=float(data.get("first_encounter_ts", 0.0)),
            latest_encounter_ts=float(data.get("latest_encounter_ts", 0.0)),
            encounter_tally=int(data.get("encounter_tally", 0)),
            favor_score=float(data.get("favor_score", 0.0)),
            annoyance_score=float(data.get("annoyance_score", 0.0)),
        )
        obj.memory_entries = list(data.get("memory_entries", []))
        obj.channel_aliases = list(data.get("channel_aliases", []))
        return obj


def compute_anchor_id(platform: str, uid: Union[int, str]) -> str:
    """跨平台唯一标识哈希"""
    normalized = platform.split("-")[-1] if "-" in platform else platform
    seed = f"{normalized}_{uid}"
    return hashlib.md5(seed.encode()).hexdigest()


class BondSettler:
    """
    情感粘合引擎

    整合好感度阻尼结算（饱和曲线 + 反向回弹 + 大幅削弱）
    以及用户记忆点管理（分类存储 + 权重衰减 + LLM 取名）。
    """
    _solo: Optional["BondSettler"] = None
    @classmethod
    def instance(cls) -> "BondSettler":
        if cls._solo is None:
            cls._solo = cls()
        return cls._solo
    @classmethod
    def teardown(cls) -> None:
        if cls._solo:
            cls._solo._dump_all()
            cls._solo._records.clear()
        cls._solo = None
    def __init__(self):
        self._records: Dict[str, ResonanceRecord] = {}
        self._rw_lock = asyncio.Lock()
        self._conf_cache: Dict[str, Any] = {}
        self._conf_ts: float = 0.0
        self._storage_dir: str = "data/huoli/bond_records"
        self._reload_conf()
        self._restore_all()
    # ---- 配置 ----
    def _reload_conf(self) -> None:
        now = time.time()
        if now - self._conf_ts < 60.0:
            return
        hub = get_core_config()
        ps = hub.personality_sliders_block()
        self._conf_cache = {
            # 饱和曲线参数
            "saturation_steepness": float(ps.get("bond_saturation_steepness", 0.02)),
            "saturation_cap": float(ps.get("bond_saturation_cap", 100.0)),
            # 反向回弹
            "reversal_multiplier": float(ps.get("bond_reversal_multiplier", 1.35)),
            "reversal_min_streak": int(ps.get("bond_reversal_min_streak", 3)),
            # 大幅削弱
            "large_delta_threshold": float(ps.get("bond_large_delta_threshold", 15.0)),
            "large_delta_dampen": float(ps.get("bond_large_delta_dampen_rate", 0.6)),
            # 全局限幅
            "step_ceiling": float(ps.get("bond_step_ceiling", 20.0)),
            # 记忆点容量
            "memory_cap": int(ps.get("bond_memory_cap_per_user", 200)),
        }
        self._conf_ts = now
    # ---- 核心结算 ----
    def settle(self, anchor_id: str, raw_delta: float) -> SettlementSummary:
        """
        对某用户执行单次情感结算

        按顺序施加：
          1. 饱和阻尼（越接近上限变化越小）
          2. 反向回弹（连续同向后突然反转 → 放大）
          3. 大幅削弱（单步过大 → 打折）
          4. 限幅 ±step_ceiling
        """
        self._reload_conf()
        rec = self._ensure_record(anchor_id)
        cap = self._conf_cache["saturation_cap"]
        steep = self._conf_cache["saturation_steepness"]
        step_ceil = self._conf_cache["step_ceiling"]
        summary = SettlementSummary(raw_delta=raw_delta)
        # 饱和因子：距离上限越近越小
        distance_ratio = abs(rec.favor_score) / max(cap, 1.0)
        summary.saturation_factor = 1.0 / (1.0 + steep * (distance_ratio ** 2) * 100.0)
        dampened = raw_delta * summary.saturation_factor
        # 判定方向
        sign = 1 if dampened > 0 else (-1 if dampened < 0 else 0)
        summary.direction = "positive" if sign > 0 else ("negative" if sign < 0 else "neutral")
        # 反向回弹
        if sign != 0 and sign != rec.last_delta_sign:
            if rec.consecutive_same_sign >= self._conf_cache["reversal_min_streak"]:
                mult = self._conf_cache["reversal_multiplier"]
                bonus = abs(dampened) * (mult - 1.0)
                summary.reversal_bonus = bonus * sign
                dampened += summary.reversal_bonus
                logger.debug(f"[粘合] 反向回弹触发 | 连续={rec.consecutive_same_sign} 加成={bonus:.2f}")
            rec.consecutive_same_sign = 1
            rec.last_delta_sign = sign
        elif sign != 0:
            rec.consecutive_same_sign += 1
        # 大幅削弱
        threshold = self._conf_cache["large_delta_threshold"]
        dampen_rate = self._conf_cache["large_delta_dampen_rate"]
        if abs(dampened) > threshold:
            excess = abs(dampened) - threshold
            dampened = (threshold + excess * dampen_rate) * (1 if dampened > 0 else -1)
        # 限幅
        dampened = max(-step_ceil, min(step_ceil, dampened))
        summary.dampened_delta = dampened
        # 应用
        new_val = rec.favor_score + dampened
        if abs(new_val) > cap:
            new_val = cap if new_val > 0 else -cap
            summary.capped = True
        rec.favor_score = new_val
        summary.final_value = new_val
        self._persist_single(anchor_id)
        return summary
    def adjust_annoyance(self, anchor_id: str, delta: float) -> float:
        """调整烦恼度，±100 限幅"""
        rec = self._ensure_record(anchor_id)
        rec.annoyance_score = max(0.0, min(100.0, rec.annoyance_score + delta))
        self._persist_single(anchor_id)
        return rec.annoyance_score
    def favor_of(self, anchor_id: str) -> float:
        return self._ensure_record(anchor_id).favor_score
    def annoyance_of(self, anchor_id: str) -> float:
        return self._ensure_record(anchor_id).annoyance_score
    # ---- 用户注册 ----
    def enroll_user(
        self,
        platform: str,
        uid: str,
        nickname: str,
        channel_id: str = "",
        channel_nick: str = "",
    ) -> ResonanceRecord:
        """注册或更新用户"""
        aid = compute_anchor_id(platform, uid)
        rec = self._ensure_record(aid)
        if not rec.recognized:
            rec.anchor_id = aid
            rec.origin_platform = platform
            rec.origin_uid = str(uid)
            rec.display_alias = nickname
            rec.custom_label = nickname
            rec.recognized = True
            rec.first_encounter_ts = time.time()
            rec.label_reason = "首次注册时沿用昵称"
            logger.info(f"[粘合] 新用户注册 | aid={aid} nick={nickname}")
        rec.encounter_tally += 1
        rec.latest_encounter_ts = time.time()
        if not rec.display_alias:
            rec.display_alias = nickname
        if channel_id and channel_nick:
            self._upsert_channel_alias(rec, channel_id, channel_nick)
        self._persist_single(aid)
        return rec
    @staticmethod
    def _upsert_channel_alias(rec: ResonanceRecord, ch_id: str, ch_nick: str) -> None:
        for entry in rec.channel_aliases:
            if entry.get("channel_id") == ch_id:
                entry["channel_nick"] = ch_nick
                return
        rec.channel_aliases.append({"channel_id": ch_id, "channel_nick": ch_nick})
    # ---- 记忆点管理 ----
    def append_memory(self, anchor_id: str, category: str, content: str, weight: float = 1.0) -> bool:
        """追加一条记忆点 (格式: category:content:weight)"""
        rec = self._ensure_record(anchor_id)
        cap = self._conf_cache.get("memory_cap", 200)
        entry = f"{category}:{content}:{weight}"
        # 去重
        for existing in rec.memory_entries:
            existing_content = self._extract_content(existing)
            if existing_content and (existing_content == content or content in existing_content):
                return False
        rec.memory_entries.append(entry)
        if len(rec.memory_entries) > cap:
            rec.memory_entries = rec.memory_entries[-cap:]
        self._persist_single(anchor_id)
        return True
    def remove_memory(self, anchor_id: str, category: str, content: str, similarity_threshold: float = 0.95) -> int:
        """删除指定分类下相似的记忆点"""
        rec = self._ensure_record(anchor_id)
        kept = []
        removed = 0
        for entry in rec.memory_entries:
            if entry is None:
                continue
            parts = entry.split(":", 2)
            if len(parts) < 3:
                kept.append(entry)
                continue
            cat = parts[0].strip()
            txt = parts[1].strip()
            if cat != category:
                kept.append(entry)
                continue
            sim = self._text_similarity(content, txt)
            if sim >= similarity_threshold:
                removed += 1
            else:
                kept.append(entry)
        rec.memory_entries = kept
        if removed:
            self._persist_single(anchor_id)
        return removed
    def list_categories(self, anchor_id: str) -> List[str]:
        rec = self._ensure_record(anchor_id)
        seen: List[str] = []
        for entry in rec.memory_entries:
            cat = self._extract_category(entry)
            if cat and cat not in seen:
                seen.append(cat)
        return seen
    def sample_memories(self, anchor_id: str, category: str, count: int = 1) -> List[str]:
        import random
        rec = self._ensure_record(anchor_id)
        pool = [e for e in rec.memory_entries if self._extract_category(e) == category]
        if len(pool) <= count:
            return pool
        return random.sample(pool, count)
    # ---- LLM 取名 ----
    async def mint_custom_label(
        self,
        anchor_id: str,
        nickname: str,
        cardname: str = "",
        avatar_desc: str = "",
        existing_labels: Optional[List[str]] = None,
    ) -> Optional[Dict[str, str]]:
        """使用 LLM 为用户生成人称标签"""
        rec = self._ensure_record(anchor_id)
        previous_label_hint = ""
        if rec.custom_label and rec.label_reason:
            previous_label_hint = f"之前叫 {rec.custom_label}，理由是 {rec.label_reason}。"
        used_names = set(existing_labels or [])
        used_names.update(r.custom_label for r in self._records.values() if r.custom_label)
        avoid_list = "、".join(sorted(used_names)[:30]) if used_names else "无"
        prompt = (
            f"[取名任务]\n"
            f"用户昵称：{nickname}\n"
            f"名片名：{cardname}\n"
            f"头像描述：{avatar_desc}\n"
            f"{previous_label_hint}\n"
            f"已存在的名称（请避开）：{avoid_list}\n\n"
            f'请输出 JSON：{{"nickname": "你取的名字", "reason": "理由"}}'
        )
        raw = await self._call_llm(prompt)
        if not raw:
            return None
        parsed = self._parse_json(raw)
        if not parsed or not parsed.get("nickname"):
            return None
        new_label = str(parsed["nickname"])
        if new_label in used_names:
            new_label = await self._make_unique_label(new_label, used_names)
        rec.custom_label = new_label
        rec.label_reason = str(parsed.get("reason", ""))
        self._persist_single(anchor_id)
        logger.info(f"[粘合] 取名成功 | aid={anchor_id} label={new_label}")
        return {"nickname": new_label, "reason": rec.label_reason}
    async def _make_unique_label(self, base: str, used: set) -> str:
        if not base or base.isspace():
            base = "匿名"
        if base not in used:
            return base
        idx = 1
        while True:
            candidate = f"{base}[{idx}]"
            if candidate not in used:
                return candidate
            idx += 1
    # ---- 关系文本构建 ----
    async def compose_relationship_blurb(
        self,
        anchor_id: str,
        chat_content: str = "",
        info_type: str = "",
    ) -> str:
        """根据记忆点构建关系描述（供 prompt 注入）"""
        rec = self._ensure_record(anchor_id)
        if not rec.recognized:
            return ""
        label = rec.custom_label or rec.display_alias or f"用户{anchor_id[:6]}"
        alias_hint = ""
        if rec.custom_label != rec.display_alias and rec.display_alias:
            alias_hint = f"（在 {rec.origin_platform} 上叫 {rec.display_alias}）"
        memory_snippet = ""
        categories = self.list_categories(anchor_id)
        if chat_content and categories:
            chosen_cat = await self._pick_relevant_category(categories, chat_content)
            if chosen_cat:
                samples = self.sample_memories(anchor_id, chosen_cat, 2)
                if samples:
                    contents = [self._extract_content(s) for s in samples]
                    memory_snippet = f"有关 {chosen_cat} 的记忆：{'；'.join(c for c in contents if c)}"
        elif info_type and categories:
            chosen_cat = await self._pick_relevant_category(categories, info_type)
            if chosen_cat:
                samples = self.sample_memories(anchor_id, chosen_cat, 3)
                if samples:
                    contents = [self._extract_content(s) for s in samples]
                    memory_snippet = f"有关 {chosen_cat} 的记忆：{'；'.join(c for c in contents if c)}"
        elif categories:
            for cat in categories[:1]:
                samples = self.sample_memories(anchor_id, cat, 1)
                if samples:
                    c = self._extract_content(samples[0])
                    if c:
                        memory_snippet = f"有关 {cat}：{c}"
                    break
        if not alias_hint and not memory_snippet:
            return ""
        parts = [f"{label}：{alias_hint}"]
        if memory_snippet:
            parts.append(memory_snippet)
        return " ".join(parts)
    async def _pick_relevant_category(self, categories: List[str], reference: str) -> Optional[str]:
        if not categories:
            return None
        if len(categories) == 1:
            return categories[0]
        prompt = (
            f"[分类选择]\n"
            f"参考内容：{reference[:500]}\n"
            f"可选分类：{categories}\n"
            f"请从中选出最相关的分类，直接输出分类名。如无匹配输出 none。"
        )
        raw = await self._call_llm(prompt)
        if not raw:
            return categories[0]
        cleaned = raw.strip().strip('"').strip("'")
        if cleaned.lower() == "none":
            return None
        for cat in categories:
            if cat in cleaned:
                return cat
        return categories[0]
    # ---- 查询 ----
    def get_record(self, anchor_id: str) -> ResonanceRecord:
        return self._ensure_record(anchor_id)
    def all_anchor_ids(self) -> List[str]:
        return list(self._records.keys())
    def find_by_label(self, label: str) -> Optional[str]:
        for aid, rec in self._records.items():
            if rec.custom_label == label or rec.display_alias == label:
                return aid
        return None
    def is_recognized(self, anchor_id: str) -> bool:
        return self._records.get(anchor_id, ResonanceRecord()).recognized
    def idle_duration(self, anchor_id: str) -> float:
        rec = self._ensure_record(anchor_id)
        return time.time() - rec.latest_encounter_ts if rec.latest_encounter_ts > 0 else float("inf")
    # ---- 持久化 ----
    def _ensure_record(self, anchor_id: str) -> ResonanceRecord:
        if anchor_id not in self._records:
            self._records[anchor_id] = ResonanceRecord(anchor_id=anchor_id)
        return self._records[anchor_id]
    def _persist_single(self, anchor_id: str) -> None:
        rec = self._records.get(anchor_id)
        if not rec:
            return
        try:
            os.makedirs(self._storage_dir, exist_ok=True)
            path = os.path.join(self._storage_dir, f"{anchor_id}.json")
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(rec.to_dict(), fh, ensure_ascii=False, indent=2)
        except (OSError, TypeError) as exc:
            logger.debug(f"[粘合] 持久化单用户失败 | {anchor_id}: {exc}")
    def _dump_all(self) -> None:
        for aid in list(self._records.keys()):
            self._persist_single(aid)
    def _restore_all(self) -> None:
        if not os.path.isdir(self._storage_dir):
            return
        try:
            for fname in os.listdir(self._storage_dir):
                if not fname.endswith(".json"):
                    continue
                path = os.path.join(self._storage_dir, fname)
                try:
                    with open(path, "r", encoding="utf-8") as fh:
                        data = json.load(fh)
                    rec = ResonanceRecord.from_dict(data)
                    if rec.anchor_id:
                        self._records[rec.anchor_id] = rec
                except (json.JSONDecodeError, TypeError, KeyError) as exc:
                    logger.debug(f"[粘合] 恢复记录失败 | {fname}: {exc}")
        except OSError as exc:
            logger.debug(f"[粘合] 读取目录失败: {exc}")
    # ---- 辅助 ----
    @staticmethod
    def _extract_category(entry: str) -> Optional[str]:
        if not isinstance(entry, str):
            return None
        parts = entry.split(":", 1)
        return parts[0].strip() if len(parts) > 1 else None
    @staticmethod
    def _extract_content(entry: str) -> str:
        if not isinstance(entry, str):
            return ""
        parts = entry.split(":")
        return ":".join(parts[1:-1]).strip() if len(parts) > 2 else ""
    @staticmethod
    def _extract_weight(entry: str) -> float:
        if not isinstance(entry, str):
            return 0.0
        parts = entry.rsplit(":", 1)
        if len(parts) <= 1:
            return 0.0
        try:
            return float(parts[-1].strip())
        except (ValueError, TypeError):
            return 0.0
    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        if a == b:
            return 1.0
        if not a or not b:
            return 0.0
        longer, shorter = (a, b) if len(a) >= len(b) else (b, a)
        prev_row = list(range(len(shorter) + 1))
        for i, ch1 in enumerate(longer):
            cur_row = [i + 1]
            for j, ch2 in enumerate(shorter):
                insert_cost = prev_row[j + 1] + 1
                delete_cost = cur_row[j] + 1
                replace_cost = prev_row[j] + (ch1 != ch2)
                cur_row.append(min(insert_cost, delete_cost, replace_cost))
            prev_row = cur_row
        return 1.0 - (prev_row[-1] / max(len(longer), 1))
    async def _call_llm(self, prompt: str) -> Optional[str]:
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            req = LLMRequest(model_config.utils, request_type="bond_settler")
            text, _ = await req.generate_response_async(prompt, max_tokens=500)
            return text
        except Exception as exc:
            logger.error(f"[粘合] LLM 调用失败: {exc}")
            return None
    @staticmethod
    def _parse_json(raw: str) -> Optional[Dict]:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return None
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            try:
                fixed = re.sub(r",\s*}", "}", match.group())
                return json.loads(fixed)
            except Exception:
                return None
    def collect_metrics(self) -> Dict[str, Any]:
        recognized_count = sum(1 for r in self._records.values() if r.recognized)
        return {
            "total_records": len(self._records),
            "recognized_count": recognized_count,
            "avg_favor": round(
                sum(r.favor_score for r in self._records.values()) / max(len(self._records), 1), 2,
            ),
        }


def get_bond_settler() -> BondSettler:
    """获取全局情感粘合引擎实例"""
    return BondSettler.instance()
