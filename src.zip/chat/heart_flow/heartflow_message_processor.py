import re
import time as _tm
import asyncio
import traceback
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from src.chat.heart_flow.heartflow import heartflow
from src.chat.message_receive.message import MessageRecv
from src.chat.message_receive.storage import MessageStorage
from src.chat.utils.chat_message_builder import replace_user_references
from src.chat.utils.utils import is_mentioned_bot_in_message
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config
from src.person_info.person_info import Person

logger = get_logger("msg_pipeline")

# ---------------------------------------------------------------------------
#  配置读取
# ---------------------------------------------------------------------------

def _pipe_cfg() -> Dict[str, Any]:
    """从配置中枢读取消息取得参数"""
    try:
        return get_core_config().assemble_processor_config()
    except RuntimeError:
        return {}


# ---------------------------------------------------------------------------
#  去重环
# ---------------------------------------------------------------------------

class _DeduplicationRing:
    """固定容量的消息ID去重环"""

    def __init__(self):
        self._ring: Set[str] = set()
        self._order: List[str] = []

    def seen(self, mid: str) -> bool:
        return mid in self._ring

    def register(self, mid: str) -> None:
        if mid in self._ring:
            return
        c = _pipe_cfg()
        cap = int(c.get("dedup_cap", 500))
        self._ring.add(mid)
        self._order.append(mid)
        if len(self._order) > cap:
            half = cap // 2
            evicted = self._order[:half]
            self._order = self._order[half:]
            for eid in evicted:
                self._ring.discard(eid)


# ---------------------------------------------------------------------------
#  图片描述替换器
# ---------------------------------------------------------------------------

_PICID_RE = re.compile(r"\[picid:([^\]]+)\]")


def _resolve_image_tags(raw_text: str) -> str:
    """将 [picid:xxx] 标记替换为图片描述或占位符"""
    c = _pipe_cfg()
    tpl = c.get("img_desc_tpl", "[图片：{desc}]")
    fallback = c.get("img_fallback", "[图片]")
    refs = _PICID_RE.findall(raw_text)
    if not refs:
        return raw_text
    result = raw_text
    try:
        from src.common.database.database_model import Images
        for pid in refs:
            tag = f"[picid:{pid}]"
            record = Images.get_or_none(Images.image_id == pid)
            if record and record.description:
                result = result.replace(tag, tpl.format(desc=record.description))
            else:
                result = result.replace(tag, fallback)
    except Exception:
        for pid in refs:
            result = result.replace(f"[picid:{pid}]", fallback)
    return result


# ---------------------------------------------------------------------------
#  短消息过滤器
# ---------------------------------------------------------------------------

class _ShortMessageGate:
    """判断短消息是否应跳过处理"""

    @staticmethod
    def should_skip(
        text: str,
        is_mentioned: bool,
        is_at: bool,
        is_private: bool,
    ) -> bool:
        c = _pipe_cfg()
        if not c.get("short_filter_on", True):
            return False
        min_chars = int(c.get("short_min", 3))
        whitelist = c.get("short_whitelist", [])
        at_also = c.get("at_also_filter", False)
        stripped = text.strip()
        if len(stripped) >= min_chars:
            return False
        if stripped in whitelist:
            return False
        if stripped.startswith(("/", "!", "！")):
            return False
        if (is_mentioned or is_at) and not at_also:
            return False
        if is_private:
            return False
        return True


# ---------------------------------------------------------------------------
#  参与度评估
# ---------------------------------------------------------------------------

async def _evaluate_engagement(text: str) -> float:
    """调用兴趣度评估器，失败时返回配置回退值"""
    c = _pipe_cfg()
    fallback = float(c.get("engage_fallback", 0.5))
    try:
        from src.chat.chatter.interest_calculator import get_engagement_scorer
        scorer = get_engagement_scorer()
        result = scorer.calculate_interest(text)
        return float(result.score)
    except Exception:
        return fallback


# ---------------------------------------------------------------------------
#  记忆存储桥
# ---------------------------------------------------------------------------

async def _route_to_memory(
    stream_id: str,
    user_id: str,
    content: str,
    engagement: float,
    is_flagged: bool,
) -> None:
    """根据参与度分流写入完整记忆或海马体临时缓存"""
    c = _pipe_cfg()
    full_thr = float(c.get("engage_full_thr", 0.6))
    hippo_min = float(c.get("hippo_min_imp", 0.2))
    should_full = engagement >= full_thr or is_flagged
    try:
        if should_full:
            from src.memory_system.memory_core import acquire_recollection_hub
            mgr = acquire_recollection_hub()
            mgr.create_memory(
                stream_id=stream_id, content=content,
                memory_type="conversation", user_id=user_id,
                importance=max(0.5, engagement),
            )
        else:
            from src.memory_system.hippocampus_buffer import get_hippocampus_buffer
            hippo = get_hippocampus_buffer(stream_id)
            hippo.add_memory(
                content=content, user_id=user_id,
                importance=max(hippo_min, engagement),
            )
    except Exception as exc:
        logger.debug(f"记忆存储异常: {exc}")


# ---------------------------------------------------------------------------
#  用户状态记录桥
# ---------------------------------------------------------------------------

def _record_user_interaction(user_id: str, text: str, explicitly_called: bool) -> None:
    """异步向用户状态检测器提交交互记录"""
    try:
        from src.chat.heart_flow.user_state_detector import get_user_state_detector
        det = get_user_state_detector()
        det.record_interaction(
            user_id=user_id,
            message_content=text,
            is_initiated_by_user=explicitly_called,
        )
    except Exception:
        pass


async def _record_dialogue_memoir(
    stream_id: str,
    user_id: str,
    sender_name: str,
    text: str,
    msg_time: float,
) -> None:
    """将真实用户消息写入 proactive 回忆录，供主动链路后续使用。"""
    if not user_id or not text:
        return
    try:
        from src.chat.proactive.session_tracker import get_memoir_cabinet

        cabinet = get_memoir_cabinet()
        memoir = await cabinet.fetch_memoir(user_id=user_id, channel_id=stream_id)
        memoir.record_user_utterance(
            content=text,
            sender_name=sender_name,
            sender_id=user_id,
            msg_time=msg_time,
        )
    except Exception as exc:
        logger.debug(f"主动回忆录记录异常: {exc}")


# ---------------------------------------------------------------------------
#  知识图谱/梗学习桥
# ---------------------------------------------------------------------------

def _try_learn_knowledge(stream_id: str, text: str, msg_id: str) -> None:
    """长消息投递知识图谱学习"""
    c = _pipe_cfg()
    min_len = int(c.get("kg_min", 10))
    if len(text) < min_len:
        return
    try:
        from src.modules.modcore.social_cognition.knowledge_graph import get_knowledge_graph_manager
        kg = get_knowledge_graph_manager(stream_id)
        kg.learn_from_message(text, msg_id=msg_id)
    except Exception:
        pass


# ---------------------------------------------------------------------------
#  独立监控器投递桥
# ---------------------------------------------------------------------------

def _feed_independent_monitor(channel_id: str, user_id: str, text: str) -> None:
    """将消息喂给独立监控器，驱动后台判定与主动发言"""
    try:
        from src.chat.heart_flow.independent_monitor import acquire_independent_monitor
        acquire_independent_monitor().feed_message(channel_id, user_id, text)
    except Exception:
        pass


# ---------------------------------------------------------------------------
#  主接收器
# ---------------------------------------------------------------------------

class MessageIntakePipeline:
    """消息摄入管线

    生命周期：
      1. 启动保护期内跳过群内超龄消息
      2. 去重 → 提及检测 → 图片描述替换 → 消息存储
      3. 短消息过滤
      4. 参与度评估 → 记忆分流
      5. 注册参与者 → 知识图谱学习
      6. 投递独立监控器
    """

    _dedup = _DeduplicationRing()

    def __init__(self):
        self._archive = MessageStorage()
        self._shielding = True
        self._boot_ts = _tm.time()
        self._shield_task: Optional[asyncio.Task] = None
        self._ensure_shield_timer()

    def _ensure_shield_timer(self) -> None:
        if self._shield_task is not None and not self._shield_task.done():
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        self._shield_task = loop.create_task(self._expire_shield())

    async def _expire_shield(self) -> None:
        c = _pipe_cfg()
        dur = float(c.get("boot_shield", 30))
        await asyncio.sleep(dur)
        self._shielding = False
        logger.info("消息管线启动保护期结束")

    # ---- 主入口 ----

    async def process_message(self, message: MessageRecv) -> None:
        try:
            self._ensure_shield_timer()
            if message.is_notify:
                return
            userinfo = message.message_info.user_info
            chat = message.chat_stream
            if self._should_discard_stale(message, chat):
                return
            mid = self._extract_msg_id(message)
            if self._dedup.seen(mid):
                logger.debug("重复消息，跳过")
                return
            self._dedup.register(mid)
            is_mentioned, is_at, boost = is_mentioned_bot_in_message(message)
            message.is_mentioned = is_mentioned
            message.is_at = is_at
            message.reply_probability_boost = boost
            raw_text = message.processed_plain_text
            enriched_text = _resolve_image_tags(raw_text)
            message.processed_plain_text = enriched_text
            if not getattr(message, "detailed_plain_text", None):
                message.detailed_plain_text = enriched_text
            await self._archive.store_message(message, chat)
            await heartflow.get_or_create_heartflow_chat(chat.stream_id)
            readable = replace_user_references(
                enriched_text, message.message_info.platform, replace_bot_name=True,
            )
            chan_label = chat.group_info.group_name if chat.group_info else "私聊"
            c = _pipe_cfg()
            log_max = int(c.get("log_max", 120))
            display = readable[:log_max] + "..." if len(readable) > log_max else readable
            logger.info(f"[{chan_label}]{userinfo.user_nickname}: {display}")
            is_private = not chat.group_info
            clean_text = (readable or "").strip()
            if _ShortMessageGate.should_skip(clean_text, is_mentioned, is_at, is_private):
                logger.debug(f"短消息过滤: len={len(clean_text)}")
                return
            uid = str(userinfo.user_id) if userinfo else ""
            engagement = await _evaluate_engagement(clean_text)
            await _route_to_memory(
                stream_id=chat.stream_id, user_id=uid,
                content=clean_text, engagement=engagement,
                is_flagged=(is_mentioned or is_at),
            )
            _record_user_interaction(uid, clean_text, is_mentioned or is_at)
            await _record_dialogue_memoir(
                stream_id=chat.stream_id,
                user_id=uid,
                sender_name=userinfo.user_nickname,
                text=clean_text,
                msg_time=float(getattr(message.message_info, "time", _tm.time()) or _tm.time()),
            )
            group_id = None
            card_name = None
            if chat.group_info:
                group_id = chat.group_info.group_id
                card_name = userinfo.user_cardname
            Person.register_person(
                platform=message.message_info.platform,
                user_id=userinfo.user_id,
                nickname=userinfo.user_nickname,
                group_id=group_id,
                group_nick_name=card_name,
            )
            _try_learn_knowledge(chat.stream_id, clean_text, mid)
            _feed_independent_monitor(chat.stream_id, uid, clean_text)
            self._log_participant_snapshot(chat.stream_id, uid, userinfo.user_nickname)
        except Exception as exc:
            logger.error(f"消息管线异常: {exc}")
            logger.error(traceback.format_exc())

    # ---- 辅助方法 ----

    def _should_discard_stale(self, message: MessageRecv, chat) -> bool:
        """启动保护期内丢弃陈旧的群消息"""
        if not self._shielding:
            return False
        is_private = not chat.group_info
        if is_private:
            return False
        c = _pipe_cfg()
        stale_thr = float(c.get("stale_thr", 180))
        now = _tm.time()
        msg_ts = getattr(message, "timestamp", now) or now
        age = now - msg_ts
        if age > stale_thr:
            logger.debug(f"启动保护 | 跳过陈旧消息 (偏移 {age:.0f}s)")
            return True
        return False

    @staticmethod
    def _extract_msg_id(message: MessageRecv) -> str:
        raw = getattr(message, "message_id", None) or id(message)
        return str(raw)

    @staticmethod
    def _log_participant_snapshot(stream_id: str, uid: str, name: str) -> None:
        """尝试打印用户状态摘要"""
        try:
            from src.modules.modcore.dynamic_persona.emotion_tracker import get_emotion_tracker
            tracker = get_emotion_tracker(stream_id)
            state = tracker.get_user_state(uid, create_if_missing=False)
            if not state:
                return
            parts = []
            aff = int(state.affection)
            parts.append(f"好感{aff:+d}")
            parts.append(state.relationship)
            annoy = int(state.annoyance)
            if annoy > 30:
                parts.append(f"烦{annoy}")
            trauma = state.trauma_score
            if trauma > 3:
                parts.append(f"创{trauma:.1f}")
            if parts:
                logger.debug(f"用户快照 {name}: {' '.join(parts)}")
        except Exception:
            pass


# ---------------------------------------------------------------------------
#  消息查询工具
# ---------------------------------------------------------------------------

def fetch_recent_messages(
    chat_id: str,
    start_time: float,
    end_time: float,
    limit: int = 20,
    limit_mode: str = "latest",
    filter_bot: bool = True,
    filter_command: bool = False,
) -> list:
    """根据时间范围查询历史消息列表"""
    try:
        from src.chat.utils.chat_message_builder import get_raw_msg_by_timestamp_with_chat
        return get_raw_msg_by_timestamp_with_chat(
            chat_id=chat_id,
            timestamp_start=start_time,
            timestamp_end=end_time,
            limit=limit,
            limit_mode=limit_mode,
            filter_bot=filter_bot,
            filter_command=filter_command,
        )
    except Exception as exc:
        logger.error(f"查询消息异常: {exc}")
        return []


# ---------------------------------------------------------------------------
#  模块级单例
# ---------------------------------------------------------------------------

message_receiver = MessageIntakePipeline()
