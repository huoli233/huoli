import json
import re
import random
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from src.common.logger import get_logger
from src.config.core_config_engine import get_core_config
from src.common.data_models.heartflow_models import BehaviorIntent, VoiceVerdict
from src.common.config.config_engine import get_default_config_engine

import src.chat.prompts.catalog  # noqa: F401 注册提示词
from src.chat.utils.prompt_builder import global_prompt_manager

logger = get_logger("self_dialogue")


class ConversationScene(Enum):
    """对话场景枚举"""
    SOLO = "solo"
    ASSEMBLY = "assembly"


class SubjectMatter(Enum):
    """话题类型枚举"""
    UNKNOWN = "unknown"
    SALUTATION = "salutation"
    INQUIRY = "inquiry"
    DIRECTIVE = "directive"
    SENTIMENT = "sentiment"
    KNOWLEDGE = "knowledge"
    CHITCHAT = "chitchat"


def _load_subject_patterns() -> Dict[SubjectMatter, List[str]]:
    engine = get_default_config_engine()
    patterns_cfg = engine.get("inner_voice", "subject_patterns", {})
    result = {}
    mapping = {
        "salutation": SubjectMatter.SALUTATION,
        "inquiry": SubjectMatter.INQUIRY,
        "directive": SubjectMatter.DIRECTIVE,
        "sentiment": SubjectMatter.SENTIMENT,
        "knowledge": SubjectMatter.KNOWLEDGE,
        "chitchat": SubjectMatter.CHITCHAT,
    }
    for key, enum_val in mapping.items():
        cfg = patterns_cfg.get(key, {})
        pats = cfg.get("patterns", [])
        if pats:
            result[enum_val] = pats
    if not result:
        result = {
            SubjectMatter.SALUTATION: [r"^(你好|嗨|哈喽|早|晚|在吗|在？|有人吗)", r"(早上好|晚上好|下午好|晚安)"],
            SubjectMatter.INQUIRY: [r"[?？]$", r"(什么|怎么|为什么|哪里|谁|多少|几)", r"(吗|呢|吧)[?？]$"],
            SubjectMatter.DIRECTIVE: [r"^(请|帮我|给我|告诉我|说|做)", r"(帮我|给我|告诉我|说一下)"],
            SubjectMatter.SENTIMENT: [r"(开心|难过|伤心|生气|烦|累|爽|哈哈|呜呜|嘤嘤)", r"[！!]{2,}"],
            SubjectMatter.KNOWLEDGE: [r"(知道|了解|懂|会|能|怎么|如何|为什么)", r"(是什么|什么意思|怎么回事)"],
            SubjectMatter.CHITCHAT: [r"(嗯|哦|啊|呢|吧|嘛)", r"(我觉得|我认为|我想)"],
        }
    return result


def _load_sentiment_terms() -> Tuple[List[Tuple[str, float]], List[Tuple[str, float]], List[Tuple[str, float]]]:
    engine = get_default_config_engine()
    upbeat_cfg = engine.get("inner_voice", "upbeat_terms", {})
    downbeat_cfg = engine.get("inner_voice", "downbeat_terms", {})
    rest_cfg = engine.get("inner_voice", "rest_terms", {})
    upbeat = [(k, float(v)) for k, v in upbeat_cfg.items()] if upbeat_cfg else [
        ("好奇", 2.5), ("有趣", 2.5), ("有意思", 2.5), ("喜欢", 2.0),
        ("开心", 1.5), ("期待", 2.0), ("聊聊", 1.5), ("说说", 1.0),
        ("听听", 1.5), ("想回", 2.0), ("想聊", 2.0), ("想说", 1.5),
    ]
    downbeat = [(k, float(v)) for k, v in downbeat_cfg.items()] if downbeat_cfg else [
        ("不想理", -3.0), ("不想回", -3.0), ("不想聊", -2.5),
        ("没兴趣", -2.0), ("没意思", -2.0), ("无聊", -2.0),
        ("烦死", -2.5), ("懒得", -2.0), ("算了", -1.5),
        ("不管", -1.5), ("沉默", -1.0), ("窥屏", -0.5),
    ]
    rest = [(k, float(v)) for k, v in rest_cfg.items()] if rest_cfg else [
        ("休息", 3.0), ("累了", 2.5), ("疲惫", 2.5), ("烦死了", 2.5),
        ("不想理", 1.5), ("没精力", 2.0), ("受不了", 2.0),
    ]
    return upbeat, downbeat, rest


def _load_time_bands() -> Dict[str, Tuple[int, int, int]]:
    engine = get_default_config_engine()
    bands_cfg = engine.get("inner_voice", "time_bands", {})
    result = {}
    for name, cfg in bands_cfg.items():
        start = int(cfg.get("start", 0))
        end = int(cfg.get("end", 24))
        adj = int(cfg.get("adjustment", 0))
        result[name] = (start, end, adj)
    if not result:
        result = {
            "deep_night": (2, 6, -2),
            "late_night": (0, 2, -1),
            "evening": (22, 24, -1),
            "morning": (6, 9, 0),
            "daytime": (9, 18, 1),
            "afternoon": (18, 22, 0),
        }
    return result


SUBJECT_PATTERNS = _load_subject_patterns()
UPBEAT_TERMS, DOWNBEAT_TERMS, REST_TERMS = _load_sentiment_terms()
TIME_BANDS = _load_time_bands()


@dataclass
class BoundaryContext:
    """护栏上下文 — 汇聚决策修正所需全部数据"""
    scene: ConversationScene = ConversationScene.ASSEMBLY
    mentioned_me: bool = False
    replying_to_me: bool = False
    raw_text: str = ""
    text_length: int = 0
    rapport_label: str = ""
    fondness: float = 0.0
    credence: float = 0.0
    mental_drain: float = 0.0
    endurance: float = 0.0
    irritation: float = 0.0
    wound_score: float = 0.0
    readiness: float = 0.0
    chat_reserve: float = 0.0
    brain_reserve: float = 0.0
    streak_count: int = 0
    clock_hour: int = 0
    subject: SubjectMatter = SubjectMatter.UNKNOWN
    assurance: float = 0.0
    involvement: float = 0.0


class SelfDialogueEngine:
    """
    自我对话引擎：构建提示词 → 调用 LLM → 解析 JSON → 护栏修正 → 输出 VoiceVerdict
    每个频道一个实例，由全局缓存管理。
    """
    def __init__(self, channel_id: str):
        self.channel_id = channel_id
        self._tag = f"[独白:{channel_id[:8]}]"
    # ---- 主入口 ----
    async def generate_reflection(
        self,
        heart_state_label: str,
        raw_text: str,
        speaker_name: str,
        dialogue_history: List[Dict],
        assurance_score: float = 0.5,
        involvement_score: float = 0.5,
        mental_drain: float = 0.0,
        endurance: float = 100.0,
        irritation: float = 0.0,
        wound_score: float = 0.0,
        readiness: float = 1.0,
        speaker_id: str = "",
    ) -> VoiceVerdict:
        """
        生成内心想法和回复欲望
        LLM 决定想回就回、不想回就不回，护栏仅做一致性修正
        """
        try:
            is_mentioned = self._detect_mention(raw_text)
            rapport_data = self._retrieve_rapport_data(speaker_name, speaker_id)
            chat_val, brain_val, streak = self._retrieve_resource_levels()
            subject = self._classify_subject(raw_text)
            is_assembly = bool(self.channel_id and not self.channel_id.startswith("private"))
            ctx = BoundaryContext(
                scene=ConversationScene.ASSEMBLY if is_assembly else ConversationScene.SOLO,
                mentioned_me=is_mentioned,
                raw_text=raw_text,
                text_length=len(raw_text),
                rapport_label=rapport_data.get("relationship", ""),
                fondness=rapport_data.get("affection", 0.0),
                credence=rapport_data.get("trust", 0.0),
                mental_drain=mental_drain,
                endurance=endurance,
                irritation=irritation,
                wound_score=wound_score,
                readiness=readiness,
                chat_reserve=chat_val,
                brain_reserve=brain_val,
                streak_count=streak,
                clock_hour=time.localtime().tm_hour,
                subject=subject,
                assurance=assurance_score,
                involvement=involvement_score,
            )
            prompt_text = await self._assemble_focused_prompt(
                heart_state_label, raw_text, speaker_name,
                dialogue_history, ctx,
            )
            llm_output = await self._invoke_llm(prompt_text)
            if llm_output == "__SAFETY_BLOCK__":
                return VoiceVerdict.make_error("safety_block")
            if not llm_output:
                return VoiceVerdict.make_error("llm_empty")
            verdict = self._extract_structured_reply(llm_output, raw_text, speaker_name)
            original_desire = verdict.reply_desire_level
            verdict = self._apply_boundaries(verdict, ctx)
            if verdict.reply_desire_level != original_desire:
                logger.info(
                    f"{self._tag} 欲望修正 {original_desire} -> {verdict.reply_desire_level}"
                )
            if verdict.reply_desire_level >= 5:
                verdict.intents = [BehaviorIntent(intent_type="reply")]
            else:
                verdict.intents = [BehaviorIntent(intent_type="observe")]
            logger.info(
                f"{self._tag} 完成 | desire={verdict.reply_desire_level} "
                f"| action={verdict.intents[0].intent_type}"
            )
            return verdict
        except Exception as exc:
            logger.error(f"{self._tag} 生成失败: {exc}")
            return VoiceVerdict.make_error(str(exc))
    # ---- 提示词构建 ----
    async def _assemble_focused_prompt(
        self, heart_label: str, raw_text: str, speaker_name: str,
        history: List[Dict], ctx: BoundaryContext,
    ) -> str:
        """组装聚焦式提示词"""
        persona = self._retrieve_persona()
        lines = []
        for msg in history[-10:]:
            role = msg.get("role", "user")
            body = msg.get("content", "")[:120]
            if body:
                prefix = "我" if role == "assistant" else speaker_name
                lines.append(f"{prefix}: {body}")
        dialogue_block = "\n".join(lines) if lines else "(刚开始聊天)"
        rapport_desc = self._describe_rapport(speaker_name, ctx)
        condition_desc = self._summarize_condition(ctx)
        scene_label = "群聊" if ctx.scene == ConversationScene.ASSEMBLY else "私聊"
        mention_note = ""
        if ctx.mentioned_me:
            mention_note = "\n注意：对方直接叫了你的名字，即使你不喜欢对方也应该回应(desire至少给5)。"
        prompt = await global_prompt_manager.format_prompt(
            "inner_voice_focused",
            persona=persona,
            scene_label=scene_label,
            dialogue_block=dialogue_block,
            speaker_name=speaker_name,
            raw_text=raw_text,
            rapport_desc=rapport_desc,
            condition_desc=condition_desc,
            chat_reserve=f"{ctx.chat_reserve:.0f}",
            brain_reserve=f"{ctx.brain_reserve:.0f}",
            mention_note=mention_note,
        )
        return prompt
    # ---- 关系描述 ----
    def _describe_rapport(self, speaker_name: str, ctx: BoundaryContext) -> str:
        """根据好感度生成关系文字描述"""
        aff = ctx.fondness
        rel = ctx.rapport_label
        if aff < -30:
            return f"你非常讨厌{speaker_name}(好感{aff:.0f},{rel})，很不想搭理"
        if aff < -10:
            return f"你对{speaker_name}印象不好(好感{aff:.0f},{rel})，有些排斥"
        if aff < 10:
            return f"你和{speaker_name}不太熟(好感{aff:.0f},{rel})"
        if aff < 40:
            return f"你觉得{speaker_name}还不错(好感{aff:.0f},{rel})"
        return f"你很喜欢{speaker_name}(好感{aff:.0f},{rel})，想多聊"
    # ---- 状态描述 ----
    def _summarize_condition(self, ctx: BoundaryContext) -> str:
        """生成当前身心状态文字描述"""
        parts = []
        if ctx.chat_reserve < 30:
            parts.append("精力快耗尽了")
        elif ctx.chat_reserve < 60:
            parts.append("有点累")
        if ctx.brain_reserve < 30:
            parts.append("脑力不足")
        if ctx.irritation > 50:
            parts.append("很烦躁")
        elif ctx.irritation > 30:
            parts.append("有点烦")
        if ctx.wound_score > 5:
            parts.append("心里有创伤很敏感")
        return "，".join(parts) if parts else "状态还行"
    # ---- 护栏修正 ----
    def _apply_boundaries(self, verdict: VoiceVerdict, ctx: BoundaryContext) -> VoiceVerdict:
        """多层护栏修正确保 thought 与 desire 逻辑一致"""
        engine = get_default_config_engine()
        inner_voice_cfg = engine.get("inner_voice", {}) or {}
        mention_min_desire = int(inner_voice_cfg.get("mention_min_desire", 6))
        private_min_desire = int(inner_voice_cfg.get("private_chat_min_desire", 5))
        res_penalty_max = int(inner_voice_cfg.get("resource_penalty_max", 5))
        tire_penalty_max = int(inner_voice_cfg.get("tiredness_penalty_max", 4))
        res_thresh = inner_voice_cfg.get("resource_thresholds", {}) or {}
        tired_thresh = inner_voice_cfg.get("tiredness_thresholds", {}) or {}
        desire = verdict.reply_desire_level
        res_penalty = self._compute_resource_deficit(ctx, res_thresh)
        if res_penalty > 0 and desire > 1:
            old = desire
            desire = max(1, desire - min(res_penalty, res_penalty_max))
            if desire != old:
                logger.info(
                    f"{self._tag} [资源惩罚] chat={ctx.chat_reserve:.0f} "
                    f"brain={ctx.brain_reserve:.0f} streak={ctx.streak_count} | {old}->{desire}"
                )
        tire_penalty = self._compute_tiredness_deficit(ctx, tired_thresh)
        if tire_penalty > 0 and desire > 1:
            old = desire
            desire = max(1, desire - min(tire_penalty, tire_penalty_max))
            if desire != old:
                logger.info(f"{self._tag} [疲劳惩罚] total={tire_penalty} | {old}->{desire}")
        if ctx.mentioned_me and desire < mention_min_desire:
            old = desire
            desire = mention_min_desire
            logger.info(f"{self._tag} [被提及保底] {old}->{desire}")
        if ctx.scene == ConversationScene.SOLO and desire < private_min_desire:
            old = desire
            desire = private_min_desire
            logger.info(f"{self._tag} [私聊保底] {old}->{desire}")
        sentiment_val = self._gauge_sentiment(verdict.thinking)
        if sentiment_val > 4.0 and desire < 4:
            old = desire
            desire = min(10, desire + 2)
            logger.info(f"{self._tag} [一致性] thought积极但desire低 {old}->{desire}")
        elif sentiment_val < -4.0 and desire > 7:
            old = desire
            desire = max(1, desire - 2)
            logger.info(f"{self._tag} [一致性] thought消极但desire高 {old}->{desire}")
        rest_val = self._gauge_rest_desire(verdict.thinking)
        if rest_val > 4.0 and desire > 3:
            old = desire
            desire = min(desire, 2)
            logger.info(f"{self._tag} [一致性] 明确休息意图 {old}->{desire}")
        time_shift = self._time_period_shift(ctx.clock_hour)
        if time_shift != 0 and desire > 1:
            old = desire
            desire = max(1, min(10, desire + time_shift))
            if desire != old:
                logger.info(f"{self._tag} [时段调节] hour={ctx.clock_hour} adj={time_shift} | {old}->{desire}")
        desire = max(1, min(10, desire))
        verdict.reply_desire_level = desire
        return verdict
    # ---- 情感分析 ----
    @staticmethod
    def _gauge_sentiment(thought: str) -> float:
        """分析 thought 文本的情感倾向"""
        score = 0.0
        for kw, weight in UPBEAT_TERMS:
            if kw in thought:
                score += weight
        for kw, weight in DOWNBEAT_TERMS:
            if kw in thought:
                score += weight
        return score
    @staticmethod
    def _gauge_rest_desire(thought: str) -> float:
        """分析 thought 中的休息意图强度"""
        score = 0.0
        for kw, weight in REST_TERMS:
            if kw in thought:
                score += abs(weight)
        return score
    # ---- 惩罚计算 ----
    @staticmethod
    def _compute_resource_deficit(ctx: BoundaryContext, thresh: Dict[str, Any] = None) -> int:
        """基于聊天精力、脑力、连续回复计算资源惩罚"""
        if thresh is None:
            thresh = {}
        chat_low = int(thresh.get("chat_reserve_low", 30))
        chat_mid = int(thresh.get("chat_reserve_mid", 50))
        brain_low = int(thresh.get("brain_reserve_low", 30))
        brain_mid = int(thresh.get("brain_reserve_mid", 50))
        streak_high = int(thresh.get("streak_high", 5))
        streak_mid = int(thresh.get("streak_mid", 3))
        penalty = 0
        if ctx.chat_reserve < chat_low:
            penalty += 2
        elif ctx.chat_reserve < chat_mid:
            penalty += 1
        if ctx.brain_reserve < brain_low:
            penalty += 2
        elif ctx.brain_reserve < brain_mid:
            penalty += 1
        if ctx.streak_count >= streak_high:
            penalty += 2
        elif ctx.streak_count >= streak_mid:
            penalty += 1
        return min(penalty, 5)
    @staticmethod
    def _compute_tiredness_deficit(ctx: BoundaryContext, thresh: Dict[str, Any] = None) -> int:
        """基于心理疲劳、耐力、意愿度计算疲劳惩罚"""
        if thresh is None:
            thresh = {}
        mental_high = int(thresh.get("mental_drain_high", 80))
        mental_mid = int(thresh.get("mental_drain_mid", 60))
        endurance_low = int(thresh.get("endurance_low", 20))
        endurance_mid = int(thresh.get("endurance_mid", 40))
        willingness_gap_high = float(thresh.get("willingness_gap_high", 0.5))
        penalty = 0
        if ctx.mental_drain > mental_high:
            penalty += 2
        elif ctx.mental_drain > mental_mid:
            penalty += 1
        if ctx.endurance < endurance_low:
            penalty += 2
        elif ctx.endurance < endurance_mid:
            penalty += 1
        willingness_gap = max(0.0, 1.0 - ctx.readiness)
        if willingness_gap > willingness_gap_high:
            penalty += 1
        return min(penalty, 4)
    @staticmethod
    def _time_period_shift(hour: int) -> int:
        """根据当前时段计算 desire 偏移"""
        if hour < 0:
            hour = time.localtime().tm_hour
        for _, (start, end, adj) in TIME_BANDS.items():
            if start <= hour < end:
                return adj
        return 0
    # ---- 辅助检测 ----
    def _detect_mention(self, raw_text: str) -> bool:
        """检测消息是否提及了自己"""
        try:
            from src.config.config import global_config
            bot_alias = global_config.bot.nickname or ""
            alt_names = global_config.bot.alias_names or []
            for name in [bot_alias] + alt_names:
                if name and name in raw_text:
                    return True
            if "@" in raw_text:
                return True
        except Exception:
            return False
        return False
    def _classify_subject(self, text: str) -> SubjectMatter:
        """从文本推断话题类型"""
        if not text:
            return SubjectMatter.UNKNOWN
        best = SubjectMatter.UNKNOWN
        best_hits = 0
        for matter, patterns in SUBJECT_PATTERNS.items():
            hits = sum(1 for p in patterns if re.search(p, text))
            if hits > best_hits:
                best_hits = hits
                best = matter
        return best
    def _retrieve_resource_levels(self) -> Tuple[float, float, int]:
        """获取当前频道的聊天精力、脑力和连续回复数"""
        chat_val = 100.0
        brain_val = 100.0
        streak = 0
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            pool = get_vitality_pool()
            snap = pool.capture_snapshot(self.channel_id)
            chat_val = snap.chat_ratio * 100.0
            brain_val = snap.brain_ratio * 100.0
        except Exception:
            pass
        try:
            from src.chat.heart_flow.frequency_control import acquire_frequency_manager
            fm = acquire_frequency_manager()
            streak = fm.get_consecutive_replies(self.channel_id) if hasattr(fm, "get_consecutive_replies") else 0
        except Exception:
            pass
        return chat_val, brain_val, streak
    def _retrieve_persona(self) -> str:
        """获取人设描述片段"""
        try:
            from src.config.config import global_config
            bot_name = global_config.bot.nickname or "AI"
            personality = global_config.personality.personality or ""
            alias_list = global_config.bot.alias_names or []
            parts = [f"你是{bot_name}"]
            if alias_list:
                parts[0] += f"(别名{'、'.join(alias_list)})"
            if personality:
                parts.append(personality)
            return "，".join(parts) if len(parts) > 1 else parts[0]
        except Exception:
            from src.chat.utils.prompt_builder import global_prompt_registry
            fallback_tpl = global_prompt_registry._global_prompts.get("inner_voice_persona_fallback")
            return str(fallback_tpl) if fallback_tpl else "你是一个拥有独立人格的灵魂"
    def _retrieve_rapport_data(self, speaker_name: str, speaker_id: str) -> Dict[str, Any]:
        """获取与说话者的关系数据"""
        try:
            from src.modules.modcore.psychological_core import get_psychological_core
            core = get_psychological_core()
            if core:
                lookup = speaker_id if speaker_id else speaker_name
                return core.get_user_psychological_state(self.channel_id, lookup)
        except Exception:
            pass
        return {"relationship": "", "affection": 0.0, "trust": 0.0}
    # ---- LLM 调用 ----
    async def _invoke_llm(self, prompt: str) -> Optional[str]:
        """调用 LLM 生成原始回复文本"""
        try:
            from src.llm_models.utils_model import LLMRequest
            from src.config.config import model_config
            request = LLMRequest(model_config.focus_chat, request_type="self_dialogue")
            response_text, _ = await request.generate_response_async(prompt)
            return response_text or None
        except Exception as exc:
            err_msg = str(exc)
            err_type = type(exc).__name__
            if "EmptyContent" in err_type or "Safety violation" in err_msg or "HARASSMENT" in err_msg:
                logger.warning(f"{self._tag} 安全违规: {err_msg}")
                return "__SAFETY_BLOCK__"
            logger.error(f"{self._tag} LLM调用失败: {exc}")
            return None
    # ---- 响应解析 ----
    def _extract_structured_reply(
        self, raw: str, raw_text: str, speaker_name: str,
    ) -> VoiceVerdict:
        """
        从 LLM 输出提取结构化 JSON
        依次尝试：标准JSON → 正则字段 → 数字+文本 → 关键词推断
        """
        text = raw.strip()
        # 去除 think 标签
        think_hit = re.search(r'</think>\s*(.+)', text, re.DOTALL)
        if think_hit:
            text = think_hit.group(1).strip()
        # 尝试提取 JSON 块
        json_hit = re.search(r'\{[^{}]*"thought"[^{}]*\}', text, re.DOTALL)
        if json_hit:
            try:
                data = json.loads(json_hit.group(0))
                thought = data.get("thought", "").strip()
                desire_raw = data.get("desire", data.get("reply_desire", 5))
                desire_val = max(1, min(10, int(desire_raw)))
                mood = data.get("mood", "")
                if thought and len(thought) >= 2:
                    return VoiceVerdict(
                        thinking=thought[:120],
                        reply_desire_level=desire_val,
                    )
            except (json.JSONDecodeError, ValueError, TypeError):
                pass
        # 正则提取字段
        num_hit = re.search(r'"?desire"?\s*[:=]\s*(\d+)', text)
        thought_hit = re.search(r'"?thought"?\s*[:=]\s*"([^"]+)"', text)
        if thought_hit and num_hit:
            desire_val = max(1, min(10, int(num_hit.group(1))))
            thought = thought_hit.group(1).strip()
            if thought and len(thought) >= 2:
                return VoiceVerdict(
                    thinking=thought[:120],
                    reply_desire_level=desire_val,
                )
        # 数字开头 + 余文
        plain_hit = re.match(r'(\d+)\s*(.*)', text, re.DOTALL)
        if plain_hit:
            desire_val = max(1, min(10, int(plain_hit.group(1))))
            remainder = plain_hit.group(2).strip()
            if remainder and len(remainder) >= 2:
                return VoiceVerdict(
                    thinking=remainder[:120],
                    reply_desire_level=desire_val,
                )
            return VoiceVerdict(
                thinking=self._fabricate_reflection(desire_val, raw_text, speaker_name),
                reply_desire_level=desire_val,
            )
        # 任意数字
        any_num = re.search(r'(\d+)', text)
        if any_num:
            desire_val = max(1, min(10, int(any_num.group(1))))
        else:
            try:
                from src.chat.heart_flow.config_loader import get_desire_keywords
                desire_keywords = get_desire_keywords()
                low_kws = desire_keywords.get("low", [])
                high_kws = desire_keywords.get("high", [])
            except Exception:
                low_kws = []
                high_kws = []
            desire_val = 5
            for kw in low_kws:
                if kw in text:
                    desire_val = 3
                    break
            for kw in high_kws:
                if kw in text:
                    desire_val = 7
                    break
        if len(text) >= 2:
            return VoiceVerdict(thinking=text[:120], reply_desire_level=desire_val)
        return VoiceVerdict(
            thinking=self._fabricate_reflection(desire_val, raw_text, speaker_name),
            reply_desire_level=desire_val,
        )
    @staticmethod
    def _fabricate_reflection(desire: int, raw_text: str, speaker_name: str) -> str:
        """根据 desire 档位生成兜底 thought"""
        preview = raw_text[:20]
        if desire >= 8:
            return f"{speaker_name}说的'{preview}'很有意思，想回复"
        if desire >= 6:
            return f"看到{speaker_name}的消息，有点想聊"
        if desire >= 4:
            return f"看了看{speaker_name}的消息，还行"
        if desire >= 2:
            return f"{speaker_name}的消息不太感兴趣"
        return "不想理"
    # ---- 等待时的内心独白 ----
    async def generate_idle_musing(
        self, speaker_name: str, progress: float,
    ) -> str:
        """生成等待期间的碎碎念"""
        engine = get_default_config_engine()
        waiting_cfg = engine.get("inner_voice", "waiting_thoughts", {}) or {}
        if progress < 0.4:
            options = waiting_cfg.get("short", ["对方可能在忙吧...", "再等等看", "不知道在做什么呢"])
        elif progress < 0.7:
            options = waiting_cfg.get("medium", ["等了一会了...", "是不是忘记回复了？", "嗯...还没消息"])
        else:
            options = waiting_cfg.get("long", ["等了挺久了", "要不要主动说点什么...", "快到时间了"])
        return random.choice(options)


# ---- 全局实例缓存 ----
_engine_cache: Dict[str, SelfDialogueEngine] = {}


def get_self_dialogue_engine(channel_id: str) -> SelfDialogueEngine:
    """获取或创建频道对应的自我对话引擎"""
    if channel_id not in _engine_cache:
        _engine_cache[channel_id] = SelfDialogueEngine(channel_id)
    return _engine_cache[channel_id]


def teardown_engine(channel_id: str) -> None:
    """移除指定频道的自我对话引擎缓存"""
    _engine_cache.pop(channel_id, None)


def clear_all_engines() -> None:
    """清除全部自我对话引擎缓存（关机时调用）"""
    _engine_cache.clear()
