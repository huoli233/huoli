import asyncio
import random
import time
import traceback
from typing import Any, Dict, List, Optional, Tuple
from src.chat.heart_flow.heartFC_chat import HeartFChatting
from src.config.config import global_config
from src.common.logger import get_logger
from src.chat.heart_flow.hfc_utils import CycleDetail
from src.chat.heart_flow.frequency_control import frequency_control_manager
from src.plugin_system.apis import message_api

logger = get_logger("hfc_enhanced")

# 增强循环内部间隔常量
_TICK_FLOOR_SEC = 0.15
_DORMANT_POLL_SEC = 2.0
_PLANNER_SWEEP_ROUNDS = 8
_PERCEPTION_COOLDOWN_SEC = 5.0
_VOICE_COOLDOWN_SEC = 6.0
_TRIGGER_SCAN_ROUNDS = 12
_ENERGY_DRAIN_FLOOR = 0.08


class EnhancedHeartFChatting(HeartFChatting):
    """群聊增强版心流控制器

    在基础循环之上叠加七阶段增强管线：
    阶段协调 → 休息/等待门控 → 能量评估 → 感知引擎 → 内心独白 →
    意图锻造 → 触发条件扫描。

    所有子系统通过懒导入获取单例，不在构造时预加载，
    保证与 heartflow.py 中心化调度器的启停顺序兼容。
    """

    def __init__(self, chat_id: str):
        super().__init__(chat_id)
        # 独立监控注册标记
        self._monitor_bound = False
        # 阶段协调器是否已将此频道注册
        self._phase_registered = False
        # 增强循环轮次计数器（与父类 _cycle_counter 独立）
        self._enhanced_round = 0
        # 上一次执行感知引擎的时间戳
        self._last_perception_ts = 0.0
        # 上一次执行内心独白的时间戳
        self._last_voice_ts = 0.0
        # 最近一次觉察判定的缓存
        self._cached_awareness = None
        # 最近一次内心独白结论缓存
        self._cached_voice = None
        # 连续跳过的增强轮次数（用于自适应节奏）
        self._consecutive_skip_ticks = 0
        # 上次触发扫描的轮次
        self._last_trigger_scan_round = 0
        # 上次意图锻造的轮次
        self._last_forge_round = 0
        # 增强管线是否就绪（延迟到首次 start 后才设为 True）
        self._pipeline_ready = False

    # ────────────────── 生命周期 ──────────────────

    async def start(self):
        await super().start()
        self._bind_monitor_channel()
        self._ensure_phase_registration()
        self._pipeline_ready = True
        logger.info(f"{self.log_prefix} 增强版控制器已接管，管线就绪")

    async def stop(self) -> None:
        self._pipeline_ready = False
        self._release_monitor_channel()
        self._teardown_voice_engine()
        await super().stop()

    # ────────────────── 独立监控注册 ──────────────────

    def _bind_monitor_channel(self) -> None:
        if self._monitor_bound:
            return
        try:
            from src.chat.heart_flow.independent_monitor import acquire_independent_monitor
            acquire_independent_monitor().register_channel(self.stream_id)
            self._monitor_bound = True
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 绑定独立监控失败: {exc}")

    def _release_monitor_channel(self) -> None:
        if not self._monitor_bound:
            return
        try:
            from src.chat.heart_flow.independent_monitor import acquire_independent_monitor
            acquire_independent_monitor().unregister_channel(self.stream_id)
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 解除独立监控失败: {exc}")
        finally:
            self._monitor_bound = False

    # ────────────────── 阶段协调器注册 ──────────────────

    def _ensure_phase_registration(self) -> None:
        if self._phase_registered:
            return
        try:
            from src.chat.heart_flow.state_machine import get_phase_coordinator
            from src.common.data_models.heartflow_models import FlowPhase
            coordinator = get_phase_coordinator()
            coordinator.register_channel(self.stream_id, initial=FlowPhase.ENGAGED)
            self._phase_registered = True
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 注册阶段协调器失败: {exc}")

    # ────────────────── 内心独白引擎清理 ──────────────────

    def _teardown_voice_engine(self) -> None:
        try:
            from src.chat.heart_flow.inner_voice import teardown_engine
            teardown_engine(self.stream_id)
        except Exception:
            pass

    # ═══════════════════════════════════════════════════
    #  核心重写：增强版主循环体
    # ═══════════════════════════════════════════════════

    async def _loopbody(self):
        """七阶段增强循环体，完全替代基础版"""
        self._enhanced_round += 1
        now = time.time()

        # ── 阶段 0：状态机门控 ──
        current_phase = self._query_flow_phase()
        gate_result = self._evaluate_phase_gate(current_phase, now)
        if gate_result == "skip":
            self._consecutive_skip_ticks += 1
            await asyncio.sleep(_DORMANT_POLL_SEC)
            return True
        if gate_result == "glance":
            # 休息期窥屏：只消耗少量体力，不进入完整流水线
            self._apply_glance_drain()
            self._consecutive_skip_ticks = 0
            await asyncio.sleep(_DORMANT_POLL_SEC)
            return True

        # ── 阶段 1：能量评估门控 ──
        eagerness_val, eagerness_reason = self._poll_eagerness()
        if eagerness_val < _ENERGY_DRAIN_FLOOR:
            # 能量严重不足，迁移至休息
            self._shift_to_dormant(cause=f"能量耗尽: {eagerness_reason}")
            await asyncio.sleep(_DORMANT_POLL_SEC)
            return True

        # ── 阶段 2：消息读取（复用父类逻辑的核心部分） ──
        incoming_batch = message_api.get_messages_by_time_in_chat(
            chat_id=self.stream_id,
            start_time=self.last_read_time,
            end_time=now,
            limit=20,
            limit_mode="latest",
            filter_mai=True,
            filter_command=False,
            filter_intercept_message_level=0,
        )
        dynamic_threshold = self._compute_dynamic_threshold()
        if len(incoming_batch) < dynamic_threshold:
            self._consecutive_skip_ticks += 1
            await asyncio.sleep(_TICK_FLOOR_SEC)
            return True

        self._consecutive_skip_ticks = 0
        self.last_read_time = now

        # 消息到达时立即记录行为与氛围
        self._record_message_behavior(incoming_batch)
        self._record_interaction_mood(incoming_batch)

        # 检查是否被 @ 或提及
        pinged_msg = self._find_pinged_message(incoming_batch)

        # ── 阶段 3：感知引擎与氛围采样 ──
        awareness_snapshot = None
        ambient_info = None
        if self._should_run_perception(now):
            awareness_snapshot = await self._invoke_perception(incoming_batch, now)
            self._cached_awareness = awareness_snapshot
            self._last_perception_ts = now
        else:
            awareness_snapshot = self._cached_awareness
        ambient_info = self._sample_channel_ambient()

        # ── 阶段 4：内心独白 ──
        voice_conclusion = None
        if self._should_run_voice(now, incoming_batch, pinged_msg):
            voice_conclusion = await self._invoke_inner_voice(
                incoming_batch, awareness_snapshot, ambient_info, now,
            )
            self._cached_voice = voice_conclusion
            self._last_voice_ts = now
        else:
            voice_conclusion = self._cached_voice

        # ── 阶段 5：行动决策（融合增强信号后委托基础版 _observe） ──
        should_act = self._decide_action(
            pinged_msg, eagerness_val, awareness_snapshot, voice_conclusion, incoming_batch,
        )
        if should_act:
            # 思考消耗
            self._apply_think_drain()
            await self._observe(
                recent_messages_list=incoming_batch,
                force_reply_message=pinged_msg,
            )
            # 回复消耗
            self._apply_reply_drain(incoming_batch)
        else:
            await asyncio.sleep(10)
            return True

        # ── 阶段 6：意图锻造（周期性） ──
        if self._should_run_forge():
            await self._invoke_intention_forge(incoming_batch)
            self._last_forge_round = self._enhanced_round

        # ── 阶段 7：触发条件扫描（周期性） ──
        if self._should_run_trigger_scan():
            await self._invoke_trigger_scan()
            self._last_trigger_scan_round = self._enhanced_round

        return True

    # ═══════════════════════════════════════════════════
    #  阶段 0：状态机门控
    # ═══════════════════════════════════════════════════

    def _query_flow_phase(self) -> str:
        """查询当前频道的心流阶段，返回阶段值字符串"""
        try:
            from src.chat.heart_flow.state_machine import get_phase_coordinator
            coordinator = get_phase_coordinator()
            phase = coordinator.current_phase(self.stream_id)
            return phase.value
        except Exception:
            return "engaged"

    def _evaluate_phase_gate(self, phase_str: str, now: float) -> str:
        """根据心流阶段决定本轮循环的行为

        返回值：
        - "proceed"  继续完整流水线
        - "skip"     跳过本轮（休息期不响应）
        - "glance"   休息期窥屏
        """
        if phase_str == "dormant":
            return self._handle_dormant_gate()
        if phase_str == "pending":
            return self._handle_pending_gate(now)
        if phase_str == "standby":
            # 待命阶段正常进入流水线，但迁移至 ENGAGED
            self._shift_to_engaged(cause="待命→活跃：消息到达")
            return "proceed"
        return "proceed"

    def _handle_dormant_gate(self) -> str:
        """休息期门控：委托 DormancySupervisor 决策"""
        try:
            from src.chat.heart_flow.rest_handler import get_dormancy_supervisor
            from src.common.data_models.heartflow_models import DormantReaction
            supervisor = get_dormancy_supervisor()
            reaction = supervisor.on_incoming_msg(self.stream_id)
            if reaction == DormantReaction.AWAKEN:
                self._shift_to_engaged(cause="休息结束被唤醒")
                return "proceed"
            if reaction == DormantReaction.GLANCE:
                return "glance"
            return "skip"
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 休息门控异常，放行: {exc}")
            return "proceed"

    def _handle_pending_gate(self, now: float) -> str:
        """等待期门控：委托 PendingOrchestrator 决策"""
        try:
            from src.chat.heart_flow.waiting_handler import get_pending_orchestrator
            from src.common.data_models.heartflow_models import IdleDecision
            orchestrator = get_pending_orchestrator()
            decision = orchestrator.evaluate_next(self.stream_id)
            if decision == IdleDecision.EXPIRED or decision == IdleDecision.WITHDRAW:
                self._shift_to_engaged(cause=f"等待结束: {decision.value}")
                return "proceed"
            if decision == IdleDecision.CONTEMPLATE:
                return "proceed"
            if decision == IdleDecision.CHASE:
                return "proceed"
            return "skip"
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 等待门控异常，放行: {exc}")
            return "proceed"

    # ═══════════════════════════════════════════════════
    #  阶段 1：能量评估
    # ═══════════════════════════════════════════════════

    def _poll_eagerness(self) -> Tuple[float, str]:
        """读取能量管理器计算的回复意愿度"""
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            pool = get_vitality_pool()
            return pool.compute_eagerness(self.stream_id)
        except Exception:
            return 1.0, "能量模块不可用，默认满意愿"

    def _apply_glance_drain(self) -> None:
        """窥屏消耗"""
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            get_vitality_pool().deplete_on_glance(self.stream_id)
        except Exception:
            pass

    def _apply_think_drain(self) -> None:
        """思考消耗"""
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            get_vitality_pool().deplete_on_think(self.stream_id)
        except Exception:
            pass

    def _apply_reply_drain(self, messages: List) -> None:
        """回复消耗，按消息总长度计算"""
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            total_len = sum(len(getattr(m, "processed_plain_text", "") or "") for m in messages)
            get_vitality_pool().deplete_on_reply(self.stream_id, content_length=total_len)
        except Exception:
            pass

    # ═══════════════════════════════════════════════════
    #  阶段 2 辅助：动态阈值与 @检测
    # ═══════════════════════════════════════════════════

    def _compute_dynamic_threshold(self) -> int:
        """根据连续跳过轮次动态升降消息触发阈值"""
        if self._consecutive_skip_ticks >= 5:
            return 2
        if self._consecutive_skip_ticks >= 3:
            return 2 if random.random() < 0.5 else 1
        return 1

    def _find_pinged_message(self, batch: List):
        """在消息批次中查找 @机器人 或提及机器人的消息"""
        if not global_config.chat.mentioned_bot_reply:
            return None
        for msg in batch:
            if getattr(msg, "is_mentioned", False) or getattr(msg, "is_at", False):
                return msg
        return None

    # ═══════════════════════════════════════════════════
    #  阶段 3：感知引擎
    # ═══════════════════════════════════════════════════

    def _should_run_perception(self, now: float) -> bool:
        """感知引擎有冷却间隔，避免每轮都跑 LLM"""
        return (now - self._last_perception_ts) >= _PERCEPTION_COOLDOWN_SEC

    async def _invoke_perception(self, messages: List, now: float):
        """调用觉察引擎，收集环境感知快照"""
        try:
            from src.chat.proactive.perception_engine import get_awareness_engine
            engine = get_awareness_engine()
            raw_msg_dicts = self._serialize_messages_for_perception(messages)
            self_state = self._collect_self_state()
            relation_state = self._collect_relation_state(messages)
            has_ping = any(
                getattr(m, "is_mentioned", False) or getattr(m, "is_at", False)
                for m in messages
            )
            verdict = await engine.gather_awareness(
                channel_id=self.stream_id,
                raw_messages=raw_msg_dicts,
                self_state=self_state,
                relation_state=relation_state,
                mention_bot=has_ping,
            )
            logger.debug(
                f"{self.log_prefix} 感知结果: "
                f"警戒={verdict.alert_grade.name} "
                f"参与度={verdict.engagement_pull:.2f} "
                f"群体={verdict.crowd_vibe.value}"
            )
            return verdict
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 感知引擎调用失败: {exc}")
            return None

    def _serialize_messages_for_perception(self, messages: List) -> List[Dict[str, Any]]:
        """将数据库消息对象序列化为感知引擎期望的字典列表"""
        result = []
        for msg in messages:
            result.append({
                "text": getattr(msg, "processed_plain_text", "") or "",
                "user_id": getattr(msg.user_info, "user_id", "") if hasattr(msg, "user_info") else "",
                "user_name": getattr(msg.user_info, "user_nickname", "") if hasattr(msg, "user_info") else "",
                "timestamp": getattr(msg, "time", 0.0) or time.time(),
            })
        return result

    def _collect_self_state(self) -> Dict[str, Any]:
        """收集机器人自身状态，供感知引擎参考"""
        state: Dict[str, Any] = {
            "channel_id": self.stream_id,
            "cycle_count": self._enhanced_round,
            "skip_ticks": self._consecutive_skip_ticks,
        }
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            snap = get_vitality_pool().capture_snapshot(self.stream_id)
            state["chat_pool"] = snap.chat_pool
            state["brain_pool"] = snap.brain_pool
            state["fatigue"] = snap.fatigue_level
            state["annoyance"] = snap.annoyance_level
        except Exception:
            pass
        return state

    def _collect_relation_state(self, messages: List) -> Dict[str, Any]:
        """收集频道社交关系信息"""
        unique_speakers = set()
        for msg in messages:
            uid = getattr(msg.user_info, "user_id", "") if hasattr(msg, "user_info") else ""
            if uid:
                unique_speakers.add(uid)
        return {
            "participant_count": len(unique_speakers),
            "speaker_ids": list(unique_speakers),
        }

    def _sample_channel_ambient(self) -> Optional[Dict[str, Any]]:
        """采样频道氛围"""
        try:
            from src.chat.heart_flow.emotion_stream import get_channel_mood_tracker
            tracker = get_channel_mood_tracker()
            ledger = tracker.fetch_mood(self.stream_id)
            return {
                "vitality": ledger.vitality,
                "weariness": ledger.weariness,
                "vexation": ledger.vexation,
                "category": ledger.category.value if hasattr(ledger.category, "value") else str(ledger.category),
            }
        except Exception:
            return None

    # ═══════════════════════════════════════════════════
    #  阶段 4：内心独白
    # ═══════════════════════════════════════════════════

    def _should_run_voice(self, now: float, messages: List, pinged) -> bool:
        """内心独白冷却判定：被 @ 时强制触发"""
        if pinged is not None:
            return True
        return (now - self._last_voice_ts) >= _VOICE_COOLDOWN_SEC

    async def _invoke_inner_voice(
        self,
        messages: List,
        awareness,
        ambient: Optional[Dict[str, Any]],
        now: float,
    ):
        """调用自我对话引擎，生成内心想法"""
        try:
            from src.chat.heart_flow.inner_voice import get_self_dialogue_engine
            engine = get_self_dialogue_engine(self.stream_id)
            # 取最新一条消息作为触发文本
            latest = messages[-1] if messages else None
            raw_text = getattr(latest, "processed_plain_text", "") if latest else ""
            speaker_name = ""
            speaker_id = ""
            if latest and hasattr(latest, "user_info"):
                speaker_name = getattr(latest.user_info, "user_nickname", "") or ""
                speaker_id = getattr(latest.user_info, "user_id", "") or ""
            # 从能量和氛围提取参数
            energy_params = self._extract_voice_energy_params()
            mood_params = self._extract_voice_mood_params(ambient)
            # 构建对话历史片段
            dialogue_fragment = self._build_dialogue_fragment(messages)
            phase_label = self._query_flow_phase()
            verdict = await engine.generate_reflection(
                heart_state_label=phase_label,
                raw_text=raw_text,
                speaker_name=speaker_name,
                dialogue_history=dialogue_fragment,
                assurance_score=energy_params.get("assurance", 0.5),
                involvement_score=energy_params.get("involvement", 0.5),
                mental_drain=energy_params.get("drain", 0.0),
                endurance=energy_params.get("endurance", 100.0),
                irritation=mood_params.get("irritation", 0.0),
                wound_score=mood_params.get("wound", 0.0),
                readiness=energy_params.get("readiness", 1.0),
                speaker_id=speaker_id,
            )
            if verdict.is_valid:
                logger.debug(
                    f"{self.log_prefix} 内心独白: "
                    f"欲望={verdict.reply_desire_level} "
                    f"情绪={verdict.current_mood} "
                    f"意图数={len(verdict.intents)}"
                )
            return verdict
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 内心独白调用失败: {exc}")
            return None

    def _extract_voice_energy_params(self) -> Dict[str, float]:
        """从能量快照提取供内心独白使用的参数"""
        result = {
            "assurance": 0.5,
            "involvement": 0.5,
            "drain": 0.0,
            "endurance": 100.0,
            "readiness": 1.0,
        }
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            pool = get_vitality_pool()
            snap = pool.capture_snapshot(self.stream_id)
            result["assurance"] = snap.chat_ratio()
            result["involvement"] = snap.brain_ratio()
            result["drain"] = snap.fatigue_level
            result["endurance"] = max(0.0, 100.0 - snap.fatigue_level)
            result["readiness"] = max(0.05, min(1.0, snap.chat_ratio() * snap.brain_ratio()))
        except Exception:
            pass
        return result

    def _extract_voice_mood_params(self, ambient: Optional[Dict[str, Any]]) -> Dict[str, float]:
        """从氛围采样提取供内心独白使用的参数"""
        result = {"irritation": 0.0, "wound": 0.0}
        if ambient is None:
            return result
        result["irritation"] = float(ambient.get("vexation", 0.0))
        result["wound"] = float(ambient.get("weariness", 0.0)) / 100.0
        return result

    def _build_dialogue_fragment(self, messages: List) -> List[Dict]:
        """将最近消息构建为内心独白使用的对话片段格式"""
        fragment = []
        for msg in messages[-8:]:
            entry: Dict[str, Any] = {
                "role": "user",
                "content": getattr(msg, "processed_plain_text", "") or "",
            }
            if hasattr(msg, "user_info"):
                entry["name"] = getattr(msg.user_info, "user_nickname", "") or ""
            fragment.append(entry)
        return fragment

    # ═══════════════════════════════════════════════════
    #  阶段 5：行动决策融合
    # ═══════════════════════════════════════════════════

    def _decide_action(
        self,
        pinged_msg,
        eagerness: float,
        awareness,
        voice,
        messages: List,
    ) -> bool:
        """融合多维信号决定本轮是否执行行动规划

        决策优先级：
        1. 被 @ → 强制行动
        2. 内心独白欲望等级 >= 7 → 强制行动
        3. 觉察引擎参与度 > 阈值 → 高概率行动
        4. 能量意愿 × 频率因子 → 概率行动
        """
        # 强制条件
        if pinged_msg is not None:
            return True
        # 内心独白强驱动
        if voice is not None and hasattr(voice, "reply_desire_level"):
            if voice.reply_desire_level >= 7:
                return True
        # 觉察参与度驱动
        engagement_boost = 0.0
        if awareness is not None and hasattr(awareness, "engagement_pull"):
            engagement_boost = awareness.engagement_pull
            if engagement_boost >= 0.7:
                return True
        # 概率决策：基础意愿 × 频率调节 × 觉察加成
        freq_adjust = frequency_control_manager.get_or_create_frequency_control(
            self.stream_id
        ).get_talk_frequency_adjust()
        base_talk = global_config.chat.get_talk_value(self.stream_id)
        combined_prob = base_talk * freq_adjust * eagerness
        # 觉察加成：参与度在 0.3~0.7 区间提供线性加成
        if 0.3 <= engagement_boost < 0.7:
            combined_prob *= (1.0 + engagement_boost)
        # 内心独白加成：欲望等级 4~6 提供小幅加成
        if voice is not None and hasattr(voice, "reply_desire_level"):
            desire = voice.reply_desire_level
            if 4 <= desire < 7:
                combined_prob *= (1.0 + desire * 0.05)
        return random.random() < combined_prob

    # ═══════════════════════════════════════════════════
    #  阶段 6：意图锻造（周期性）
    # ═══════════════════════════════════════════════════

    def _should_run_forge(self) -> bool:
        """每隔固定轮次执行一次意图锻造"""
        return (self._enhanced_round - self._last_forge_round) >= _PLANNER_SWEEP_ROUNDS

    async def _invoke_intention_forge(self, messages: List) -> None:
        """调用意图锻造器生成主动行动蓝图"""
        try:
            from src.chat.proactive.self_planner import get_intention_forge
            forge = get_intention_forge()
            context = {
                "channel_id": self.stream_id,
                "round": self._enhanced_round,
                "message_count": len(messages),
            }
            # 添加觉察信息
            if self._cached_awareness is not None:
                context["engagement"] = self._cached_awareness.engagement_pull
                context["crowd_vibe"] = self._cached_awareness.crowd_vibe.value
            # 添加氛围信息
            ambient = self._sample_channel_ambient()
            if ambient:
                context["mood_category"] = ambient.get("category", "unknown")
            blueprint = await forge.forge_initiative_blueprint(
                channel_id=self.stream_id,
                occasion_desc=f"增强循环第{self._enhanced_round}轮周期性规划",
                context_info=context,
            )
            if blueprint.get("success"):
                logger.debug(
                    f"{self.log_prefix} 意图锻造成功: "
                    f"行动数={len(blueprint.get('actions', []))}"
                )
                # 将锻造结果注入思考调度器
                self._feed_blueprint_to_scheduler(blueprint)
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 意图锻造调用失败: {exc}")

    def _feed_blueprint_to_scheduler(self, blueprint: Dict[str, Any]) -> None:
        """将意图锻造结果提交给思考调度器排队"""
        try:
            from src.chat.proactive.think_scheduler import get_cognitive_dispatcher, JobDomain, JobUrgency
            dispatcher = get_cognitive_dispatcher()
            actions = blueprint.get("actions", [])
            thought = blueprint.get("thought", "")
            if not actions:
                return
            dispatcher.enqueue_job(
                domain=JobDomain.IMPULSE_LAUNCH,
                target_user="",
                target_channel=self.stream_id,
                urgency=JobUrgency.STANDARD,
                payload={
                    "source": "intention_forge",
                    "thought": thought,
                    "actions": actions,
                    "round": self._enhanced_round,
                },
            )
        except Exception:
            pass

    # ═══════════════════════════════════════════════════
    #  阶段 7：触发条件扫描（周期性）
    # ═══════════════════════════════════════════════════

    def _should_run_trigger_scan(self) -> bool:
        """触发条件扫描间隔更长"""
        return (self._enhanced_round - self._last_trigger_scan_round) >= _TRIGGER_SCAN_ROUNDS

    async def _invoke_trigger_scan(self) -> None:
        """扫描时间型触发条件，发现符合条件的提交给调度器"""
        try:
            from src.chat.proactive.trigger_hooks import get_activation_sentinel
            sentinel = get_activation_sentinel()
            fired_conditions = await sentinel.scan_temporal_signals(
                channel_id=self.stream_id,
            )
            if fired_conditions:
                logger.debug(
                    f"{self.log_prefix} 触发扫描命中 {len(fired_conditions)} 个条件"
                )
                self._dispatch_fired_conditions(fired_conditions)
            # 额外扫描日历类型
            calendar_hits = await sentinel.scan_calendar_signals()
            if calendar_hits:
                logger.debug(
                    f"{self.log_prefix} 日历触发命中 {len(calendar_hits)} 个条件"
                )
                self._dispatch_fired_conditions(calendar_hits)
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 触发扫描调用失败: {exc}")

    def _dispatch_fired_conditions(self, conditions: List) -> None:
        """将触发的条件推送给思考调度器"""
        try:
            from src.chat.proactive.think_scheduler import get_cognitive_dispatcher, JobDomain, JobUrgency
            dispatcher = get_cognitive_dispatcher()
            for cond in conditions:
                dispatcher.enqueue_job(
                    domain=JobDomain.IMPULSE_LAUNCH,
                    target_user="",
                    target_channel=self.stream_id,
                    urgency=JobUrgency.ELEVATED,
                    payload={
                        "source": "trigger_scan",
                        "condition": cond.to_dict() if hasattr(cond, "to_dict") else str(cond),
                        "round": self._enhanced_round,
                    },
                )
        except Exception:
            pass

    # ═══════════════════════════════════════════════════
    #  状态迁移辅助
    # ═══════════════════════════════════════════════════

    def _shift_to_dormant(self, cause: str = "") -> None:
        """迁移至休息阶段"""
        try:
            from src.chat.heart_flow.state_machine import get_phase_coordinator
            from src.common.data_models.heartflow_models import FlowPhase
            coordinator = get_phase_coordinator()
            shifted = coordinator.attempt_shift(
                self.stream_id, FlowPhase.DORMANT, reason=cause,
            )
            if shifted:
                # 通知休息管理器开始休息
                from src.chat.heart_flow.rest_handler import get_dormancy_supervisor
                get_dormancy_supervisor().begin_dormancy(self.stream_id, cause=cause)
                logger.info(f"{self.log_prefix} 迁移至休息: {cause}")
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 迁移休息失败: {exc}")

    def _shift_to_engaged(self, cause: str = "") -> None:
        """迁移至活跃阶段"""
        try:
            from src.chat.heart_flow.state_machine import get_phase_coordinator
            from src.common.data_models.heartflow_models import FlowPhase
            coordinator = get_phase_coordinator()
            coordinator.attempt_shift(
                self.stream_id, FlowPhase.ENGAGED, reason=cause,
            )
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 迁移活跃失败: {exc}")

    def _shift_to_pending(self, cause: str = "", anticipated: str = "") -> None:
        """迁移至等待阶段"""
        try:
            from src.chat.heart_flow.state_machine import get_phase_coordinator
            from src.common.data_models.heartflow_models import FlowPhase
            coordinator = get_phase_coordinator()
            shifted = coordinator.attempt_shift(
                self.stream_id, FlowPhase.PENDING, reason=cause,
            )
            if shifted and anticipated:
                from src.chat.heart_flow.waiting_handler import get_pending_orchestrator
                get_pending_orchestrator().initiate_watch(
                    self.stream_id, anticipated=anticipated,
                )
        except Exception as exc:
            logger.debug(f"{self.log_prefix} 迁移等待失败: {exc}")

    # ═══════════════════════════════════════════════════
    #  行为分析辅助
    # ═══════════════════════════════════════════════════

    def _record_message_behavior(self, messages: List) -> None:
        """将消息行为记录到行为分析器"""
        try:
            from src.chat.heart_flow.behavior_analyzer import get_behavior_analyzer
            analyzer = get_behavior_analyzer()
            for msg in messages:
                uid = getattr(msg.user_info, "user_id", "") if hasattr(msg, "user_info") else ""
                if not uid:
                    continue
                text = getattr(msg, "processed_plain_text", "") or ""
                polarity = self._estimate_text_polarity(text)
                analyzer.record(uid, polarity)
        except Exception:
            pass

    def _estimate_text_polarity(self, text: str) -> float:
        """极简文本极性估计：正面词 +0.3，负面词 -0.3，默认 0"""
        positive_markers = ("哈哈", "不错", "好的", "谢谢", "厉害", "棒", "可以", "喜欢", "赞")
        negative_markers = ("不行", "差", "烦", "滚", "讨厌", "垃圾", "无聊", "别")
        score = 0.0
        for marker in positive_markers:
            if marker in text:
                score += 0.3
                break
        for marker in negative_markers:
            if marker in text:
                score -= 0.3
                break
        return max(-1.0, min(1.0, score))

    # ═══════════════════════════════════════════════════
    #  氛围反馈
    # ═══════════════════════════════════════════════════

    def _record_interaction_mood(self, messages: List) -> None:
        """将交互记录到氛围追踪器"""
        try:
            from src.chat.heart_flow.emotion_stream import get_channel_mood_tracker
            tracker = get_channel_mood_tracker()
            for msg in messages:
                text = getattr(msg, "processed_plain_text", "") or ""
                uid = getattr(msg.user_info, "user_id", "") if hasattr(msg, "user_info") else ""
                if text and uid:
                    tracker.record_inquiry(
                        channel_id=self.stream_id,
                        content=text,
                        author_id=uid,
                    )
        except Exception:
            pass