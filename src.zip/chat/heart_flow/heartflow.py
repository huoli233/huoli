import asyncio
import traceback
import time as _tm
from typing import Any, Optional, Dict, List

from src.chat.message_receive.chat_stream import get_chat_manager
from src.common.logger import get_logger
from src.chat.heart_flow.heartFC_chat import HeartFChatting
from src.chat.heart_flow.heartFC_chat_enhanced import EnhancedHeartFChatting
from src.chat.brain_chat.brain_chat import BrainChatting
from src.chat.message_receive.chat_stream import ChatStream

logger = get_logger("heartflow")


def _module_switch_on(name: str, default: bool = True) -> bool:
    try:
        from src.config.core_config_engine import get_core_config

        return bool(get_core_config().is_module_on(name))
    except Exception:
        return default


def _enhanced_focus_route_enabled() -> bool:
    return _module_switch_on("enhanced_focus_route_enabled", True)


def _proactive_pipeline_enabled() -> bool:
    return _module_switch_on("proactive_enabled", True)


class Heartflow:
    """主心流协调器

    职责:
      - 管理频道和 HeartFChatting/BrainChatting 的映射
      - 提供统一的生命周期(启动/停止/清理)
      - 集成状态管理器、独立监控器
      - 定期清理长时间未活跃的聊天实例
    """

    def __init__(self):
        self.heartflow_chat_list: Dict[
            Any,
            HeartFChatting | EnhancedHeartFChatting | BrainChatting,
        ] = {}
        self._creation_locks: Dict[Any, asyncio.Lock] = {}
        self._active_since: Dict[Any, float] = {}
        self._started = False
        self._cleanup_task: Optional[asyncio.Task] = None

    # ---- 生命周期 ----

    async def startup(self) -> None:
        """启动心流系统及后台监控"""
        if self._started:
            return
        self._started = True
        try:
            from src.config.core_config_engine import boot_core_config

            boot_core_config()
        except Exception as exc:
            logger.warning(f"[心流] 核心配置启动异常: {exc}")
        try:
            from src.chat.heart_flow.system_calibration import acquire_system_calibrator
            calibrator = acquire_system_calibrator()
            summary = calibrator.calibrate_and_propagate()
            logger.info(
                f"[心流] 启动校准完成: {summary.level}, "
                f"亲密度变化{summary.intimacy_delta:+.1f}"
            )
        except Exception as exc:
            logger.warning(f"[心流] 启动校准异常: {exc}")
        try:
            if _enhanced_focus_route_enabled() and _proactive_pipeline_enabled():
                from src.chat.proactive.think_executor import wire_up_handlers
                from src.chat.proactive.think_scheduler import get_cognitive_dispatcher

                await wire_up_handlers()
                await get_cognitive_dispatcher().start()
        except Exception as exc:
            logger.warning(f"[心流] 主动调度启动异常: {exc}")
        try:
            from src.chat.heart_flow.independent_monitor import acquire_independent_monitor

            monitor = acquire_independent_monitor()
            monitor.set_reply_callback(self._handle_monitor_reply)
            monitor.start()
        except Exception as exc:
            logger.warning(f"[心流] 监控器启动异常: {exc}")
        self._cleanup_task = asyncio.ensure_future(self._periodic_cleanup_loop())
        logger.info("[心流] 主协调器已启动")

    async def shutdown(self) -> None:
        """优雅关闭所有聊天实例和后台服务"""
        logger.info(f"[心流] 正在关闭, 活跃聊天数: {len(self.heartflow_chat_list)}")
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        try:
            if _proactive_pipeline_enabled():
                from src.chat.proactive.think_scheduler import get_cognitive_dispatcher

                await get_cognitive_dispatcher().stop()
        except Exception:
            pass
        try:
            from src.chat.heart_flow.independent_monitor import acquire_independent_monitor
            acquire_independent_monitor().stop()
        except Exception:
            pass
        try:
            from src.chat.heart_flow.user_state_detector import acquire_engagement_probe
            saved = acquire_engagement_probe().persist_all_active()
            if saved:
                logger.info(f"[心流] 用户参与度快照已保存 {saved} 人")
        except Exception:
            pass
        try:
            from src.chat.heart_flow.energy_manager import get_vitality_pool
            e_saved = get_vitality_pool().persist_all_channels()
            if e_saved:
                logger.info(f"[心流] 能量快照已保存 {e_saved} 个频道")
        except Exception:
            pass
        try:
            from src.chat.heart_flow.state_machine import get_phase_coordinator
            get_phase_coordinator().persist_phases()
        except Exception:
            pass
        try:
            from src.chat.heart_flow.emotion_stream import get_channel_mood_tracker
            get_channel_mood_tracker().save_to_persistent_store()
        except Exception:
            pass
        try:
            from src.chat.heart_flow.persona_engine import CharacterFoundry
            CharacterFoundry.teardown()
        except Exception:
            pass
        try:
            from src.chat.heart_flow.inner_voice import clear_all_engines
            clear_all_engines()
        except Exception:
            pass
        try:
            from src.chat.heart_flow.persistent_state_db import acquire_persistent_store
            flushed = acquire_persistent_store().flush()
            logger.info(f"[心流] 持久化刷盘 {flushed} 条")
        except Exception:
            pass
        try:
            from src.chat.proactive.session_tracker import get_memoir_cabinet

            saved = await get_memoir_cabinet().persist_all()
            if saved:
                logger.info(f"[心流] 主动回忆录已保存 {saved} 份")
        except Exception:
            pass
        for chat_id in list(self.heartflow_chat_list.keys()):
            await self._teardown_chat(chat_id)
        self.heartflow_chat_list.clear()
        self._active_since.clear()
        self._started = False
        logger.info("[心流] 主协调器已关闭")

    # ---- 聊天实例获取/创建 ----

    async def get_or_create_heartflow_chat(
        self, chat_id: Any
    ) -> Optional[HeartFChatting | EnhancedHeartFChatting | BrainChatting]:
        """获取或创建聊天实例（线程安全）"""
        existing = self.heartflow_chat_list.get(chat_id)
        if existing is not None:
            self._active_since[chat_id] = _tm.time()
            return existing
        lock = self._creation_locks.setdefault(chat_id, asyncio.Lock())
        async with lock:
            if chat_id in self.heartflow_chat_list:
                self._active_since[chat_id] = _tm.time()
                return self.heartflow_chat_list[chat_id]
            try:
                chat_stream: ChatStream | None = get_chat_manager().get_stream(chat_id)
                if not chat_stream:
                    raise ValueError(f"未找到 chat_id={chat_id} 的聊天流")
                if chat_stream.group_info:
                    if _enhanced_focus_route_enabled():
                        new_chat = EnhancedHeartFChatting(chat_id=chat_id)
                    else:
                        new_chat = HeartFChatting(chat_id=chat_id)
                else:
                    new_chat = BrainChatting(chat_id=chat_id)
                await new_chat.start()
                self.heartflow_chat_list[chat_id] = new_chat
                self._active_since[chat_id] = _tm.time()
                logger.info(
                    f"[心流] 创建聊天实例 {chat_id}, "
                    f"类型={'群聊' if chat_stream.group_info else '私聊'}"
                )
                return new_chat
            except Exception as e:
                logger.error(f"创建心流聊天 {chat_id} 失败: {e}", exc_info=True)
                traceback.print_exc()
                return None

    # ---- 清理 ----

    async def cleanup_inactive(self, max_idle_sec: float = 1800.0) -> int:
        """清理长时间未活跃的聊天实例"""
        now = _tm.time()
        stale_ids: List[Any] = []
        for chat_id, last_active in self._active_since.items():
            if now - last_active > max_idle_sec:
                stale_ids.append(chat_id)
        for chat_id in stale_ids:
            await self._teardown_chat(chat_id)
            self.heartflow_chat_list.pop(chat_id, None)
            self._active_since.pop(chat_id, None)
        if stale_ids:
            logger.info(f"[心流] 清理了 {len(stale_ids)} 个不活跃聊天")
        return len(stale_ids)

    async def _teardown_chat(self, chat_id: Any) -> None:
        """安全关闭单个聊天实例"""
        chat = self.heartflow_chat_list.get(chat_id)
        if chat is None:
            return
        self._flush_channel_state(chat_id)
        try:
            if hasattr(chat, "stop"):
                await chat.stop()
        except Exception as exc:
            logger.warning(f"[心流] 关闭聊天 {chat_id} 异常: {exc}")

    @staticmethod
    def _flush_channel_state(channel_id: Any) -> None:
        """通知下游模块刷新该频道的缓存或持久化数据"""
        try:
            from src.chat.heart_flow.heartflow_decision import acquire_decision_maker
            acquire_decision_maker().signal_activity_change(str(channel_id))
        except Exception:
            pass
        try:
            from src.chat.heart_flow.user_state_detector import acquire_engagement_probe
            acquire_engagement_probe().persist_report(str(channel_id))
        except Exception:
            pass

    async def _handle_monitor_reply(
        self,
        stream_id: str,
        prompt_text: str,
        meta: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """承接独立监控器的回调。

        reactive 消息批次只用于唤醒/保活现有聊天主链，避免重复回复；
        proactive 沉默触发则通过第三版主动调度链执行真实发送。
        """
        meta = meta or {}
        await self.get_or_create_heartflow_chat(stream_id)
        self.touch(stream_id)

        if meta.get("kind") != "proactive":
            return False
        if not (_enhanced_focus_route_enabled() and _proactive_pipeline_enabled()):
            return False
        try:
            from src.chat.proactive.think_scheduler import (
                JobDomain,
                JobUrgency,
                get_cognitive_dispatcher,
            )

            dispatcher = get_cognitive_dispatcher()
            job_id = dispatcher.enqueue_job(
                domain=JobDomain.IMPULSE_LAUNCH,
                target_user=str(stream_id),
                target_channel=str(stream_id),
                urgency=JobUrgency.ELEVATED,
                payload={
                    "trigger_reason": prompt_text,
                    "silence_duration": meta.get("silence_seconds", 0.0),
                    "source": "independent_monitor",
                },
                delay_sec=0.0,
            )
            if not job_id:
                logger.debug(f"[心流] {stream_id} 主动任务入队失败")
                return False
            return await self._await_proactive_job(job_id)
        except Exception as exc:
            logger.warning(f"[心流] 主动回复桥接异常: {exc}")
            return False

    async def _await_proactive_job(self, job_id: str, timeout: float = 45.0) -> bool:
        """等待主动调度任务执行结束，并返回发送是否成功。"""
        from src.chat.proactive.think_scheduler import get_cognitive_dispatcher

        dispatcher = get_cognitive_dispatcher()
        deadline = _tm.time() + timeout
        while _tm.time() < deadline:
            job = dispatcher.lookup_job(job_id)
            if job is None:
                return False
            if job.phase in ("done", "failed", "timeout", "expired", "cancelled"):
                if job.phase != "done":
                    return False
                if isinstance(job.outcome, dict):
                    return bool(job.outcome.get("succeeded"))
                return True
            await asyncio.sleep(0.25)
        dispatcher.revoke_job(job_id)
        logger.debug(f"[心流] 主动任务等待超时: {job_id}")
        return False

    # ---- 状态查询 ----

    def active_chat_count(self) -> int:
        return len(self.heartflow_chat_list)

    def list_active_chats(self) -> List[Any]:
        return list(self.heartflow_chat_list.keys())

    def touch(self, chat_id: Any) -> None:
        """手动标记频道活跃"""
        self._active_since[chat_id] = _tm.time()

    async def _periodic_cleanup_loop(self) -> None:
        """后台协程，定期回收不活跃聊天实例"""
        while True:
            try:
                await asyncio.sleep(300.0)
                await self.cleanup_inactive()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.debug(f"[心流] 周期清理异常: {exc}")


heartflow = Heartflow()
