import time as _tm
from typing import Dict, Optional

from src.common.logger import get_logger

logger = get_logger("frequency_control")


# ---------------------------------------------------------------------------
#  衰减参数
# ---------------------------------------------------------------------------
_DECAY_HALF_LIFE_SEC = 300.0   # 频率调整值半衰期（秒）
_MIN_FACTOR = 0.1
_MAX_FACTOR = 5.0
_DEFAULT_FACTOR = 1.0


class FrequencyControl:
    """频率控制器，管理单个频道的发言频率调整

    支持:
      - 手动加减频率
      - 基于消息长度自适应微调
      - 随时间自然衰减回归默认值
    """

    def __init__(self, chat_id: str):
        self.chat_id = chat_id
        self.talk_frequency_adjust: float = _DEFAULT_FACTOR
        self._last_adjust_ts: float = _tm.time()
        self._cumulative_boost: float = 0.0

    def _apply_decay(self) -> None:
        """按半衰期对频率因子做自然衰减"""
        import math
        now = _tm.time()
        elapsed = now - self._last_adjust_ts
        if elapsed <= 0:
            return
        diff = self.talk_frequency_adjust - _DEFAULT_FACTOR
        if abs(diff) < 0.01:
            self.talk_frequency_adjust = _DEFAULT_FACTOR
            self._last_adjust_ts = now
            return
        decay = math.exp(-0.693 * elapsed / _DECAY_HALF_LIFE_SEC)
        self.talk_frequency_adjust = _DEFAULT_FACTOR + diff * decay
        self._last_adjust_ts = now

    def get_talk_frequency_adjust(self) -> float:
        """获取当前频率因子（先执行衰减）"""
        self._apply_decay()
        return self.talk_frequency_adjust

    def set_talk_frequency_adjust(self, value: float) -> None:
        """设置频率因子，限制在合理范围"""
        self.talk_frequency_adjust = max(_MIN_FACTOR, min(_MAX_FACTOR, value))
        self._last_adjust_ts = _tm.time()
        logger.debug(f"[{self.chat_id}] 频率因子→{self.talk_frequency_adjust:.2f}")

    def increase_frequency(self, delta: float = 0.1) -> None:
        """提高发言频率"""
        self._apply_decay()
        self.set_talk_frequency_adjust(self.talk_frequency_adjust + delta)

    def decrease_frequency(self, delta: float = 0.1) -> None:
        """降低发言频率"""
        self._apply_decay()
        self.set_talk_frequency_adjust(self.talk_frequency_adjust - delta)

    def reset_frequency(self) -> None:
        """重置为默认值"""
        self.talk_frequency_adjust = _DEFAULT_FACTOR
        self._cumulative_boost = 0.0
        self._last_adjust_ts = _tm.time()

    def adapt_by_message_length(self, msg_length: int) -> None:
        """根据消息长度自适应微调

        长消息 → 稍微提高频率（对方在认真聊）
        极短消息 → 稍微降低频率（对方可能不想聊）
        """
        if msg_length > 80:
            self.increase_frequency(0.05)
        elif msg_length < 5:
            self.decrease_frequency(0.03)

    def adapt_by_interval(self, seconds_since_last_msg: float) -> None:
        """根据消息间隔自适应微调

        消息来得快 → 提高频率
        消息来得慢 → 降低频率
        """
        if seconds_since_last_msg < 5.0:
            self.increase_frequency(0.08)
        elif seconds_since_last_msg > 60.0:
            self.decrease_frequency(0.05)

    def effective_probability(self, base_prob: float) -> float:
        """计算有效回复概率 = 基础概率 × 频率因子"""
        factor = self.get_talk_frequency_adjust()
        return min(1.0, max(0.0, base_prob * factor))


class FrequencyControlManager:
    """频率控制管理器，管理多个频道的频率控制实例"""

    def __init__(self):
        self.frequency_control_dict: Dict[str, FrequencyControl] = {}

    def get_or_create_frequency_control(self, chat_id: str) -> FrequencyControl:
        """获取或创建指定频道的频率控制实例"""
        if chat_id not in self.frequency_control_dict:
            self.frequency_control_dict[chat_id] = FrequencyControl(chat_id)
            logger.debug(f"创建频率控制实例: {chat_id}")
        return self.frequency_control_dict[chat_id]

    def remove_frequency_control(self, chat_id: str) -> bool:
        """移除指定频道的频率控制实例"""
        if chat_id in self.frequency_control_dict:
            del self.frequency_control_dict[chat_id]
            logger.debug(f"移除频率控制实例: {chat_id}")
            return True
        return False

    def cleanup_stale(self, max_idle_sec: float = 1800.0) -> int:
        """清理长时间未调整的频率控制实例"""
        now = _tm.time()
        stale = [
            cid for cid, ctrl in self.frequency_control_dict.items()
            if now - ctrl._last_adjust_ts > max_idle_sec
        ]
        for cid in stale:
            del self.frequency_control_dict[cid]
        if stale:
            logger.info(f"清理了 {len(stale)} 个过期频率控制实例")
        return len(stale)

    def get_all_chat_ids(self) -> list:
        """获取所有有频率控制的聊天ID"""
        return list(self.frequency_control_dict.keys())

    def adjust_all_frequency(self, factor: float) -> None:
        """对所有频道的频率因子乘以指定系数"""
        for ctrl in self.frequency_control_dict.values():
            ctrl.set_talk_frequency_adjust(ctrl.talk_frequency_adjust * factor)

    def summary(self) -> Dict[str, float]:
        """返回所有频道当前频率因子"""
        return {
            cid: ctrl.get_talk_frequency_adjust()
            for cid, ctrl in self.frequency_control_dict.items()
        }


# ---------------------------------------------------------------------------
#  模块级单例
# ---------------------------------------------------------------------------

frequency_control_manager = FrequencyControlManager()

_manager_ref: Optional[FrequencyControlManager] = None


def acquire_frequency_manager() -> FrequencyControlManager:
    global _manager_ref
    if _manager_ref is None:
        _manager_ref = FrequencyControlManager()
    return _manager_ref
