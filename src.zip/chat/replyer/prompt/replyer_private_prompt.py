from typing import Optional
from src.chat.utils.prompt_builder import Prompt, global_prompt_manager


# ---------------------------------------------------------------------------
#  私聊提示词辅助函数
# ---------------------------------------------------------------------------

def get_private_responder_prompt(
    *,
    sender_name: str = "",
    identity: str = "",
    chat_prompt: str = "",
    reply_style: str = "",
    keywords_reaction_prompt: str = "",
    knowledge_prompt: str = "",
    tool_info_block: str = "",
    extra_info_block: str = "",
    expression_habits_block: str = "",
    memory_retrieval: str = "",
    jargon_explanation: str = "",
    time_block: str = "",
    dialogue_prompt: str = "",
    reply_target_block: str = "",
    planner_reasoning: str = "",
    moderation_prompt: str = "",
) -> str:
    """渲染私聊回复提示词"""
    template = global_prompt_manager.get_prompt("private_replyer_prompt")
    if not template:
        return ""
    return template.format(
        sender_name=sender_name,
        identity=identity,
        chat_prompt=chat_prompt,
        reply_style=reply_style,
        keywords_reaction_prompt=keywords_reaction_prompt,
        knowledge_prompt=knowledge_prompt,
        tool_info_block=tool_info_block,
        extra_info_block=extra_info_block,
        expression_habits_block=expression_habits_block,
        memory_retrieval=memory_retrieval,
        jargon_explanation=jargon_explanation,
        time_block=time_block,
        dialogue_prompt=dialogue_prompt,
        reply_target_block=reply_target_block,
        planner_reasoning=planner_reasoning,
        moderation_prompt=moderation_prompt,
    )


def get_self_continuation_prompt(
    *,
    sender_name: str = "",
    target: str = "",
    reason: str = "",
    identity: str = "",
    chat_prompt: str = "",
    reply_style: str = "",
    keywords_reaction_prompt: str = "",
    knowledge_prompt: str = "",
    tool_info_block: str = "",
    extra_info_block: str = "",
    expression_habits_block: str = "",
    memory_retrieval: str = "",
    jargon_explanation: str = "",
    time_block: str = "",
    dialogue_prompt: str = "",
    moderation_prompt: str = "",
) -> str:
    """渲染私聊自我补充提示词"""
    template = global_prompt_manager.get_prompt("private_replyer_self_prompt")
    if not template:
        return ""
    return template.format(
        sender_name=sender_name,
        target=target,
        reason=reason,
        identity=identity,
        chat_prompt=chat_prompt,
        reply_style=reply_style,
        keywords_reaction_prompt=keywords_reaction_prompt,
        knowledge_prompt=knowledge_prompt,
        tool_info_block=tool_info_block,
        extra_info_block=extra_info_block,
        expression_habits_block=expression_habits_block,
        memory_retrieval=memory_retrieval,
        jargon_explanation=jargon_explanation,
        time_block=time_block,
        dialogue_prompt=dialogue_prompt,
        moderation_prompt=moderation_prompt,
    )


def init_replyer_private_prompt():
    Prompt(
        """{knowledge_prompt}{tool_info_block}{extra_info_block}
    {expression_habits_block}{memory_retrieval}{jargon_explanation}

    你正在和{sender_name}聊天，这是你们之前聊的内容:
    {time_block}
    {dialogue_prompt}

    {reply_target_block}。
    {planner_reasoning}
    {identity}
    {chat_prompt}你正在和{sender_name}聊天,现在请你读读之前的聊天记录，然后给出日常且口语化的回复，平淡一些，
    尽量简短一些。{keywords_reaction_prompt}请注意把握聊天内容，不要回复的太有条理。
    {reply_style}
    请注意不要输出多余内容(包括前后缀，冒号和引号，括号，表情等)，只输出回复内容。
    {moderation_prompt}不要输出多余内容(包括前后缀，冒号和引号，括号，表情包，at或 @等 )。""",
        "private_replyer_prompt",
    )

    Prompt(
        """{knowledge_prompt}{tool_info_block}{extra_info_block}
{expression_habits_block}{memory_retrieval}{jargon_explanation}

你正在和{sender_name}聊天，这是你们之前聊的内容:
{time_block}
{dialogue_prompt}

你现在想补充说明你刚刚自己的发言内容：{target}，原因是{reason}
请你根据聊天内容，组织一条新回复。注意，{target} 是刚刚你自己的发言，你要在这基础上进一步发言，请按照你自己的角度来继续进行回复。注意保持上下文的连贯性。
{identity}
{chat_prompt}尽量简短一些。{keywords_reaction_prompt}请注意把握聊天内容，不要回复的太有条理，可以有个性。
{reply_style}
请注意不要输出多余内容(包括前后缀，冒号和引号，括号，表情等)，只输出回复内容。
{moderation_prompt}不要输出多余内容(包括冒号和引号，括号，表情包，at或 @等 )。
""",
        "private_replyer_self_prompt",
    )
