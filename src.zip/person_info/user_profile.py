import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from src.common.config.config_engine import ConfigEngine
from src.common.logger import get_logger

logger = get_logger("user_profile")


@dataclass
class UserArchive:
    """用户档案 - 汇聚一个用户的全量静态+统计信息"""
    uid: str = ""
    alias: str = ""
    shown_name: str = ""
    first_encounter: float = field(default_factory=time.time)
    latest_encounter: float = field(default_factory=time.time)
    encounter_count: int = 0
    labels: Set[str] = field(default_factory=set)
    remarks: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    def serialize(self) -> Dict[str, Any]:
        """序列化为可持久化的字典"""
        return {
            "uid": self.uid,
            "alias": self.alias,
            "shown_name": self.shown_name,
            "first_encounter": self.first_encounter,
            "latest_encounter": self.latest_encounter,
            "encounter_count": self.encounter_count,
            "labels": sorted(self.labels),
            "remarks": self.remarks[-50:],
            "extra": self.extra,
        }

    @classmethod
    def deserialize(cls, data: Dict[str, Any]) -> "UserArchive":
        """从字典还原"""
        return cls(
            uid=data.get("uid", ""),
            alias=data.get("alias", ""),
            shown_name=data.get("shown_name", ""),
            first_encounter=data.get("first_encounter", time.time()),
            latest_encounter=data.get("latest_encounter", time.time()),
            encounter_count=data.get("encounter_count", 0),
            labels=set(data.get("labels", [])),
            remarks=data.get("remarks", []),
            extra=data.get("extra", {}),
        )


class UserProfileManager:
    """用户档案管理器

    职责:
        - 维护内存中的用户档案缓存
        - 在用户首次出现时自动创建空档案
        - 每次交互自动递增 encounter_count 并更新 latest_encounter
        - 通过适配器接口实现持久化

    不负责:
        - 认知偏好存储（由 CognitiveStore 管理）
        - 情感/社交数值（由 SocialValueCore 管理）
    """

    _MAX_REMARKS = 50

    def __init__(self, config_engine: Optional[ConfigEngine] = None, adapter: Any = None):
        self._config = config_engine or ConfigEngine.get_instance()
        self._adapter = adapter
        self._archives: Dict[str, UserArchive] = {}
        self._load_config()

    def _load_config(self):
        """加载配置"""
        self._MAX_REMARKS = self._config.get("user_profile", "max_remarks", 50)

    def bind_adapter(self, adapter: Any) -> None:
        """绑定持久化适配器"""
        self._adapter = adapter

    def touch(self, uid: str, shown_name: str = "") -> UserArchive:
        """记录一次用户出现，不存在则自动创建"""
        archive = self._ensure_loaded(uid)
        archive.encounter_count += 1
        archive.latest_encounter = time.time()
        if shown_name and not archive.shown_name:
            archive.shown_name = shown_name
        return archive

    async def touch_async(self, uid: str, shown_name: str = "") -> UserArchive:
        """异步记录用户出现"""
        return self.touch(uid, shown_name)

    def get_archive(self, uid: str) -> UserArchive:
        """获取用户档案，不存在则创建空档案"""
        return self._ensure_loaded(uid)

    async def get_archive_async(self, uid: str) -> UserArchive:
        """异步获取用户档案"""
        return self.get_archive(uid)

    def attach_label(self, uid: str, label: str) -> None:
        """给用户贴标签"""
        archive = self._ensure_loaded(uid)
        archive.labels.add(label)

    def detach_label(self, uid: str, label: str) -> None:
        """移除用户标签"""
        archive = self._ensure_loaded(uid)
        archive.labels.discard(label)

    def has_label(self, uid: str, label: str) -> bool:
        """检查用户是否有某标签"""
        archive = self._archives.get(uid)
        return archive is not None and label in archive.labels

    def get_labels(self, uid: str) -> List[str]:
        """获取用户所有标签"""
        archive = self._archives.get(uid)
        return list(archive.labels) if archive else []

    def append_remark(self, uid: str, note: str) -> None:
        """追加备注，保留最近 _MAX_REMARKS 条"""
        archive = self._ensure_loaded(uid)
        archive.remarks.append(note)
        if len(archive.remarks) > self._MAX_REMARKS:
            archive.remarks = archive.remarks[-self._MAX_REMARKS:]

    def get_remarks(self, uid: str) -> List[str]:
        """获取用户备注"""
        archive = self._archives.get(uid)
        return archive.remarks[:] if archive else []

    def set_alias(self, uid: str, alias: str) -> None:
        """设置用户别名"""
        archive = self._ensure_loaded(uid)
        archive.alias = alias

    def put_extra(self, uid: str, key: str, value: Any) -> None:
        """写入自定义附加数据"""
        archive = self._ensure_loaded(uid)
        archive.extra[key] = value

    def get_extra(self, uid: str, key: str, default: Any = None) -> Any:
        """读取自定义附加数据"""
        archive = self._archives.get(uid)
        if archive:
            return archive.extra.get(key, default)
        return default

    def get_idle_duration(self, uid: str) -> float:
        """距离上次出现过了多少秒"""
        archive = self._archives.get(uid)
        if archive:
            return time.time() - archive.latest_encounter
        return 0.0

    def get_encounter_count(self, uid: str) -> int:
        """获取用户交互次数"""
        archive = self._archives.get(uid)
        return archive.encounter_count if archive else 0

    def get_first_encounter(self, uid: str) -> float:
        """获取首次相遇时间"""
        archive = self._archives.get(uid)
        return archive.first_encounter if archive else 0.0

    def get_relationship_duration_days(self, uid: str) -> float:
        """获取关系持续天数"""
        archive = self._archives.get(uid)
        if archive:
            return (time.time() - archive.first_encounter) / 86400.0
        return 0.0

    def is_newcomer(self, uid: str, threshold_days: float = 7.0) -> bool:
        """判断是否新人"""
        archive = self._archives.get(uid)
        if not archive:
            return True
        return archive.encounter_count < 5 or self.get_relationship_duration_days(uid) < threshold_days

    def is_familiar(self, uid: str, threshold_count: int = 10) -> bool:
        """判断是否熟人"""
        archive = self._archives.get(uid)
        return archive is not None and archive.encounter_count >= threshold_count

    def get_user_summary(self, uid: str) -> str:
        """获取用户摘要描述"""
        archive = self._archives.get(uid)
        if not archive:
            return "陌生人"

        parts = []
        if archive.shown_name:
            parts.append(f"名称: {archive.shown_name}")
        parts.append(f"交互: {archive.encounter_count}次")

        duration = self.get_relationship_duration_days(uid)
        if duration < 1:
            parts.append("刚认识")
        elif duration < 7:
            parts.append(f"认识{duration:.1f}天")
        elif duration < 30:
            parts.append(f"认识{duration/7:.1f}周")
        else:
            parts.append(f"认识{duration/30:.1f}月")

        if archive.labels:
            parts.append(f"标签: {', '.join(sorted(archive.labels)[:5])}")

        return " | ".join(parts)

    def persist_all(self) -> int:
        """批量持久化所有脏档案"""
        if not self._adapter:
            return 0

        saved = 0
        for uid, archive in self._archives.items():
            try:
                if hasattr(self._adapter, "persist_user_archive"):
                    self._adapter.persist_user_archive(uid, archive.serialize())
                    saved += 1
            except Exception as e:
                logger.debug(f"持久化用户档案失败 uid={uid}: {e}")
        return saved

    async def persist_all_async(self) -> int:
        """异步批量持久化"""
        if not self._adapter:
            return 0

        saved = 0
        for uid, archive in self._archives.items():
            try:
                if hasattr(self._adapter, "persist_user_archive"):
                    await self._adapter.persist_user_archive(uid, archive.serialize())
                    saved += 1
            except Exception as e:
                logger.debug(f"持久化用户档案失败 uid={uid}: {e}")
        return saved

    def _ensure_loaded(self, uid: str) -> UserArchive:
        """确保档案在内存中可用"""
        if uid in self._archives:
            return self._archives[uid]

        if self._adapter:
            try:
                if hasattr(self._adapter, "load_user_archive"):
                    raw = self._adapter.load_user_archive(uid)
                    if raw:
                        archive = UserArchive.deserialize(raw)
                        self._archives[uid] = archive
                        return archive
            except Exception as e:
                logger.debug(f"加载用户档案失败 uid={uid}: {e}")

        archive = UserArchive(uid=uid)
        self._archives[uid] = archive
        return archive

    def clear_cache(self, uid: Optional[str] = None) -> None:
        """清除缓存"""
        if uid:
            self._archives.pop(uid, None)
        else:
            self._archives.clear()

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            "total_users": len(self._archives),
            "total_encounters": sum(a.encounter_count for a in self._archives.values()),
            "avg_encounter_count": (
                sum(a.encounter_count for a in self._archives.values()) / len(self._archives)
                if self._archives else 0
            ),
        }


_user_profile_manager: Optional[UserProfileManager] = None


def get_user_profile_manager(config_engine: Optional[ConfigEngine] = None) -> UserProfileManager:
    """获取用户档案管理器单例"""
    global _user_profile_manager
    if _user_profile_manager is None:
        _user_profile_manager = UserProfileManager(config_engine)
    return _user_profile_manager
