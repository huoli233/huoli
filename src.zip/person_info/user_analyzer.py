import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from src.common.config.config_engine import ConfigEngine
from src.common.logger import get_logger

logger = get_logger("user_analyzer")


@dataclass
class ActivityPattern:
    """活跃模式"""
    peak_hours: List[int] = field(default_factory=list)
    avg_message_length: float = 0.0
    message_frequency: float = 0.0
    preferred_topics: List[str] = field(default_factory=list)


@dataclass
class SentimentRecord:
    """情绪记录"""
    timestamp: float = 0.0
    sentiment: float = 0.5
    trigger: str = ""


class UserBehaviorAnalyzer:
    """用户行为分析器

    分析用户的行为模式:
    - 消息频率和时段
    - 话题偏好
    - 消息长度
    """

    def __init__(self, config_engine: Optional[ConfigEngine] = None):
        self._config = config_engine or ConfigEngine.get_instance()
        self._message_logs: Dict[str, List[Dict]] = {}
        self._activity_patterns: Dict[str, Dict[int, int]] = {}
        self._topic_preferences: Dict[str, Dict[str, int]] = {}
        self._load_config()

    def _load_config(self):
        """加载配置"""
        self._max_log_size = self._config.get("user_analyzer", "max_log_size", 500)
        self._min_topic_length = self._config.get("user_analyzer", "min_topic_length", 2)

    def log_message(self, user_id: str, content: str, channel_id: str = "") -> None:
        """记录消息"""
        if user_id not in self._message_logs:
            self._message_logs[user_id] = []

        self._message_logs[user_id].append({
            "content": content,
            "channel_id": channel_id,
            "timestamp": time.time(),
            "hour": time.localtime().tm_hour,
        })

        if len(self._message_logs[user_id]) > self._max_log_size:
            self._message_logs[user_id] = self._message_logs[user_id][-self._max_log_size:]

        self._update_activity_pattern(user_id)
        self._extract_topic_preferences(user_id, content)

    def _update_activity_pattern(self, user_id: str) -> None:
        """更新活跃模式"""
        if user_id not in self._activity_patterns:
            self._activity_patterns[user_id] = {}
        hour = time.localtime().tm_hour
        self._activity_patterns[user_id][hour] = self._activity_patterns[user_id].get(hour, 0) + 1

    def _extract_topic_preferences(self, user_id: str, content: str) -> None:
        """提取话题偏好"""
        if user_id not in self._topic_preferences:
            self._topic_preferences[user_id] = {}

        keywords = re.findall(r'[\u4e00-\u9fa5a-zA-Z]{' + str(self._min_topic_length) + r',}', content)
        for kw in keywords:
            kw_lower = kw.lower()
            self._topic_preferences[user_id][kw_lower] = (
                self._topic_preferences[user_id].get(kw_lower, 0) + 1
            )

    def get_active_hours(self, user_id: str) -> List[Tuple[int, int]]:
        """获取活跃时段（小时, 消息数）"""
        if user_id not in self._activity_patterns:
            return []
        sorted_hours = sorted(
            self._activity_patterns[user_id].items(),
            key=lambda x: x[1],
            reverse=True,
        )
        return sorted_hours[:5]

    def get_peak_hours(self, user_id: str) -> List[int]:
        """获取最活跃时段"""
        active_hours = self.get_active_hours(user_id)
        return [h for h, _ in active_hours[:3]]

    def get_top_topics(self, user_id: str, limit: int = 10) -> List[Tuple[str, int]]:
        """获取热门话题"""
        if user_id not in self._topic_preferences:
            return []
        sorted_topics = sorted(
            self._topic_preferences[user_id].items(),
            key=lambda x: x[1],
            reverse=True,
        )
        return sorted_topics[:limit]

    def get_message_frequency(self, user_id: str, hours: int = 24) -> float:
        """获取消息频率（每小时消息数）"""
        if user_id not in self._message_logs:
            return 0.0
        cutoff = time.time() - (hours * 3600)
        count = sum(1 for m in self._message_logs[user_id] if m["timestamp"] >= cutoff)
        return count / max(hours, 1)

    def get_average_message_length(self, user_id: str) -> float:
        """获取平均消息长度"""
        if user_id not in self._message_logs or not self._message_logs[user_id]:
            return 0.0
        total_len = sum(len(m["content"]) for m in self._message_logs[user_id])
        return total_len / len(self._message_logs[user_id])

    def get_activity_pattern(self, user_id: str) -> ActivityPattern:
        """获取活跃模式"""
        pattern = ActivityPattern()
        pattern.peak_hours = self.get_peak_hours(user_id)
        pattern.avg_message_length = self.get_average_message_length(user_id)
        pattern.message_frequency = self.get_message_frequency(user_id, 24)
        pattern.preferred_topics = [t for t, _ in self.get_top_topics(user_id, 5)]
        return pattern

    def get_user_stats(self, user_id: str) -> Dict[str, Any]:
        """获取用户统计"""
        return {
            "total_messages": len(self._message_logs.get(user_id, [])),
            "active_hours": self.get_active_hours(user_id),
            "peak_hours": self.get_peak_hours(user_id),
            "top_topics": self.get_top_topics(user_id, 5),
            "avg_message_length": self.get_average_message_length(user_id),
            "message_frequency_24h": self.get_message_frequency(user_id, 24),
        }

    def clear_user(self, user_id: str) -> None:
        """清除用户数据"""
        self._message_logs.pop(user_id, None)
        self._activity_patterns.pop(user_id, None)
        self._topic_preferences.pop(user_id, None)

    def clear_all(self) -> None:
        """清除所有数据"""
        self._message_logs.clear()
        self._activity_patterns.clear()
        self._topic_preferences.clear()


class UserSentimentTracker:
    """用户情绪追踪器"""

    def __init__(self, config_engine: Optional[ConfigEngine] = None):
        self._config = config_engine or ConfigEngine.get_instance()
        self._sentiment_history: Dict[str, List[SentimentRecord]] = {}
        self._positive_words = ["好", "棒", "喜欢", "开心", "谢谢", "赞", "哈哈", "厉害", "优秀", "棒极了"]
        self._negative_words = ["差", "烦", "讨厌", "难过", "生气", "糟", "唉", "无语", "烦人", "恶心"]
        self._load_config()

    def _load_config(self):
        """加载配置"""
        custom_positive = self._config.get("sentiment", "positive_words", [])
        custom_negative = self._config.get("sentiment", "negative_words", [])
        if custom_positive:
            self._positive_words.extend(custom_positive)
        if custom_negative:
            self._negative_words.extend(custom_negative)

    def analyze_sentiment(self, text: str) -> float:
        """分析情绪（简单关键词匹配）"""
        positive_count = sum(1 for w in self._positive_words if w in text)
        negative_count = sum(1 for w in self._negative_words if w in text)
        total = positive_count + negative_count
        if total == 0:
            return 0.5
        return positive_count / total

    def record_sentiment(self, user_id: str, text: str, trigger: str = "") -> float:
        """记录情绪"""
        sentiment = self.analyze_sentiment(text)

        if user_id not in self._sentiment_history:
            self._sentiment_history[user_id] = []

        record = SentimentRecord(
            timestamp=time.time(),
            sentiment=sentiment,
            trigger=trigger,
        )
        self._sentiment_history[user_id].append(record)

        if len(self._sentiment_history[user_id]) > 100:
            self._sentiment_history[user_id] = self._sentiment_history[user_id][-100:]

        return sentiment

    def get_average_sentiment(self, user_id: str) -> float:
        """获取平均情绪"""
        if user_id not in self._sentiment_history or not self._sentiment_history[user_id]:
            return 0.5
        total = sum(s.sentiment for s in self._sentiment_history[user_id])
        return total / len(self._sentiment_history[user_id])

    def get_sentiment_trend(self, user_id: str) -> str:
        """获取情绪趋势"""
        if user_id not in self._sentiment_history or len(self._sentiment_history[user_id]) < 2:
            return "stable"

        recent = self._sentiment_history[user_id][-10:]
        if len(recent) < 2:
            return "stable"

        first_half = sum(s.sentiment for s in recent[:len(recent)//2]) / (len(recent)//2)
        second_half = sum(s.sentiment for s in recent[len(recent)//2:]) / (len(recent) - len(recent)//2)

        diff = second_half - first_half
        if diff > 0.1:
            return "improving"
        elif diff < -0.1:
            return "declining"
        return "stable"

    def get_recent_sentiments(self, user_id: str, limit: int = 10) -> List[SentimentRecord]:
        """获取最近情绪记录"""
        if user_id not in self._sentiment_history:
            return []
        return self._sentiment_history[user_id][-limit:]

    def clear_user(self, user_id: str) -> None:
        """清除用户数据"""
        self._sentiment_history.pop(user_id, None)


class UserInterestProfiler:
    """用户兴趣画像器"""

    def __init__(self, config_engine: Optional[ConfigEngine] = None):
        self._config = config_engine or ConfigEngine.get_instance()
        self._interest_scores: Dict[str, Dict[str, float]] = {}
        self._decay_factor = 0.95
        self._load_config()

    def _load_config(self):
        """加载配置"""
        self._decay_factor = self._config.get("interest", "decay_factor", 0.95)
        self._max_interests = self._config.get("interest", "max_interests", 50)

    def record_interest(self, user_id: str, topic: str, weight: float = 1.0) -> None:
        """记录兴趣"""
        if user_id not in self._interest_scores:
            self._interest_scores[user_id] = {}

        current = self._interest_scores[user_id].get(topic, 0.0)
        self._interest_scores[user_id][topic] = current + weight

    def apply_decay(self, user_id: str) -> None:
        """应用衰减"""
        if user_id not in self._interest_scores:
            return
        for topic in self._interest_scores[user_id]:
            self._interest_scores[user_id][topic] *= self._decay_factor

    def get_top_interests(self, user_id: str, limit: int = 10) -> List[Tuple[str, float]]:
        """获取顶级兴趣"""
        if user_id not in self._interest_scores:
            return []
        sorted_interests = sorted(
            self._interest_scores[user_id].items(),
            key=lambda x: x[1],
            reverse=True,
        )
        return sorted_interests[:limit]

    def get_interest_score(self, user_id: str, topic: str) -> float:
        """获取兴趣分数"""
        if user_id not in self._interest_scores:
            return 0.0
        return self._interest_scores[user_id].get(topic, 0.0)

    def has_interest(self, user_id: str, topic: str, threshold: float = 1.0) -> bool:
        """检查是否有某兴趣"""
        return self.get_interest_score(user_id, topic) >= threshold

    def clear_user(self, user_id: str) -> None:
        """清除用户数据"""
        self._interest_scores.pop(user_id, None)


_user_behavior_analyzer: Optional[UserBehaviorAnalyzer] = None
_user_sentiment_tracker: Optional[UserSentimentTracker] = None
_user_interest_profiler: Optional[UserInterestProfiler] = None


def get_user_behavior_analyzer(config_engine: Optional[ConfigEngine] = None) -> UserBehaviorAnalyzer:
    """获取用户行为分析器单例"""
    global _user_behavior_analyzer
    if _user_behavior_analyzer is None:
        _user_behavior_analyzer = UserBehaviorAnalyzer(config_engine)
    return _user_behavior_analyzer


def get_user_sentiment_tracker(config_engine: Optional[ConfigEngine] = None) -> UserSentimentTracker:
    """获取用户情绪追踪器单例"""
    global _user_sentiment_tracker
    if _user_sentiment_tracker is None:
        _user_sentiment_tracker = UserSentimentTracker(config_engine)
    return _user_sentiment_tracker


def get_user_interest_profiler(config_engine: Optional[ConfigEngine] = None) -> UserInterestProfiler:
    """获取用户兴趣画像器单例"""
    global _user_interest_profiler
    if _user_interest_profiler is None:
        _user_interest_profiler = UserInterestProfiler(config_engine)
    return _user_interest_profiler
