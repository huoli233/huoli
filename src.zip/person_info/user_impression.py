import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from src.common.config.config_engine import ConfigEngine
from src.common.logger import get_logger

logger = get_logger("user_impression")


@dataclass
class UserImpressionRecord:
    """用户印象记录"""
    user_id: str = ""
    channel_id: str = ""
    personality_traits: List[str] = field(default_factory=list)
    topic_preferences: Dict[str, float] = field(default_factory=dict)
    behavior_distribution: Dict[str, int] = field(default_factory=dict)
    active_hours: List[int] = field(default_factory=list)
    total_interactions: int = 0
    last_interaction: float = 0.0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "user_id": self.user_id,
            "channel_id": self.channel_id,
            "personality_traits": self.personality_traits,
            "topic_preferences": self.topic_preferences,
            "behavior_distribution": self.behavior_distribution,
            "active_hours": self.active_hours,
            "total_interactions": self.total_interactions,
            "last_interaction": self.last_interaction,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UserImpressionRecord":
        """从字典创建"""
        return cls(
            user_id=data.get("user_id", ""),
            channel_id=data.get("channel_id", ""),
            personality_traits=data.get("personality_traits", []),
            topic_preferences=data.get("topic_preferences", {}),
            behavior_distribution=data.get("behavior_distribution", {}),
            active_hours=data.get("active_hours", []),
            total_interactions=data.get("total_interactions", 0),
            last_interaction=data.get("last_interaction", 0.0),
            created_at=data.get("created_at", time.time()),
            updated_at=data.get("updated_at", time.time()),
        )


class UserImpression:
    """用户印象 - 简化版本"""

    def __init__(self, user_id: str):
        self.user_id = user_id
        self.traits: Dict[str, float] = {}
        self.keywords: Dict[str, int] = {}
        self.topics: Dict[str, int] = {}
        self.sentiment_history: List[Tuple[float, float]] = []
        self.last_updated: float = time.time()

    def add_trait(self, trait: str, value: float):
        """添加特质"""
        current = self.traits.get(trait, 0.5)
        self.traits[trait] = (current + value) / 2
        self.last_updated = time.time()

    def add_keyword(self, keyword: str):
        """添加关键词"""
        self.keywords[keyword] = self.keywords.get(keyword, 0) + 1
        self.last_updated = time.time()

    def add_topic(self, topic: str):
        """添加话题"""
        self.topics[topic] = self.topics.get(topic, 0) + 1
        self.last_updated = time.time()

    def add_sentiment(self, sentiment: float):
        """添加情绪记录"""
        self.sentiment_history.append((time.time(), sentiment))
        if len(self.sentiment_history) > 100:
            self.sentiment_history = self.sentiment_history[-100:]
        self.last_updated = time.time()

    def get_average_sentiment(self) -> float:
        """获取平均情绪"""
        if not self.sentiment_history:
            return 0.5
        return sum(s for _, s in self.sentiment_history) / len(self.sentiment_history)

    def get_top_keywords(self, limit: int = 10) -> List[Tuple[str, int]]:
        """获取高频关键词"""
        sorted_keywords = sorted(self.keywords.items(), key=lambda x: x[1], reverse=True)
        return sorted_keywords[:limit]

    def get_top_topics(self, limit: int = 5) -> List[Tuple[str, int]]:
        """获取高频话题"""
        sorted_topics = sorted(self.topics.items(), key=lambda x: x[1], reverse=True)
        return sorted_topics[:limit]

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "user_id": self.user_id,
            "traits": self.traits,
            "keywords": self.keywords,
            "topics": self.topics,
            "sentiment_history": self.sentiment_history,
            "last_updated": self.last_updated,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "UserImpression":
        """从字典创建"""
        impression = cls(data.get("user_id", ""))
        impression.traits = data.get("traits", {})
        impression.keywords = data.get("keywords", {})
        impression.topics = data.get("topics", {})
        impression.sentiment_history = data.get("sentiment_history", [])
        impression.last_updated = data.get("last_updated", time.time())
        return impression


class ImpressionManager:
    """印象管理器"""

    def __init__(self, config_engine: Optional[ConfigEngine] = None):
        self._config = config_engine or ConfigEngine.get_instance()
        self._impressions: Dict[str, UserImpression] = {}
        self._records: Dict[str, UserImpressionRecord] = {}
        self._load_config()

    def _load_config(self):
        """加载配置"""
        self._max_traits = self._config.get("impression", "max_traits", 20)
        self._max_keywords = self._config.get("impression", "max_keywords", 100)

    def get_or_create(self, user_id: str) -> UserImpression:
        """获取或创建印象"""
        if user_id not in self._impressions:
            self._impressions[user_id] = UserImpression(user_id)
        return self._impressions[user_id]

    def get_impression(self, user_id: str) -> Optional[UserImpression]:
        """获取印象"""
        return self._impressions.get(user_id)

    def get_record(self, user_id: str, channel_id: str) -> Optional[UserImpressionRecord]:
        """获取记录"""
        key = f"{user_id}:{channel_id}"
        return self._records.get(key)

    def get_or_create_record(self, user_id: str, channel_id: str) -> UserImpressionRecord:
        """获取或创建记录"""
        key = f"{user_id}:{channel_id}"
        if key not in self._records:
            self._records[key] = UserImpressionRecord(
                user_id=user_id,
                channel_id=channel_id,
            )
        return self._records[key]

    def update_from_message(self, user_id: str, message: str, channel_id: str = "") -> None:
        """从消息更新印象"""
        impression = self.get_or_create(user_id)
        words = message.split()
        for word in words:
            if len(word) >= 2:
                impression.add_keyword(word.lower())

        if channel_id:
            record = self.get_or_create_record(user_id, channel_id)
            record.total_interactions += 1
            record.last_interaction = time.time()
            record.updated_at = time.time()

            current_hour = time.localtime().tm_hour
            if current_hour not in record.active_hours:
                record.active_hours.append(current_hour)
                record.active_hours = sorted(record.active_hours)

    def add_trait(self, user_id: str, trait: str, value: float = 0.5) -> None:
        """添加特质"""
        impression = self.get_or_create(user_id)
        impression.add_trait(trait, value)

    def add_topic(self, user_id: str, topic: str) -> None:
        """添加话题"""
        impression = self.get_or_create(user_id)
        impression.add_topic(topic)

    def record_sentiment(self, user_id: str, sentiment: float) -> None:
        """记录情绪"""
        impression = self.get_or_create(user_id)
        impression.add_sentiment(sentiment)

    def get_user_summary(self, user_id: str) -> str:
        """获取用户摘要"""
        impression = self.get_impression(user_id)
        if not impression:
            return "暂无印象"

        parts = []
        top_keywords = impression.get_top_keywords(5)
        if top_keywords:
            keywords_str = ", ".join(k for k, _ in top_keywords)
            parts.append(f"常用词: {keywords_str}")

        top_topics = impression.get_top_topics(3)
        if top_topics:
            topics_str = ", ".join(t for t, _ in top_topics)
            parts.append(f"常聊话题: {topics_str}")

        avg_sentiment = impression.get_average_sentiment()
        if avg_sentiment > 0.6:
            parts.append("整体情绪: 积极")
        elif avg_sentiment < 0.4:
            parts.append("整体情绪: 消极")
        else:
            parts.append("整体情绪: 中性")

        return " | ".join(parts) if parts else "暂无印象"

    def get_active_hours(self, user_id: str, channel_id: str) -> List[int]:
        """获取活跃时段"""
        record = self.get_record(user_id, channel_id)
        return record.active_hours if record else []

    def get_interaction_count(self, user_id: str, channel_id: str) -> int:
        """获取交互次数"""
        record = self.get_record(user_id, channel_id)
        return record.total_interactions if record else 0

    def export_all(self) -> List[Dict]:
        """导出所有印象"""
        return [imp.to_dict() for imp in self._impressions.values()]

    def import_all(self, data: List[Dict]) -> None:
        """导入印象"""
        for item in data:
            impression = UserImpression.from_dict(item)
            self._impressions[impression.user_id] = impression

    def clear(self, user_id: Optional[str] = None) -> None:
        """清除印象"""
        if user_id:
            self._impressions.pop(user_id, None)
            keys_to_remove = [k for k in self._records if k.startswith(f"{user_id}:")]
            for k in keys_to_remove:
                del self._records[k]
        else:
            self._impressions.clear()
            self._records.clear()

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            "total_users": len(self._impressions),
            "total_records": len(self._records),
            "total_interactions": sum(r.total_interactions for r in self._records.values()),
        }


class UserTagManager:
    """用户标签管理器"""

    def __init__(self):
        self._tags: Dict[str, set] = {}

    def add_tag(self, user_id: str, tag: str) -> None:
        """添加标签"""
        if user_id not in self._tags:
            self._tags[user_id] = set()
        self._tags[user_id].add(tag)

    def remove_tag(self, user_id: str, tag: str) -> None:
        """移除标签"""
        if user_id in self._tags:
            self._tags[user_id].discard(tag)

    def get_tags(self, user_id: str) -> List[str]:
        """获取标签"""
        return list(self._tags.get(user_id, set()))

    def has_tag(self, user_id: str, tag: str) -> bool:
        """检查标签"""
        return tag in self._tags.get(user_id, set())

    def get_users_by_tag(self, tag: str) -> List[str]:
        """根据标签获取用户"""
        return [uid for uid, tags in self._tags.items() if tag in tags]

    def clear(self, user_id: Optional[str] = None) -> None:
        """清除标签"""
        if user_id:
            self._tags.pop(user_id, None)
        else:
            self._tags.clear()


_impression_manager: Optional[ImpressionManager] = None
_user_tag_manager: Optional[UserTagManager] = None


def get_impression_manager(config_engine: Optional[ConfigEngine] = None) -> ImpressionManager:
    """获取印象管理器单例"""
    global _impression_manager
    if _impression_manager is None:
        _impression_manager = ImpressionManager(config_engine)
    return _impression_manager


def get_user_tag_manager() -> UserTagManager:
    """获取用户标签管理器单例"""
    global _user_tag_manager
    if _user_tag_manager is None:
        _user_tag_manager = UserTagManager()
    return _user_tag_manager
