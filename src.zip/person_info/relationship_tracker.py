import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

from src.common.config.config_engine import ConfigEngine
from src.common.logger import get_logger

logger = get_logger("relationship_tracker")

STAGE_STRANGER = "stranger"
STAGE_ACQUAINTANCE = "acquaintance"
STAGE_FAMILIAR = "familiar"
STAGE_CLOSE = "close"
STAGE_TRUSTED = "trusted"
STAGE_HOSTILE = "hostile"
STAGE_BLOCKED = "blocked"


@dataclass
class TrendSample:
    """趋势样本"""
    value: float = 0.0
    timestamp: float = 0.0


@dataclass
class StageTransition:
    """阶段转换"""
    prior_stage: str = ""
    next_stage: str = ""
    triggered_at: float = 0.0
    social_value_at: float = 0.0


@dataclass
class MilestoneRecord:
    """里程碑记录"""
    milestone_name: str = ""
    reached_at: float = 0.0
    social_value_at: float = 0.0


@dataclass
class RelationshipProfile:
    """关系档案"""
    uid: str = ""
    channel_id: str = ""
    current_stage: str = STAGE_ACQUAINTANCE
    trend_direction: str = "stable"
    trend_samples: Deque[TrendSample] = field(default_factory=lambda: deque(maxlen=100))
    stage_history: List[StageTransition] = field(default_factory=list)
    pair_interactions: Dict[str, float] = field(default_factory=dict)
    milestones: List[MilestoneRecord] = field(default_factory=list)
    last_stage_change_at: float = 0.0
    _MAX_HISTORY: int = 30

    def serialize(self) -> Dict[str, Any]:
        """序列化"""
        return {
            "uid": self.uid,
            "channel_id": self.channel_id,
            "current_stage": self.current_stage,
            "trend_direction": self.trend_direction,
            "trend_samples": [{"value": s.value, "timestamp": s.timestamp} for s in self.trend_samples],
            "stage_history": [
                {
                    "prior_stage": t.prior_stage,
                    "next_stage": t.next_stage,
                    "triggered_at": t.triggered_at,
                    "social_value_at": t.social_value_at,
                }
                for t in self.stage_history[-self._MAX_HISTORY:]
            ],
            "pair_interactions": self.pair_interactions,
            "milestones": [
                {
                    "milestone_name": m.milestone_name,
                    "reached_at": m.reached_at,
                    "social_value_at": m.social_value_at,
                }
                for m in self.milestones
            ],
            "last_stage_change_at": self.last_stage_change_at,
        }

    @classmethod
    def deserialize(cls, data: Dict[str, Any]) -> "RelationshipProfile":
        """反序列化"""
        profile = cls(
            uid=data.get("uid", ""),
            channel_id=data.get("channel_id", ""),
            current_stage=data.get("current_stage", STAGE_ACQUAINTANCE),
            trend_direction=data.get("trend_direction", "stable"),
            last_stage_change_at=float(data.get("last_stage_change_at", 0.0)),
        )
        for s in data.get("trend_samples", []):
            profile.trend_samples.append(TrendSample(value=s.get("value", 0.0), timestamp=s.get("timestamp", 0.0)))
        for t in data.get("stage_history", []):
            profile.stage_history.append(
                StageTransition(
                    prior_stage=t.get("prior_stage", ""),
                    next_stage=t.get("next_stage", ""),
                    triggered_at=t.get("triggered_at", 0.0),
                    social_value_at=t.get("social_value_at", 0.0),
                )
            )
        for m in data.get("milestones", []):
            profile.milestones.append(
                MilestoneRecord(
                    milestone_name=m.get("milestone_name", ""),
                    reached_at=m.get("reached_at", 0.0),
                    social_value_at=m.get("social_value_at", 0.0),
                )
            )
        profile.pair_interactions = data.get("pair_interactions", {})
        return profile


class RelationshipTracker:
    """关系追踪器

    追踪用户关系的变化趋势、阶段转换和用户间互动强度
    """

    def __init__(self, config_engine: Optional[ConfigEngine] = None):
        self._config = config_engine or ConfigEngine.get_instance()
        self._profiles: Dict[str, RelationshipProfile] = {}
        self._adapter: Any = None
        self._stage_thresholds: Dict[str, Tuple[float, float]] = {}
        self._trend_window_sec: float = 3600.0
        self._trend_improving_threshold: float = 3.0
        self._trend_declining_threshold: float = -3.0
        self._stage_change_cooldown_sec: float = 120.0
        self._protection_ratio: float = 0.35
        self._milestones: Dict[str, float] = {}
        self._load_config()

    def _load_config(self) -> None:
        """加载配置"""
        default_thresholds = {
            STAGE_HOSTILE: (-100.0, -45.0),
            STAGE_STRANGER: (-45.0, -10.0),
            STAGE_ACQUAINTANCE: (-10.0, 20.0),
            STAGE_FAMILIAR: (20.0, 45.0),
            STAGE_CLOSE: (45.0, 70.0),
            STAGE_TRUSTED: (70.0, 101.0),
        }
        default_milestones = {
            "first_trust": 30.0,
            "stable_friendship": 55.0,
            "high_trust": 75.0,
        }

        self._stage_thresholds = self._config.get("relationship", "stage_thresholds", default_thresholds)
        self._trend_window_sec = float(self._config.get("relationship", "trend_window_sec", 3600.0))
        self._trend_improving_threshold = float(self._config.get("relationship", "trend_improving_threshold", 3.0))
        self._trend_declining_threshold = float(self._config.get("relationship", "trend_declining_threshold", -3.0))
        self._stage_change_cooldown_sec = float(self._config.get("relationship", "stage_change_cooldown_sec", 120.0))
        self._protection_ratio = float(self._config.get("relationship", "protection_ratio", 0.35))
        self._milestones = self._config.get("relationship", "milestones", default_milestones)

    def bind_adapter(self, adapter: Any) -> None:
        """绑定适配器"""
        self._adapter = adapter

    def record_value(self, uid: str, channel_id: str, social_value: float) -> Optional[StageTransition]:
        """记录社交值并检测阶段变化"""
        profile = self._get_or_create(uid, channel_id)
        now = time.time()

        profile.trend_samples.append(TrendSample(value=social_value, timestamp=now))
        profile.trend_direction = self._evaluate_trend(profile)
        self._check_milestones(profile, social_value, now)

        candidate_stage = self._resolve_stage(social_value)
        transition: Optional[StageTransition] = None

        if candidate_stage != profile.current_stage and self._can_change_stage(
            profile, social_value, candidate_stage, now
        ):
            transition = StageTransition(
                prior_stage=profile.current_stage,
                next_stage=candidate_stage,
                triggered_at=now,
                social_value_at=social_value,
            )
            profile.stage_history.append(transition)
            if len(profile.stage_history) > profile._MAX_HISTORY:
                profile.stage_history = profile.stage_history[-profile._MAX_HISTORY:]
            profile.current_stage = candidate_stage
            profile.last_stage_change_at = now
            logger.info(f"关系阶段变化: {uid} {transition.prior_stage} -> {transition.next_stage}")

        self._schedule_persist(profile)
        return transition

    def record_pair_interaction(self, uid: str, channel_id: str, partner_uid: str, interaction_weight: float = 1.0) -> None:
        """记录用户间互动"""
        profile = self._get_or_create(uid, channel_id)
        profile.pair_interactions[partner_uid] = profile.pair_interactions.get(partner_uid, 0.0) + interaction_weight

    def get_closest_partners(self, uid: str, channel_id: str, cap: int = 5) -> List[Tuple[str, float]]:
        """获取最亲密的伙伴"""
        profile = self._get_or_create(uid, channel_id)
        return sorted(profile.pair_interactions.items(), key=lambda kv: kv[1], reverse=True)[:cap]

    def get_profile(self, uid: str, channel_id: str) -> RelationshipProfile:
        """获取关系档案"""
        return self._get_or_create(uid, channel_id)

    def get_stage(self, uid: str, channel_id: str) -> str:
        """获取关系阶段"""
        return self._get_or_create(uid, channel_id).current_stage

    def get_trend(self, uid: str, channel_id: str) -> str:
        """获取关系趋势"""
        return self._get_or_create(uid, channel_id).trend_direction

    def get_recent_transitions(self, uid: str, channel_id: str, cap: int = 5) -> List[StageTransition]:
        """获取最近的阶段转换"""
        return self._get_or_create(uid, channel_id).stage_history[-cap:]

    def get_milestones(self, uid: str, channel_id: str) -> List[MilestoneRecord]:
        """获取里程碑"""
        return list(self._get_or_create(uid, channel_id).milestones)

    def _resolve_stage(self, social_value: float) -> str:
        """解析阶段"""
        for stage, bounds in self._stage_thresholds.items():
            if not isinstance(bounds, (list, tuple)) or len(bounds) != 2:
                continue
            lower, upper = float(bounds[0]), float(bounds[1])
            if lower <= social_value < upper:
                return stage
        if social_value <= -100.0:
            return STAGE_HOSTILE
        return STAGE_TRUSTED

    def _evaluate_trend(self, profile: RelationshipProfile) -> str:
        """评估趋势"""
        if len(profile.trend_samples) < 2:
            return "stable"
        now = time.time()
        cutoff = now - self._trend_window_sec
        recent = [s for s in profile.trend_samples if s.timestamp >= cutoff]
        if len(recent) < 2:
            return "stable"
        delta = recent[-1].value - recent[0].value
        if delta >= self._trend_improving_threshold:
            return "improving"
        if delta <= self._trend_declining_threshold:
            return "declining"
        return "stable"

    def _check_milestones(self, profile: RelationshipProfile, social_value: float, now: float) -> None:
        """检查里程碑"""
        reached = {m.milestone_name for m in profile.milestones}
        for name, threshold in self._milestones.items():
            if name in reached:
                continue
            if social_value >= float(threshold):
                profile.milestones.append(
                    MilestoneRecord(milestone_name=name, reached_at=now, social_value_at=social_value)
                )
                logger.info(f"里程碑达成: {profile.uid} - {name}")

    def _can_change_stage(self, profile: RelationshipProfile, social_value: float, candidate_stage: str, now: float) -> bool:
        """检查是否可以改变阶段"""
        if profile.last_stage_change_at > 0 and now - profile.last_stage_change_at < self._stage_change_cooldown_sec:
            return False
        if not profile.trend_samples:
            return True

        stage_now = profile.current_stage
        cur_range = self._stage_thresholds.get(stage_now)
        if not isinstance(cur_range, (list, tuple)) or len(cur_range) != 2:
            return True

        lower, upper = float(cur_range[0]), float(cur_range[1])
        width = max(1.0, upper - lower)
        center = (lower + upper) / 2.0

        if candidate_stage in {STAGE_HOSTILE, STAGE_BLOCKED}:
            return True
        if social_value < center and (center - social_value) < width * self._protection_ratio:
            return False
        return True

    def _get_or_create(self, uid: str, channel_id: str) -> RelationshipProfile:
        """获取或创建档案"""
        key = f"{uid}:{channel_id}"
        if key not in self._profiles:
            self._profiles[key] = RelationshipProfile(uid=uid, channel_id=channel_id)
        return self._profiles[key]

    def _schedule_persist(self, profile: RelationshipProfile) -> None:
        """调度持久化"""
        if not self._adapter:
            return
        try:
            if hasattr(self._adapter, "set_relationship"):
                self._adapter.set_relationship(
                    profile.uid,
                    profile.channel_id,
                    profile.serialize(),
                )
        except Exception as e:
            logger.debug(f"关系持久化失败: {e}")

    def get_stage_description(self, stage: str) -> str:
        """获取阶段描述"""
        descriptions = {
            STAGE_STRANGER: "陌生人",
            STAGE_ACQUAINTANCE: "认识的人",
            STAGE_FAMILIAR: "熟人",
            STAGE_CLOSE: "好友",
            STAGE_TRUSTED: "信任的人",
            STAGE_HOSTILE: "敌对",
            STAGE_BLOCKED: "已屏蔽",
        }
        return descriptions.get(stage, stage)

    def get_relationship_summary(self, uid: str, channel_id: str) -> str:
        """获取关系摘要"""
        profile = self.get_profile(uid, channel_id)
        stage_desc = self.get_stage_description(profile.current_stage)
        trend_desc = {
            "improving": "关系升温中",
            "declining": "关系降温中",
            "stable": "关系稳定",
        }.get(profile.trend_direction, "关系稳定")

        parts = [f"阶段: {stage_desc}", f"趋势: {trend_desc}"]

        if profile.milestones:
            milestone_names = [m.milestone_name for m in profile.milestones[-3:]]
            parts.append(f"里程碑: {', '.join(milestone_names)}")

        return " | ".join(parts)

    def clear_profile(self, uid: str, channel_id: str) -> None:
        """清除档案"""
        key = f"{uid}:{channel_id}"
        self._profiles.pop(key, None)

    def clear_all(self) -> None:
        """清除所有档案"""
        self._profiles.clear()

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        stage_counts: Dict[str, int] = {}
        for profile in self._profiles.values():
            stage = profile.current_stage
            stage_counts[stage] = stage_counts.get(stage, 0) + 1

        return {
            "total_profiles": len(self._profiles),
            "stage_distribution": stage_counts,
        }


_relationship_tracker: Optional[RelationshipTracker] = None


def get_relationship_tracker(config_engine: Optional[ConfigEngine] = None) -> RelationshipTracker:
    """获取关系追踪器单例"""
    global _relationship_tracker
    if _relationship_tracker is None:
        _relationship_tracker = RelationshipTracker(config_engine)
    return _relationship_tracker
