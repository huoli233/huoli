from typing import Optional, Dict, Any, List

from src.modules.trauma.trauma_system import TraumaSystem, TraumaFragment, get_trauma_system
from src.modules.trauma.trauma_layers import TraumaLayerManager, TraumaLayer, get_trauma_layer_manager
from src.modules.trauma.trauma_triggers import TraumaTriggerEvaluator, TriggerResult, get_trauma_trigger_evaluator
from src.modules.trauma.trauma_timeline import TraumaTimeline, TraumaEvent, get_trauma_timeline
from src.modules.trauma.trauma_worldview import WorldviewImpactProcessor, get_worldview_impact_processor
from src.modules.trauma.complex_psychology import ComplexTraumaPsychology, get_complex_psychology
from src.modules.trauma.fragment_stimulus import FragmentStimulusEvaluator, get_fragment_stimulus_evaluator

from src.modules.perception.group_sense import GroupSense, GroupSenseResult, BurstAnalysis, ControversySignals, get_group_sense
from src.modules.perception.self_sense import SelfSense, SelfStatus, DecisionRecord, SessionState, get_self_sense
from src.modules.perception.user_relation_sense import UserRelationSense, RelationInfo, RelationBrief, RelationStats, get_user_relation_sense
from src.modules.perception.user_state import UserStateDetector, UserStateResult, RuleSignals, get_user_state_detector

from src.modules.recall.correction_detector import CorrectionDetector, get_correction_detector
from src.modules.recall.dimension_collector import DimensionCollector, DimensionFactors, get_dimension_collector
from src.modules.recall.post_send_analyzer import PostSendAnalyzer, RecallReason, RecallDecision, PendingRecall, AfterRecallAction, get_post_send_analyzer
from src.modules.recall.self_awareness import SelfAwareness, get_self_awareness
from src.modules.recall.self_behavior_learner import SelfBehaviorLearner, LearnedPattern, get_self_behavior_learner
from src.modules.recall.typo_generator import TypoGenerator, TypoType, TypoDecision, get_typo_generator
from src.modules.recall.models import RecallReason as RecallReasonModel, RecallDecision as RecallDecisionModel

from src.modules.safety.global_shield import GlobalShieldManager, get_global_shield_manager
from src.modules.safety.harassment_detector import HarassmentDetector, get_harassment_detector
from src.modules.safety.injection.detector import InjectionSentinel, get_injection_sentinel

from src.modules.modcore.decision_engine.scoring_system import (
    UnifiedScoringSystem, DecisionType, ScoreLevel, ScoringFactors, DecisionScore, get_scoring_system
)

from src.modules.modcore.fatigue.fatigue_controller import (
    FatigueBasedResponseController, SocialPressureContext, get_fatigue_controller
)

from src.modules.modcore.dynamic_persona.affection_dynamics import (
    AffectionDynamicsManager, EmotionContagion, ConversationContextAnalyzer,
    AffectionTriggers, RelationshipMemory, get_affection_dynamics
)

from src.modules.modcore.dynamic_persona.persona_controller import (
    PersonaController, DynamicPersona, get_persona_controller
)
from src.modules.modcore.dynamic_persona.persona_switcher import (
    PersonaSwitcher, get_persona_switcher
)
from src.modules.modcore.dynamic_persona.persona_generator import (
    PersonaGenerator, PersonaType, PersonaState, TraumaState,
    PersonaTraits, PersonaProfile, get_persona_generator
)
from src.modules.modcore.dynamic_persona.emotion_tracker import (
    EmotionTracker, get_emotion_tracker
)

from src.modules.modcore.psychological_core import (
    PsychologicalCore, PsychologicalEvent, PsychologicalResponse,
    get_psychological_core, handle_harassment_unified, handle_message_unified,
    get_psychological_state, get_response_mode, check_social_fatigue, generate_perception_context
)

from src.modules.modcore.perception.perception_generator import (
    PerceptionGenerator, PerceptionContext, get_perception_generator
)

from src.modules.modcore.social_cognition.relationship_controller import (
    RelationshipController, InteractionType, RelationStage, RelationshipState, get_relationship_controller
)

from src.person_info.user_profile import UserProfileManager, UserArchive, get_user_profile_manager
from src.person_info.user_impression import ImpressionManager, UserImpression, get_impression_manager
from src.person_info.user_analyzer import UserBehaviorAnalyzer, get_user_behavior_analyzer
from src.person_info.user_persistence import UserDataStorage, UserDataExporter, get_user_data_storage
from src.person_info.bot_identity import BotIdentityManager, BotPersona, get_bot_identity_manager
from src.person_info.relationship_tracker import RelationshipTracker, RelationshipProfile, get_relationship_tracker


class HuoLiCore:
    """HuoLi核心管理器

    统一管理所有核心模块的访问和初始化。
    采用懒加载模式，按需初始化各模块。
    """

    _instance: Optional["HuoLiCore"] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._trauma_system: Optional[TraumaSystem] = None
        self._trauma_layer_manager: Optional[TraumaLayerManager] = None
        self._trauma_trigger_evaluator: Optional[TraumaTriggerEvaluator] = None
        self._trauma_timeline: Optional[TraumaTimeline] = None
        self._worldview_processor: Optional[WorldviewImpactProcessor] = None
        self._complex_psychology: Optional[ComplexTraumaPsychology] = None
        self._fragment_stimulus: Optional[FragmentStimulusEvaluator] = None
        self._scoring_system: Optional[UnifiedScoringSystem] = None
        self._fatigue_controller: Optional[FatigueBasedResponseController] = None
        self._affection_dynamics: Optional[AffectionDynamicsManager] = None
        self._persona_controller: Optional[PersonaController] = None
        self._persona_switcher: Optional[PersonaSwitcher] = None
        self._persona_generator: Optional[PersonaGenerator] = None
        self._psychological_core: Optional[PsychologicalCore] = None
        self._perception_generator: Optional[PerceptionGenerator] = None
        self._user_profile_manager: Optional[UserProfileManager] = None
        self._impression_manager: Optional[ImpressionManager] = None
        self._user_behavior_analyzer: Optional[UserBehaviorAnalyzer] = None
        self._bot_identity_manager: Optional[BotIdentityManager] = None
        self._relationship_tracker: Optional[RelationshipTracker] = None
        self._global_shield: Optional[GlobalShieldManager] = None
        self._harassment_detector: Optional[HarassmentDetector] = None
        self._injection_sentinel: Optional[InjectionSentinel] = None
        self._group_sense: Optional[GroupSense] = None
        self._self_sense: Optional[SelfSense] = None
        self._user_relation_sense: Optional[UserRelationSense] = None
        self._user_state_detector: Optional[UserStateDetector] = None
        self._dimension_collector: Optional[DimensionCollector] = None
        self._post_send_analyzer: Optional[PostSendAnalyzer] = None
        self._self_awareness: Optional[SelfAwareness] = None
        self._self_behavior_learner: Optional[SelfBehaviorLearner] = None
        self._typo_generator: Optional[TypoGenerator] = None
        self._correction_detector: Optional[CorrectionDetector] = None
        self._emotion_tracker: Optional[EmotionTracker] = None
        self._relationship_controller: Optional[RelationshipController] = None
        self._initialized = True

    @property
    def trauma(self) -> TraumaSystem:
        """创伤系统"""
        if self._trauma_system is None:
            self._trauma_system = get_trauma_system()
        return self._trauma_system

    @property
    def trauma_layers(self) -> TraumaLayerManager:
        """创伤层级管理器"""
        if self._trauma_layer_manager is None:
            self._trauma_layer_manager = get_trauma_layer_manager()
        return self._trauma_layer_manager

    @property
    def trauma_triggers(self) -> TraumaTriggerEvaluator:
        """创伤触发评估器"""
        if self._trauma_trigger_evaluator is None:
            self._trauma_trigger_evaluator = get_trauma_trigger_evaluator()
        return self._trauma_trigger_evaluator

    @property
    def trauma_timeline(self) -> TraumaTimeline:
        """创伤时间线"""
        if self._trauma_timeline is None:
            self._trauma_timeline = get_trauma_timeline()
        return self._trauma_timeline

    @property
    def worldview_processor(self) -> WorldviewImpactProcessor:
        """世界观影响处理器"""
        if self._worldview_processor is None:
            self._worldview_processor = get_worldview_impact_processor()
        return self._worldview_processor

    @property
    def complex_psychology(self) -> ComplexTraumaPsychology:
        """复杂创伤心理"""
        if self._complex_psychology is None:
            self._complex_psychology = get_complex_psychology()
        return self._complex_psychology

    @property
    def fragment_stimulus(self) -> FragmentStimulusEvaluator:
        """碎片刺激评估器"""
        if self._fragment_stimulus is None:
            self._fragment_stimulus = get_fragment_stimulus_evaluator()
        return self._fragment_stimulus

    @property
    def scoring(self) -> UnifiedScoringSystem:
        """统一评分系统"""
        if self._scoring_system is None:
            self._scoring_system = get_scoring_system()
        return self._scoring_system

    @property
    def fatigue(self) -> FatigueBasedResponseController:
        """疲劳控制器"""
        if self._fatigue_controller is None:
            self._fatigue_controller = get_fatigue_controller()
        return self._fatigue_controller

    @property
    def affection(self) -> AffectionDynamicsManager:
        """情感动力学管理器"""
        if self._affection_dynamics is None:
            self._affection_dynamics = get_affection_dynamics()
        return self._affection_dynamics

    @property
    def persona(self) -> PersonaController:
        """人格控制器"""
        if self._persona_controller is None:
            self._persona_controller = get_persona_controller()
        return self._persona_controller

    @property
    def persona_switcher(self) -> PersonaSwitcher:
        """人格切换器"""
        if self._persona_switcher is None:
            self._persona_switcher = get_persona_switcher()
        return self._persona_switcher

    @property
    def persona_generator(self) -> PersonaGenerator:
        """人格生成器"""
        if self._persona_generator is None:
            self._persona_generator = get_persona_generator()
        return self._persona_generator

    @property
    def psychological_core(self) -> PsychologicalCore:
        """心理核心"""
        if self._psychological_core is None:
            self._psychological_core = get_psychological_core()
        return self._psychological_core

    @property
    def perception_generator(self) -> PerceptionGenerator:
        """感知生成器"""
        if self._perception_generator is None:
            self._perception_generator = get_perception_generator()
        return self._perception_generator

    @property
    def user_profile(self) -> UserProfileManager:
        """用户档案管理器"""
        if self._user_profile_manager is None:
            self._user_profile_manager = get_user_profile_manager()
        return self._user_profile_manager

    @property
    def impression(self) -> ImpressionManager:
        """印象管理器"""
        if self._impression_manager is None:
            self._impression_manager = get_impression_manager()
        return self._impression_manager

    @property
    def user_analyzer(self) -> UserBehaviorAnalyzer:
        """用户行为分析器"""
        if self._user_behavior_analyzer is None:
            self._user_behavior_analyzer = get_user_behavior_analyzer()
        return self._user_behavior_analyzer

    @property
    def bot_identity(self) -> BotIdentityManager:
        """机器人身份管理器"""
        if self._bot_identity_manager is None:
            self._bot_identity_manager = get_bot_identity_manager()
        return self._bot_identity_manager

    @property
    def relationship(self) -> RelationshipTracker:
        """关系追踪器"""
        if self._relationship_tracker is None:
            self._relationship_tracker = get_relationship_tracker()
        return self._relationship_tracker

    @property
    def shield(self) -> GlobalShieldManager:
        """全局防护盾"""
        if self._global_shield is None:
            self._global_shield = get_global_shield_manager()
        return self._global_shield

    @property
    def harassment(self) -> HarassmentDetector:
        """骚扰检测器"""
        if self._harassment_detector is None:
            self._harassment_detector = get_harassment_detector()
        return self._harassment_detector

    @property
    def injection(self) -> InjectionSentinel:
        """注入哨兵"""
        if self._injection_sentinel is None:
            self._injection_sentinel = get_injection_sentinel()
        return self._injection_sentinel

    @property
    def group_sense(self) -> GroupSense:
        """群聊感知"""
        if self._group_sense is None:
            self._group_sense = get_group_sense()
        return self._group_sense

    @property
    def self_sense(self) -> SelfSense:
        """自我感知"""
        if self._self_sense is None:
            self._self_sense = get_self_sense()
        return self._self_sense

    @property
    def user_relation_sense(self) -> UserRelationSense:
        """用户关系感知"""
        if self._user_relation_sense is None:
            self._user_relation_sense = get_user_relation_sense()
        return self._user_relation_sense

    @property
    def user_state(self) -> UserStateDetector:
        """用户状态检测器"""
        if self._user_state_detector is None:
            self._user_state_detector = get_user_state_detector()
        return self._user_state_detector

    @property
    def dimension_collector(self) -> DimensionCollector:
        """维度收集器"""
        if self._dimension_collector is None:
            self._dimension_collector = get_dimension_collector()
        return self._dimension_collector

    @property
    def post_send_analyzer(self) -> PostSendAnalyzer:
        """发送后分析器"""
        if self._post_send_analyzer is None:
            self._post_send_analyzer = get_post_send_analyzer()
        return self._post_send_analyzer

    @property
    def self_awareness(self) -> SelfAwareness:
        """自我意识"""
        if self._self_awareness is None:
            self._self_awareness = get_self_awareness()
        return self._self_awareness

    @property
    def self_behavior_learner(self) -> SelfBehaviorLearner:
        """自我行为学习器"""
        if self._self_behavior_learner is None:
            self._self_behavior_learner = get_self_behavior_learner()
        return self._self_behavior_learner

    @property
    def typo_generator(self) -> TypoGenerator:
        """打错字生成器"""
        if self._typo_generator is None:
            self._typo_generator = get_typo_generator()
        return self._typo_generator

    @property
    def correction_detector(self) -> CorrectionDetector:
        """纠正检测器"""
        if self._correction_detector is None:
            self._correction_detector = get_correction_detector()
        return self._correction_detector

    @property
    def emotion_tracker(self) -> EmotionTracker:
        """情绪追踪器"""
        if self._emotion_tracker is None:
            self._emotion_tracker = get_emotion_tracker()
        return self._emotion_tracker

    @property
    def relationship_controller(self) -> RelationshipController:
        """关系控制器（默认流）"""
        if self._relationship_controller is None:
            self._relationship_controller = get_relationship_controller("default")
        return self._relationship_controller

    def get_all_stats(self) -> Dict[str, Any]:
        """获取所有模块统计信息"""
        return {
            "trauma": {
                "fragments": len(self.trauma.get_fragments()) if self._trauma_system else 0,
            },
            "persona": self.persona_generator.get_stats() if self._persona_generator else {},
            "fatigue": self.fatigue.get_fatigue_state("default") if self._fatigue_controller else {},
            "scoring": {
                "available": self._scoring_system is not None,
            },
            "group_sense": {
                "active_streams": len(self._group_sense._last_message_times) if self._group_sense else 0,
            },
            "self_sense": {
                "active_sessions": len(self._self_sense._sessions) if self._self_sense else 0,
            },
            "shield": {
                "active": self._global_shield is not None,
            },
        }

    def get_module_list(self) -> List[str]:
        """获取所有可用模块列表"""
        return [
            "trauma", "trauma_layers", "trauma_triggers", "trauma_timeline",
            "worldview_processor", "complex_psychology", "fragment_stimulus",
            "scoring", "fatigue", "affection", "persona", "persona_switcher",
            "persona_generator", "psychological_core", "perception_generator",
            "user_profile", "impression", "user_analyzer", "bot_identity",
            "relationship", "shield", "harassment", "injection",
            "group_sense", "self_sense", "user_relation_sense", "user_state",
            "dimension_collector", "post_send_analyzer", "self_awareness",
            "self_behavior_learner", "typo_generator", "correction_detector",
            "emotion_tracker", "relationship_controller",
        ]

    def reset_all(self):
        """重置所有模块状态"""
        if self._group_sense:
            self._group_sense.reset()
        if self._self_sense:
            self._self_sense.clear_all_sessions()
        if self._user_state_detector:
            self._user_state_detector.clear_all()
        if self._user_relation_sense:
            self._user_relation_sense.clear_cache()
        if self._self_behavior_learner:
            self._self_behavior_learner.clear_patterns()


def get_core() -> HuoLiCore:
    """获取HuoLi核心管理器单例"""
    return HuoLiCore()


core = get_core()
