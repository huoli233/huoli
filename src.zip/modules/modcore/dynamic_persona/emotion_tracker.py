import time
import math
import random
import json
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
from src.common.logger import get_logger

logger = get_logger("emotion_tracker")


class EmotionDimension(Enum):
    JOY = "joy"
    ANTICIPATION = "anticipation"
    SURPRISE = "surprise"
    SADNESS = "sadness"
    DISGUST = "disgust"
    ANGER = "anger"
    FEAR = "fear"
    TRUST = "trust"


class RelationshipTier(Enum):
    SOULMATE = ("挚友", 80)
    CLOSE_FRIEND = ("好友", 60)
    ACQUAINTANCE = ("熟人", 40)
    KNOWN = ("认识", 20)
    STRANGER = ("陌生人", 0)
    DISLIKE = ("不太喜欢", -20)
    ENEMY = ("讨厌", -50)
    HOSTILE = ("敌意", -80)


def _get_relation_thresholds() -> List[Tuple[int, str]]:
    try:
        from src.modules.modcore.dynamic_persona.config_loader import get_relation_thresholds
        return get_relation_thresholds()
    except Exception:
        return [
            (80, "挚友"), (60, "好友"), (40, "熟人"), (20, "认识"),
            (0, "陌生人"), (-20, "不太喜欢"), (-50, "讨厌"), (-80, "敌意")
        ]

_RELATION_THRESHOLDS = _get_relation_thresholds()


@dataclass
class UserEmotionState:
    user_id: str
    stream_id: str = ""
    affection: float = 0.0
    impression: str = "初次见面"
    relationship: str = "陌生人"
    annoyance: float = 0.0
    trust_score: float = 0.0
    trauma_score: float = 0.0
    trauma_history: List[Dict] = field(default_factory=list)
    trauma_last_recall: float = 0.0
    trauma_recall_count: int = 0
    baseline_affection: float = 0.0
    interaction_count: int = 0
    last_interaction: float = 0.0
    is_blocked: bool = False
    block_until: float = 0.0
    block_reason: str = ""
    volatility: float = 1.0
    has_trauma_mark: bool = False
    trauma_mark_level: int = 0
    trauma_mark_time: float = 0.0
    milestones_reached: List[str] = field(default_factory=list)
    highest_affection: float = 0.0
    nickname: str = ""
    last_relationship: str = "陌生人"
    relationship_protected_until: float = 0.0
    created_at: float = field(default_factory=time.time)
    joy: float = 0.0
    anticipation: float = 0.0
    surprise: float = 0.0
    sadness: float = 0.0
    disgust: float = 0.0
    anger: float = 0.0
    fear: float = 0.0
    pride: float = 0.0
    guilt: float = 0.0
    shame: float = 0.0
    envy: float = 0.0
    gratitude: float = 0.0
    positive_interactions: int = 0
    negative_interactions: int = 0
    intimacy: float = 0.0
    attitude: str = "中立"
    submission_level: float = 0.0
    shyness_level: float = 50.0
    training_stage: int = 0
    training_progress: float = 0.0
    training_resistance: float = 100.0
    trained_responses: List[str] = field(default_factory=list)
    last_training_time: float = 0.0
    training_streak: int = 0
    authority_level: float = 0.0
    intimacy_level: float = 0.0
    excess_level: float = 0.0
    last_update_time: float = field(default_factory=time.time)
    is_protected: bool = False
    protect_until: float = 0.0
    protect_reason: str = ""
    protect_count: int = 0
    affection_threshold_offset: float = 0.0
    cumulative_negative_count: int = 0
    cumulative_positive_count: int = 0
    negative_behavior_streak: int = 0
    positive_behavior_streak: int = 0
    last_behavior_type: str = ""
    threshold_offset_decay_rate: float = 0.02
    psychological_pressure: float = 0.0
    mental_fatigue: float = 0.0
    trust: float = 0.0
    stamina: float = 100.0
    surface_mask: float = 0.0
    inner_chaos: float = 0.0
    mood: str = "平静"
    trust_accumulation: float = 0.0
    distrust_accumulation: float = 0.0
    trauma_accumulation: float = 0.0
    interaction_coefficients: Dict[str, float] = field(default_factory=lambda: {
        "authority_intimacy_ratio": 0.5,
        "excess_trauma_multiplier": 1.0,
        "fatigue_response_factor": 0.8,
        "pressure_resistance_factor": 0.6,
    })

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def get_dominant_emotion(self) -> Tuple[str, float]:
        emotions = {
            "joy": self.joy, "anticipation": self.anticipation, "surprise": self.surprise,
            "sadness": self.sadness, "disgust": self.disgust, "anger": self.anger,
            "fear": self.fear, "pride": self.pride, "guilt": self.guilt,
            "shame": self.shame, "envy": self.envy, "gratitude": self.gratitude,
        }
        if not emotions:
            return "neutral", 0.0
        dominant = max(emotions.items(), key=lambda x: abs(x[1]))
        return dominant[0], dominant[1]

    def get_emotion_vector(self) -> Dict[str, float]:
        return {
            "pleasure": (self.joy + self.gratitude - self.sadness - self.anger) / 4.0,
            "arousal": (self.anticipation + self.surprise + self.fear) / 3.0,
            "dominance": (self.pride - self.shame - self.guilt) / 3.0,
        }

    def compute_vulnerability_score(self) -> float:
        return (
            (self.trauma_accumulation / 10.0) * 0.3 +
            (self.psychological_pressure / 100.0) * 0.3 +
            (self.mental_fatigue / 100.0) * 0.2 +
            (self.distrust_accumulation / 100.0) * 0.2
        )

    def is_vulnerable(self) -> bool:
        return self.compute_vulnerability_score() > 0.6

    def needs_protection(self) -> bool:
        return self.trauma_accumulation > 7 or self.psychological_pressure > 80


class EmotionConfig:
    AFFECTION_MAX = 100.0
    AFFECTION_MIN = -100.0
    TRUST_MAX = 100.0
    TRUST_MIN = -100.0
    ANNOYANCE_MAX = 100.0
    ANNOYANCE_MIN = 0.0
    TRAUMA_MAX = 10.0
    TRAUMA_MIN = 0.0
    TRUST_THRESHOLD = 30.0
    BLOCK_THRESHOLD = 80.0
    BLOCK_DURATION_BASE = 60.0
    BLOCK_DURATION_MAX = 3600.0
    GLOBAL_RAGE_THRESHOLD = 150.0


class EmotionTracker:
    _global_irritation: float = 0.0
    _last_global_impact: float = 0.0
    _global_shield_active: bool = False
    _global_shield_until: float = 0.0
    _global_shield_reason: str = ""

    def __init__(self, stream_id: str):
        self.stream_id = stream_id
        self._user_states: Dict[str, UserEmotionState] = {}
        self._psychology_states: Dict[str, Any] = {}
        self._llm_bridge = None
        self._db = None
        self._interaction_history: Dict[str, List[Dict]] = {}
        self._trauma_timers: Dict[str, float] = {}
        self._stream_emotion_manager = None
        self._active_members: Dict[str, float] = {}
        self._active_window_seconds = 1200.0
        self._max_active_slots = 20
        self._init_database()
        self._load_states()
        self._check_time_sync()
        self._init_stream_emotion()

    def _init_database(self):
        try:
            from src.modules.modcore.dynamic_persona.emotion_database import get_emotion_database
            self._db = get_emotion_database(self.stream_id)
        except Exception as exc:
            logger.debug(f"情绪数据库初始化跳过: {exc}")

    def _load_states(self):
        if self._db:
            try:
                states = self._db.load_all_states()
                for user_id, state_dict in states.items():
                    self._user_states[user_id] = self._dict_to_state(state_dict)
                logger.debug(f"加载 {len(self._user_states)} 个用户情绪状态")
            except Exception as exc:
                logger.warning(f"加载情绪状态失败: {exc}")

    def _dict_to_state(self, data: Dict) -> UserEmotionState:
        return UserEmotionState(
            user_id=data.get("user_id", ""),
            stream_id=data.get("stream_id", self.stream_id),
            affection=data.get("affection", 0.0),
            impression=data.get("impression", "初次见面"),
            relationship=data.get("relationship", "陌生人"),
            annoyance=data.get("annoyance", 0.0),
            trust_score=data.get("trust_score", 0.0),
            trauma_score=data.get("trauma_score", 0.0),
            trauma_history=data.get("trauma_history", []),
            trauma_last_recall=data.get("trauma_last_recall", 0.0),
            trauma_recall_count=data.get("trauma_recall_count", 0),
            baseline_affection=data.get("baseline_affection", 0.0),
            interaction_count=data.get("interaction_count", 0),
            last_interaction=data.get("last_interaction", 0.0),
            is_blocked=data.get("is_blocked", False),
            block_until=data.get("block_until", 0.0),
            block_reason=data.get("block_reason", ""),
            volatility=data.get("volatility", 1.0),
            has_trauma_mark=data.get("has_trauma_mark", False),
            trauma_mark_level=data.get("trauma_mark_level", 0),
            trauma_mark_time=data.get("trauma_mark_time", 0.0),
            milestones_reached=data.get("milestones_reached", []),
            highest_affection=data.get("highest_affection", 0.0),
            nickname=data.get("nickname", ""),
            last_relationship=data.get("last_relationship", "陌生人"),
            relationship_protected_until=data.get("relationship_protected_until", 0.0),
            created_at=data.get("created_at", time.time()),
            joy=data.get("joy", 0.0),
            anticipation=data.get("anticipation", 0.0),
            surprise=data.get("surprise", 0.0),
            sadness=data.get("sadness", 0.0),
            disgust=data.get("disgust", 0.0),
            anger=data.get("anger", 0.0),
            fear=data.get("fear", 0.0),
            pride=data.get("pride", 0.0),
            guilt=data.get("guilt", 0.0),
            shame=data.get("shame", 0.0),
            envy=data.get("envy", 0.0),
            gratitude=data.get("gratitude", 0.0),
            positive_interactions=data.get("positive_interactions", 0),
            negative_interactions=data.get("negative_interactions", 0),
            intimacy=data.get("intimacy", 0.0),
            attitude=data.get("attitude", "中立"),
            submission_level=data.get("submission_level", 0.0),
            shyness_level=data.get("shyness_level", 50.0),
            training_stage=data.get("training_stage", 0),
            training_progress=data.get("training_progress", 0.0),
            training_resistance=data.get("training_resistance", 100.0),
            trained_responses=data.get("trained_responses", []),
            last_training_time=data.get("last_training_time", 0.0),
            training_streak=data.get("training_streak", 0),
            authority_level=data.get("authority_level", 0.0),
            intimacy_level=data.get("intimacy_level", 0.0),
            excess_level=data.get("excess_level", 0.0),
            is_protected=data.get("is_protected", False),
            protect_until=data.get("protect_until", 0.0),
            protect_reason=data.get("protect_reason", ""),
            protect_count=data.get("protect_count", 0),
            affection_threshold_offset=data.get("affection_threshold_offset", 0.0),
            cumulative_negative_count=data.get("cumulative_negative_count", 0),
            cumulative_positive_count=data.get("cumulative_positive_count", 0),
            negative_behavior_streak=data.get("negative_behavior_streak", 0),
            positive_behavior_streak=data.get("positive_behavior_streak", 0),
            last_behavior_type=data.get("last_behavior_type", ""),
            psychological_pressure=data.get("psychological_pressure", 0.0),
            mental_fatigue=data.get("mental_fatigue", 0.0),
            trust=data.get("trust", 0.0),
            stamina=data.get("stamina", 100.0),
            surface_mask=data.get("surface_mask", 0.0),
            inner_chaos=data.get("inner_chaos", 0.0),
            mood=data.get("mood", "平静"),
            trust_accumulation=data.get("trust_accumulation", 0.0),
            distrust_accumulation=data.get("distrust_accumulation", 0.0),
            trauma_accumulation=data.get("trauma_accumulation", 0.0),
            interaction_coefficients=data.get("interaction_coefficients", {
                "authority_intimacy_ratio": 0.5,
                "excess_trauma_multiplier": 1.0,
                "fatigue_response_factor": 0.8,
                "pressure_resistance_factor": 0.6,
            }),
        )

    def _save_states(self):
        if self._db:
            try:
                for user_id, state in self._user_states.items():
                    self._db.save_user_state(user_id, state.to_dict())
            except Exception as exc:
                logger.warning(f"保存情绪状态失败: {exc}")

    def _save_user_state(self, user_id: str):
        if self._db and user_id in self._user_states:
            try:
                self._db.save_user_state(user_id, self._user_states[user_id].to_dict())
            except Exception as exc:
                logger.debug(f"保存用户状态失败: {exc}")

    def _check_time_sync(self):
        now = time.time()
        for user_id, state in self._user_states.items():
            if state.last_interaction > 0:
                gap = now - state.last_interaction
                if gap > 30 * 24 * 3600:
                    state.last_interaction = now - (7 * 24 * 3600) + (hash(user_id) % (7 * 24 * 3600))
                    if state.created_at > state.last_interaction:
                        state.created_at = state.last_interaction - 3600
                    if state.trauma_last_recall > state.last_interaction:
                        state.trauma_last_recall = state.last_interaction
                    if state.last_training_time > state.last_interaction:
                        state.last_training_time = state.last_interaction

    def _init_stream_emotion(self):
        try:
            from src.chat.heart_flow.emotion_stream import get_channel_mood_tracker
            self._stream_emotion_manager = get_channel_mood_tracker()
            logger.debug(f"[{self.stream_id}] 流情绪管理器初始化成功")
        except Exception as exc:
            logger.debug(f"流情绪管理器初始化跳过: {exc}")

    @staticmethod
    def mask_id(uid: str) -> str:
        if not uid or uid in ("default", "guest"):
            return uid
        uid_str = str(uid)
        if len(uid_str) >= 10:
            return f"{uid_str[:4]}****{uid_str[-4:]}"
        elif len(uid_str) > 4:
            return f"{uid_str[:2]}**{uid_str[-2:]}"
        return uid_str

    @staticmethod
    def clamp_affection(value: float) -> float:
        return max(EmotionConfig.AFFECTION_MIN, min(EmotionConfig.AFFECTION_MAX, value))

    @staticmethod
    def clamp_trust(value: float) -> float:
        return max(EmotionConfig.TRUST_MIN, min(EmotionConfig.TRUST_MAX, value))

    @staticmethod
    def clamp_annoyance(value: float) -> float:
        return max(EmotionConfig.ANNOYANCE_MIN, min(EmotionConfig.ANNOYANCE_MAX, value))

    @staticmethod
    def clamp_trauma(value: float) -> float:
        return max(EmotionConfig.TRAUMA_MIN, min(EmotionConfig.TRAUMA_MAX, value))

    @staticmethod
    def clamp_all_values(state: UserEmotionState) -> None:
        state.affection = EmotionTracker.clamp_affection(state.affection)
        state.trust_score = EmotionTracker.clamp_trust(state.trust_score)
        state.annoyance = EmotionTracker.clamp_annoyance(state.annoyance)
        state.trauma_score = EmotionTracker.clamp_trauma(state.trauma_score)
        state.submission_level = max(0, min(100, state.submission_level))
        state.shyness_level = max(0, min(100, state.shyness_level))
        state.training_resistance = max(0, min(100, state.training_resistance))
        state.authority_level = max(0, min(100, state.authority_level))
        state.intimacy_level = max(0, min(100, state.intimacy_level))
        state.excess_level = max(0, min(100, state.excess_level))
        state.psychological_pressure = max(0, min(100, state.psychological_pressure))
        state.mental_fatigue = max(0, min(100, state.mental_fatigue))
        state.inner_chaos = max(0, min(10, state.inner_chaos))
        state.surface_mask = max(0, min(10, state.surface_mask))

    def get_user_state(self, user_id: str, create_if_missing: bool = True) -> Optional[UserEmotionState]:
        if user_id in self._user_states:
            state = self._user_states[user_id]
            now = time.time()
            hours = (now - state.last_interaction) / 3600 if state.last_interaction > 0 else 0
            if hours > 0:
                self._apply_time_decay(state, hours)
                if hours >= 0.5:
                    state.last_interaction = now
                    self._save_user_state(user_id)
            return state
        if create_if_missing:
            state = UserEmotionState(user_id=user_id, stream_id=self.stream_id)
            self._user_states[user_id] = state
            return state
        return None

    def _apply_time_decay(self, state: UserEmotionState, hours: float):
        if hours <= 0:
            return
        decay_factor = min(hours, 168.0)
        if state.annoyance > 0:
            decay_rate = min(1.0, decay_factor / 4.0)
            state.annoyance = max(0, state.annoyance * (1.0 - decay_rate * 0.5))
        if state.trauma_score > 0:
            decay_rate = min(1.0, decay_factor / 24.0)
            state.trauma_score = max(0, state.trauma_score * (1.0 - decay_rate * 0.1))
        if state.affection < 0:
            recovery_rate = min(1.0, decay_factor / 8.0)
            state.affection = min(0, state.affection + abs(state.affection) * recovery_rate * 0.3)
        if state.psychological_pressure > 0:
            decay_rate = min(1.0, decay_factor / 6.0)
            state.psychological_pressure = max(0, state.psychological_pressure * (1.0 - decay_rate * 0.4))
        if state.mental_fatigue > 0:
            decay_rate = min(1.0, decay_factor / 4.0)
            state.mental_fatigue = max(0, state.mental_fatigue * (1.0 - decay_rate * 0.5))
        self.clamp_all_values(state)

    def update_affection(self, user_id: str, delta: float, reason: str = "") -> float:
        state = self.get_user_state(user_id, create_if_missing=True)
        old_val = state.affection
        state.affection = self.clamp_affection(state.affection + delta * state.volatility)
        if state.affection > state.highest_affection:
            state.highest_affection = state.affection
        state.last_interaction = time.time()
        state.interaction_count += 1
        if delta > 0:
            state.positive_interactions += 1
            state.positive_behavior_streak += 1
            state.negative_behavior_streak = 0
        elif delta < 0:
            state.negative_interactions += 1
            state.negative_behavior_streak += 1
            state.positive_behavior_streak = 0
        self._update_relationship(state)
        self.clamp_all_values(state)
        self._save_user_state(user_id)
        if abs(delta) > 2:
            mask_uid = self.mask_id(user_id)
            logger.info(f"好感变化 {mask_uid} | {old_val:.1f} -> {state.affection:.1f} ({delta:+.1f}) | {reason}")
        return state.affection

    def update_annoyance(self, user_id: str, delta: float, reason: str = "") -> float:
        state = self.get_user_state(user_id, create_if_missing=True)
        state.annoyance = self.clamp_annoyance(state.annoyance + delta)
        if state.annoyance >= EmotionConfig.BLOCK_THRESHOLD and not state.is_blocked:
            block_duration = min(
                EmotionConfig.BLOCK_DURATION_BASE * (state.annoyance / EmotionConfig.BLOCK_THRESHOLD),
                EmotionConfig.BLOCK_DURATION_MAX
            )
            state.is_blocked = True
            state.block_until = time.time() + block_duration
            state.block_reason = reason or "烦躁度过高"
            mask_uid = self.mask_id(user_id)
            logger.warning(f"用户屏蔽 {mask_uid} | 烦躁度{state.annoyance:.0f} | 持续{block_duration:.0f}秒")
        state.last_interaction = time.time()
        self.clamp_all_values(state)
        self._save_user_state(user_id)
        return state.annoyance

    def update_trauma(self, user_id: str, delta: float, trigger: str = "") -> float:
        state = self.get_user_state(user_id, create_if_missing=True)
        old_trauma = state.trauma_score
        state.trauma_score = self.clamp_trauma(state.trauma_score + delta)
        if delta > 0 and trigger:
            state.trauma_history.append({
                "trigger": trigger,
                "score": delta,
                "time": time.time()
            })
            if len(state.trauma_history) > 50:
                state.trauma_history = state.trauma_history[-30:]
            state.trauma_last_recall = time.time()
            state.trauma_recall_count += 1
        if state.trauma_score >= 3.0 and not state.has_trauma_mark:
            state.has_trauma_mark = True
            state.trauma_mark_level = 1
            state.trauma_mark_time = time.time()
        if delta > 0 and state.trauma_score >= 6.0 and old_trauma < 6.0:
            self.activate_global_shield(1800, f"用户{self.mask_id(user_id)}创伤分数达到{state.trauma_score:.1f}")
            logger.warning(f"创伤保护激活: 用户{self.mask_id(user_id)} 创伤{state.trauma_score:.1f}")
        self.clamp_all_values(state)
        self._save_user_state(user_id)
        return state.trauma_score

    def update_emotion_dimension(self, user_id: str, dimension: EmotionDimension, delta: float) -> float:
        state = self.get_user_state(user_id, create_if_missing=True)
        attr_name = dimension.value
        current = getattr(state, attr_name, 0.0)
        new_val = max(-100.0, min(100.0, current + delta))
        setattr(state, attr_name, new_val)
        self._save_user_state(user_id)
        return new_val

    def update_multi_dimensional_emotion(self, user_id: str, emotion_deltas: Dict[str, float]) -> Dict[str, float]:
        state = self.get_user_state(user_id, create_if_missing=True)
        results = {}
        for emotion, delta in emotion_deltas.items():
            if hasattr(state, emotion):
                current = getattr(state, emotion, 0.0)
                new_val = max(-100.0, min(100.0, current + delta))
                setattr(state, emotion, new_val)
                results[emotion] = new_val
        self._save_user_state(user_id)
        return results

    def _update_relationship(self, state: UserEmotionState):
        aff = state.affection
        old_rel = state.relationship
        for threshold, label in _RELATION_THRESHOLDS:
            if aff >= threshold:
                if state.relationship != label:
                    state.last_relationship = state.relationship
                    state.relationship = label
                break

    def get_user_emotion(self, user_id: str) -> Dict[str, Any]:
        state = self.get_user_state(user_id, create_if_missing=False)
        if not state:
            return {
                "affection": 0.0, "trust": 0.0, "annoyance": 0.0,
                "trauma_score": 0.0, "relationship": "陌生人",
                "mental_fatigue": 0.0, "is_blocked": False
            }
        return {
            "affection": state.affection,
            "trust": state.trust_score,
            "annoyance": state.annoyance,
            "trauma_score": state.trauma_score,
            "relationship": state.relationship,
            "mental_fatigue": state.mental_fatigue,
            "is_blocked": state.is_blocked,
            "interaction_count": state.interaction_count,
            "intimacy": state.intimacy,
            "submission_level": state.submission_level,
            "dominant_emotion": state.get_dominant_emotion(),
            "vulnerability": state.compute_vulnerability_score(),
        }

    def get_layered_response_mode(self, user_id: str) -> Dict[str, Any]:
        state = self.get_user_state(user_id, create_if_missing=False)
        if not state:
            return {
                "tone": "neutral",
                "emoji_usage": "normal",
                "response_length": "normal",
                "formality": "medium",
                "playfulness": 0.5,
            }
        mode = {
            "tone": "neutral",
            "emoji_usage": "normal",
            "response_length": "normal",
            "formality": "medium",
            "playfulness": 0.5,
            "keywords": [],
            "avoid_patterns": [],
        }
        vulnerability = state.compute_vulnerability_score()
        try:
            from src.modules.modcore.dynamic_persona.config_loader import get_response_mode_keywords
            mode_keywords = get_response_mode_keywords()
        except Exception:
            mode_keywords = {}
        if vulnerability > 0.6 or state.trauma_accumulation > 5:
            mode["tone"] = "gentle"
            mode["response_length"] = "concise"
            mode["formality"] = "low"
            mode["emoji_usage"] = "rare"
            mode["playfulness"] = 0.2
            vulnerable_cfg = mode_keywords.get("vulnerable", {})
            mode["keywords"] = vulnerable_cfg.get("keywords", [])
            mode["avoid_patterns"] = vulnerable_cfg.get("avoid_patterns", [])
        elif state.psychological_pressure > 60 or state.mental_fatigue > 70:
            mode["tone"] = "calm"
            mode["emoji_usage"] = "occasional"
            mode["playfulness"] = 0.4
            stressed_cfg = mode_keywords.get("stressed", {})
            mode["keywords"] = stressed_cfg.get("keywords", [])
        elif state.trust_accumulation > 60:
            mode["tone"] = "warm"
            mode["formality"] = "low"
            mode["emoji_usage"] = "moderate"
            mode["playfulness"] = 0.7
        elif state.distrust_accumulation > 50:
            mode["tone"] = "guarded"
            mode["response_length"] = "concise"
            mode["emoji_usage"] = "none"
            mode["playfulness"] = 0.3
            guarded_cfg = mode_keywords.get("guarded", {})
            mode["avoid_patterns"] = guarded_cfg.get("avoid_patterns", [])
        return mode

    def fuse_psychology_with_context(self, user_id: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        state = self.get_user_state(user_id, create_if_missing=False)
        if not state:
            return {
                "dominant_mood": "neutral",
                "response_tendency": "normal",
                "interaction_readiness": 1.0,
                "is_vulnerable": False,
                "needs_protection": False,
            }
        fused = {
            "dominant_mood": "neutral",
            "response_tendency": "normal",
            "interaction_readiness": 1.0,
            "trust_level": state.trust_accumulation / 100,
            "distrust_level": state.distrust_accumulation / 100,
            "trauma_level": state.trauma_accumulation / 10,
            "pressure_level": state.psychological_pressure / 100,
            "fatigue_level": state.mental_fatigue / 100,
            "is_vulnerable": state.is_vulnerable(),
            "needs_protection": state.needs_protection(),
        }
        vulnerability = state.compute_vulnerability_score()
        if vulnerability > 0.6:
            fused["response_tendency"] = "cautious"
        elif vulnerability > 0.4:
            fused["response_tendency"] = "guarded"
        elif fused["interaction_readiness"] > 0.8:
            fused["response_tendency"] = "engaged"
        if state.trauma_accumulation > 5:
            fused["dominant_mood"] = "wounded"
        elif state.psychological_pressure > 60:
            fused["dominant_mood"] = "stressed"
        elif state.mental_fatigue > 70:
            fused["dominant_mood"] = "tired"
        elif state.distrust_accumulation > 50:
            fused["dominant_mood"] = "guarded"
        elif state.trust_accumulation > 60:
            fused["dominant_mood"] = "open"
        readiness = 1.0
        readiness -= (state.trauma_accumulation / 10) * 0.3
        readiness -= (state.psychological_pressure / 100) * 0.2
        readiness -= (state.mental_fatigue / 100) * 0.2
        readiness -= (state.distrust_accumulation / 100) * 0.15
        fused["interaction_readiness"] = round(max(0.2, min(1.0, readiness)), 2)
        return fused

    def is_user_blocked(self, user_id: str) -> Tuple[bool, Any]:
        state = self._user_states.get(user_id)
        if not state or not state.is_blocked:
            return False, ""
        if time.time() >= state.block_until:
            state.is_blocked = False
            state.block_until = 0.0
            state.block_reason = ""
            self._save_user_state(user_id)
            return False, ""
        remaining = int(state.block_until - time.time())
        return True, {
            "blocked": True,
            "reason": state.block_reason,
            "remaining_seconds": remaining,
            "trauma_score": state.trauma_score,
        }

    def block_user(self, user_id: str, duration: float, reason: str):
        state = self.get_user_state(user_id, create_if_missing=True)
        state.is_blocked = True
        state.block_until = time.time() + duration
        state.block_reason = reason
        logger.warning(f"屏蔽用户 {self.mask_id(user_id)} | 时长:{duration:.0f}秒 | 原因:{reason[:30]}")
        self._save_user_state(user_id)

    def activate_global_shield(self, duration: float, reason: str):
        now = time.time()
        EmotionTracker._global_shield_active = True
        EmotionTracker._global_shield_until = now + duration
        EmotionTracker._global_shield_reason = reason
        logger.critical(f"全局保护激活 | 原因:{reason} | 持续:{duration:.0f}秒")

    def is_global_shield_active(self) -> Tuple[bool, str]:
        if not EmotionTracker._global_shield_active:
            return False, ""
        now = time.time()
        if now >= EmotionTracker._global_shield_until:
            EmotionTracker._global_shield_active = False
            EmotionTracker._global_shield_until = 0.0
            EmotionTracker._global_shield_reason = ""
            return False, ""
        remaining = int(EmotionTracker._global_shield_until - now)
        return True, f"系统保护中，还剩{remaining}秒。原因: {EmotionTracker._global_shield_reason}"

    def deactivate_global_shield(self) -> bool:
        if EmotionTracker._global_shield_active:
            EmotionTracker._global_shield_active = False
            EmotionTracker._global_shield_until = 0.0
            EmotionTracker._global_shield_reason = ""
            logger.info("全局保护已解除")
            return True
        return False

    def activate_user_protection(self, user_id: str, duration: float, reason: str):
        state = self.get_user_state(user_id, create_if_missing=True)
        now = time.time()
        state.is_protected = True
        state.protect_until = now + duration
        state.protect_reason = reason
        state.protect_count += 1
        logger.warning(f"用户保护 {self.mask_id(user_id)} | 原因:{reason} | 持续:{duration:.0f}秒")
        self._save_user_state(user_id)

    def is_user_protected(self, user_id: str) -> Tuple[bool, str]:
        state = self._user_states.get(user_id)
        if not state or not state.is_protected:
            return False, ""
        now = time.time()
        if now >= state.protect_until:
            state.is_protected = False
            state.protect_until = 0.0
            state.protect_reason = ""
            return False, ""
        remaining = int(state.protect_until - now)
        return True, f"保护中，还剩{remaining}秒。原因: {state.protect_reason}"

    def process_interaction(self, user_id: str, interaction_type: str,
                            content: str = "", magnitude: float = 1.0) -> Dict[str, Any]:
        state = self.get_user_state(user_id, create_if_missing=True)
        result = {"type": interaction_type, "changes": {}}
        if interaction_type == "positive":
            affection_delta = magnitude * 0.5 * state.volatility
            result["changes"]["affection"] = self.update_affection(user_id, affection_delta, "正向交互")
            result["changes"]["annoyance"] = self.update_annoyance(user_id, -magnitude * 2.0)
            self.update_emotion_dimension(user_id, EmotionDimension.JOY, magnitude * 0.3)
            self.update_emotion_dimension(user_id, EmotionDimension.GRATITUDE, magnitude * 0.2)
        elif interaction_type == "negative":
            affection_delta = -magnitude * 0.3 * state.volatility
            result["changes"]["affection"] = self.update_affection(user_id, affection_delta, "负向交互")
            result["changes"]["annoyance"] = self.update_annoyance(user_id, magnitude * 5.0)
            result["changes"]["trauma"] = self.update_trauma(user_id, magnitude * 0.3, content[:50])
            self.update_emotion_dimension(user_id, EmotionDimension.ANGER, magnitude * 0.4)
            self.update_emotion_dimension(user_id, EmotionDimension.SADNESS, magnitude * 0.3)
        elif interaction_type == "neutral":
            result["changes"]["affection"] = self.update_affection(user_id, 0.02, "中性交互")
        result["state"] = self.get_user_emotion(user_id)
        result["response_mode"] = self.get_layered_response_mode(user_id)
        return result

    def get_all_user_states(self) -> Dict[str, UserEmotionState]:
        return self._user_states.copy()

    def get_statistics(self) -> Dict[str, Any]:
        total = len(self._user_states)
        if total == 0:
            return {"total": 0}
        affections = [s.affection for s in self._user_states.values()]
        avg_affection = sum(affections) / total
        blocked_count = sum(1 for s in self._user_states.values() if s.is_blocked)
        protected_count = sum(1 for s in self._user_states.values() if s.is_protected)
        trauma_count = sum(1 for s in self._user_states.values() if s.trauma_score > 0)
        relationship_dist = {}
        for state in self._user_states.values():
            relationship_dist[state.relationship] = relationship_dist.get(state.relationship, 0) + 1
        return {
            "total": total,
            "average_affection": round(avg_affection, 2),
            "blocked_count": blocked_count,
            "protected_count": protected_count,
            "trauma_affected_count": trauma_count,
            "relationship_distribution": relationship_dist,
            "global_shield_active": EmotionTracker._global_shield_active,
        }


_tracker_instances: Dict[str, EmotionTracker] = {}


def get_emotion_tracker(stream_id: str = "default") -> EmotionTracker:
    if stream_id not in _tracker_instances:
        _tracker_instances[stream_id] = EmotionTracker(stream_id)
    return _tracker_instances[stream_id]


def reset_emotion_tracker(stream_id: str = ""):
    if stream_id and stream_id in _tracker_instances:
        del _tracker_instances[stream_id]
    elif not stream_id:
        _tracker_instances.clear()
