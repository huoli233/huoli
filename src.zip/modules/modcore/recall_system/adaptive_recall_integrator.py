import asyncio
import random
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple
from src.common.logger import get_logger

logger = get_logger("adaptive_recall")

_FATIGUE_AMPLIFIER = 0.015
_CHAOS_AMPLIFIER = 0.02
_TRAUMA_AMPLIFIER = 0.008
_MASK_SUPPRESSOR = 0.003


class AdaptiveRecallIntegrator:
    """自适应召回整合器"""

    def __init__(self, floor_rate: float = 0.005, ceiling_rate: float = 0.15):
        self._floor = floor_rate
        self._ceiling = ceiling_rate

    def should_trigger_recall(
        self,
        surface_mask: float = 10.0,
        inner_chaos: float = 0.0,
        mental_fatigue: float = 0.0,
        trauma_score: float = 0.0,
    ) -> Tuple[bool, Optional[str], Dict[str, Any]]:
        """综合心理指标判定是否触发召回

        返回 (触发标记, 错误类型, 诊断信息)
        """
        rate = self._floor
        rate += mental_fatigue * _FATIGUE_AMPLIFIER
        rate += inner_chaos * _CHAOS_AMPLIFIER
        rate += trauma_score * _TRAUMA_AMPLIFIER
        rate -= surface_mask * _MASK_SUPPRESSOR
        rate = max(self._floor, min(self._ceiling, rate))
        roll = random.random()
        triggered = roll < rate
        error_kind = None
        if triggered:
            if mental_fatigue > 60:
                error_kind = "incomplete"
            elif inner_chaos > 50:
                error_kind = "wrong_word"
            elif trauma_score > 5:
                error_kind = "accidental_send"
            else:
                error_kind = "typo"
        diagnostics = {
            "computed_rate": round(rate, 5),
            "roll": round(roll, 5),
            "inputs": {
                "surface_mask": surface_mask,
                "inner_chaos": inner_chaos,
                "mental_fatigue": mental_fatigue,
                "trauma_score": trauma_score,
            },
        }
        return triggered, error_kind, diagnostics

    async def process_with_adaptive_recall(
        self,
        original_text: str,
        surface_mask: float = 10.0,
        inner_chaos: float = 0.0,
        mental_fatigue: float = 0.0,
        trauma_score: float = 0.0,
        group_id: str = "",
        stream_id: str = "",
        send_func: Optional[Callable[[str, str], Awaitable[str]]] = None,
        delete_func: Optional[Callable[[str], Awaitable[bool]]] = None,
    ) -> Tuple[str, bool, Dict[str, Any]]:
        """完整的自适应召回流程

        返回 (最终文本, 是否触发了召回, 额外信息)
        """
        triggered, err_kind, diag = self.should_trigger_recall(
            surface_mask, inner_chaos, mental_fatigue, trauma_score,
        )
        if not triggered or err_kind is None:
            return original_text, False, diag
        try:
            from src.modules.modcore.recall_system.recall_controller import get_recall_controller
            ctl = get_recall_controller()
            error_text, meta = await ctl.generate_error_text(original_text, err_kind, stream_id)
            if send_func and delete_func and group_id:
                msg_id = await send_func(group_id, error_text)
                await ctl.schedule_recall(
                    msg_id=msg_id,
                    group_id=group_id,
                    original_text=original_text,
                    delete_func=delete_func,
                    send_func=send_func,
                    stream_id=stream_id,
                    error_text=error_text,
                    error_type=err_kind,
                )
                return error_text, True, {**diag, **meta}
            return error_text, True, {**diag, **meta}
        except Exception as exc:
            logger.error(f"[自适应召回] 流程异常: {exc}")
            return original_text, False, diag


_integrator_ref: Optional[AdaptiveRecallIntegrator] = None


def get_adaptive_recall_integrator() -> AdaptiveRecallIntegrator:
    global _integrator_ref
    if _integrator_ref is None:
        _integrator_ref = AdaptiveRecallIntegrator()
    return _integrator_ref
