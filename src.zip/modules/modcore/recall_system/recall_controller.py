import asyncio
import random
import re
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple
from src.common.logger import get_logger

logger = get_logger("recall_ctrl")


def _get_error_archetypes() -> list:
    try:
        from src.modules.modcore.recall_system.config_loader import get_error_types
        types = get_error_types()
        if types:
            return types
    except Exception:
        pass
    return ["typo", "wrong_word", "incomplete", "accidental_send"]


def _get_word_swaps() -> list:
    try:
        from src.modules.modcore.recall_system.config_loader import get_word_swaps
        swaps = get_word_swaps()
        if swaps:
            return swaps
    except Exception:
        pass
    return [("你", "我"), ("是", "不"), ("好", "坏"), ("对", "错")]


def _get_typo_fillers() -> list:
    try:
        from src.modules.modcore.recall_system.config_loader import get_typo_fillers
        fillers = get_typo_fillers()
        if fillers:
            return fillers
    except Exception:
        pass
    return ["啊", "哦", "嗯", "呃", "额"]


def _get_delay_range() -> Tuple[float, float]:
    try:
        from src.modules.modcore.recall_system.config_loader import get_recall_delay_range
        return get_recall_delay_range()
    except Exception:
        pass
    return (2.0, 12.0)


def _get_pause_range() -> Tuple[float, float]:
    try:
        from src.modules.modcore.recall_system.config_loader import get_pause_delay_range
        return get_pause_delay_range()
    except Exception:
        pass
    return (1.0, 4.0)


class RecallController:
    """消息召回控制器"""

    def __init__(self, base_trigger_rate: float = 0.02, cooldown_sec: float = 600.0):
        self._base_rate = base_trigger_rate
        self._cooldown = cooldown_sec
        self._last_trigger_ts: float = 0.0

    def should_trigger(self) -> Tuple[bool, Optional[str]]:
        """判断是否应触发召回机制，返回 (是否触发, 错误类型)"""
        import time
        now = time.time()
        if now - self._last_trigger_ts < self._cooldown:
            return False, None
        roll = random.random()
        if roll > self._base_rate:
            return False, None
        self._last_trigger_ts = now
        err_kind = random.choice(_get_error_archetypes())
        return True, err_kind

    async def generate_error_text(
        self, original: str, error_type: str, stream_id: str = ""
    ) -> Tuple[str, Dict[str, Any]]:
        """根据错误类型生成带错误的文本"""
        meta: Dict[str, Any] = {"error_type": error_type, "original_length": len(original)}
        if error_type == "incomplete":
            cut_point = max(3, len(original) // 3)
            return original[:cut_point], meta
        if error_type == "accidental_send":
            fragments = original.split("，")
            if len(fragments) > 1:
                return fragments[0], meta
            return original[:max(5, len(original) // 2)], meta
        if error_type == "typo" and len(original) > 4:
            chars = list(original)
            idx = random.randint(1, len(chars) - 2)
            fillers = _get_typo_fillers()
            chars[idx] = random.choice(fillers)
            return "".join(chars), meta
        if error_type == "wrong_word":
            swaps = _get_word_swaps()
            result = original
            pair = random.choice(swaps)
            if pair[0] in result:
                result = result.replace(pair[0], pair[1], 1)
                return result, meta
        return original, meta

    async def schedule_recall(
        self,
        msg_id: str,
        group_id: str,
        original_text: str,
        delete_func: Callable[[str], Awaitable[bool]],
        send_func: Callable[[str, str], Awaitable[str]],
        stream_id: str = "",
        error_text: str = "",
        error_type: str = "",
    ) -> None:
        """调度延迟撤回和修正发送"""
        delay_min, delay_max = _get_delay_range()
        delay = random.uniform(delay_min, delay_max)

        async def _do_recall():
            await asyncio.sleep(delay)
            try:
                success = await delete_func(msg_id)
                if success:
                    logger.debug(f"[召回] 撤回消息 {msg_id} (延迟 {delay:.1f}s)")
                    pause_min, pause_max = _get_pause_range()
                    pause = random.uniform(pause_min, pause_max)
                    await asyncio.sleep(pause)
                    await send_func(group_id, original_text)
            except Exception as exc:
                logger.error(f"[召回] 调度失败: {exc}")

        asyncio.create_task(_do_recall())


_controller_ref: Optional[RecallController] = None


def get_recall_controller() -> RecallController:
    global _controller_ref
    if _controller_ref is None:
        _controller_ref = RecallController()
    return _controller_ref
