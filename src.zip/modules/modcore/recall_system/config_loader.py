import os
import yaml
from typing import Dict, List, Any, Optional, Tuple
from src.common.logger import get_logger

logger = get_logger("recall_config_loader")

_RECALL_CONFIG_CACHE: Dict[str, Any] = {}


def _get_recall_config_path(relative_path: str) -> str:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, relative_path)


def load_recall_yaml_config(config_name: str, relative_path: str, use_cache: bool = True) -> Dict[str, Any]:
    if use_cache and config_name in _RECALL_CONFIG_CACHE:
        return _RECALL_CONFIG_CACHE[config_name]
    config_path = _get_recall_config_path(relative_path)
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
        if use_cache:
            _RECALL_CONFIG_CACHE[config_name] = config
        return config
    except FileNotFoundError:
        logger.warning(f"配置文件不存在: {config_path}")
        return {}
    except yaml.YAMLError as e:
        logger.error(f"配置文件解析错误: {config_path} | {e}")
        return {}


def get_recall_config() -> Dict[str, Any]:
    return load_recall_yaml_config(
        "recall_config",
        "configs/recall_config.yaml"
    )


def get_word_swaps() -> List[Tuple[str, str]]:
    config = get_recall_config()
    swaps = config.get("word_swaps", [])
    return [tuple(s) for s in swaps]


def get_typo_fillers() -> List[str]:
    config = get_recall_config()
    return config.get("typo_fillers", [])


def get_error_types() -> List[str]:
    config = get_recall_config()
    return config.get("error_types", [])


def get_recall_delay_range() -> Tuple[float, float]:
    config = get_recall_config()
    delay_range = config.get("recall_delay_range", {})
    return (
        delay_range.get("min", 2.0),
        delay_range.get("max", 12.0)
    )


def get_pause_delay_range() -> Tuple[float, float]:
    config = get_recall_config()
    delay_range = config.get("pause_delay_range", {})
    return (
        delay_range.get("min", 1.0),
        delay_range.get("max", 4.0)
    )


def clear_recall_config_cache(config_name: Optional[str] = None):
    global _RECALL_CONFIG_CACHE
    if config_name:
        _RECALL_CONFIG_CACHE.pop(config_name, None)
    else:
        _RECALL_CONFIG_CACHE.clear()
