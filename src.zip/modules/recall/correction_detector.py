import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.common.config.config_engine import ConfigEngine
from src.common.logger import get_logger

logger = get_logger("correction_detector")


@dataclass
class CorrectionEvent:
    """纠正事件"""
    stream_id: str = ""
    bot_msg_id: str = ""
    bot_content: str = ""
    sent_at: float = 0.0
    user_reply: str = ""
    detected_at: float = 0.0
    need_recall: bool = False
    reason: str = ""
    confidence: float = 0.0
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CorrectionResult:
    """纠正检测结果"""
    is_correction: bool = False
    confidence: float = 0.0
    reason: str = ""
    suggested_action: str = ""
    urgency: str = "normal"


class CorrectionDetector:
    """纠正检测器"""

    def __init__(
        self,
        config_engine: Optional[ConfigEngine] = None,
        prompt_manager: Any = None,
        model_client: Any = None,
    ):
        self._config = config_engine or ConfigEngine.get_instance()
        self._prompts = prompt_manager
        self._model = model_client

        self._history: Dict[str, List[CorrectionEvent]] = {}
        self._history_limit = 12
        self._timeout_sec = 150.0
        self._confidence_threshold = 0.6
        self._correction_keywords: List[str] = []
        self._load_config()
        logger.info("纠正检测器初始化完成")

    def _load_config(self) -> None:
        """从配置加载参数"""
        self._history_limit = self._config.get("correction", "history_limit", 12)
        self._timeout_sec = self._config.get("correction", "timeout_seconds", 150.0)
        self._confidence_threshold = self._config.get("correction", "confidence_threshold", 0.6)
        self._correction_keywords = self._config.get(
            "correction", "keywords",
            ["不对", "错了", "不是", "纠正", "更正", "说错了", "搞错了"]
        )

    def log_bot_send(self, stream_id: str, msg_id: str, content: str) -> None:
        """记录机器人发送的消息"""
        if stream_id not in self._history:
            self._history[stream_id] = []

        event = CorrectionEvent(
            stream_id=stream_id,
            bot_msg_id=msg_id,
            bot_content=content,
            sent_at=time.time(),
        )
        self._history[stream_id].append(event)

        if len(self._history[stream_id]) > self._history_limit:
            self._history[stream_id] = self._history[stream_id][-self._history_limit:]

        logger.debug(f"记录机器人消息: {msg_id}")

    async def check_correction(
        self,
        stream_id: str,
        user_msg: str,
    ) -> Optional[CorrectionEvent]:
        """检查用户消息是否构成纠正"""
        history = self._history.get(stream_id) or []
        if not history:
            return None

        recent = history[-1]
        elapsed = time.time() - recent.sent_at
        if elapsed > self._timeout_sec:
            return None

        is_correction, confidence, reason = await self._evaluate_correction(
            recent.bot_content, user_msg
        )

        recent.user_reply = user_msg
        recent.detected_at = time.time()
        recent.need_recall = bool(is_correction)
        recent.confidence = float(confidence)
        recent.reason = reason

        if not recent.need_recall:
            return None
        return recent

    async def _evaluate_correction(
        self,
        bot_content: str,
        user_msg: str,
    ) -> Tuple[bool, float, str]:
        """评估是否为纠正"""
        keyword_detected = self._check_keywords(user_msg)
        if self._model is None:
            if keyword_detected:
                return True, 0.5, "关键词匹配"
            return False, 0.0, "model_unavailable"

        try:
            prompt = self._build_prompt(bot_content, user_msg)
            result = await self._call_model(prompt)
            return result
        except Exception as e:
            logger.error(f"纠正检测模型调用失败: {e}")
            if keyword_detected:
                return True, 0.5, "关键词匹配（模型降级）"
            return False, 0.0, "model_error"

    def _check_keywords(self, user_msg: str) -> bool:
        """检查关键词"""
        msg_lower = user_msg.lower()
        for keyword in self._correction_keywords:
            if keyword in msg_lower:
                return True
        return False

    def _build_prompt(self, bot_content: str, user_message: str) -> str:
        """构建纠正判断提示词"""
        if self._prompts is not None:
            try:
                rendered = self._prompts.get(
                    "correction_detection",
                    bot_content=bot_content,
                    user_message=user_message,
                )
                if rendered:
                    return rendered
            except Exception as e:
                logger.debug(f"纠正提示词模板加载失败: {e}")

        return (
            "你需要判断用户是否在纠正机器人上一条回复。\n"
            "请只输出JSON：\n"
            '{"is_correction": boolean, "confidence": float, "reasoning": string}\n\n'
            f"机器人上一条消息：{bot_content}\n"
            f"用户当前回复：{user_message}\n"
        )

    async def _call_model(self, prompt: str) -> Tuple[bool, float, str]:
        """调用模型"""
        try:
            if hasattr(self._model, "generate"):
                raw = await self._model.generate(prompt)
            elif hasattr(self._model, "analyze"):
                raw = await self._model.analyze({"prompt": prompt})
            else:
                return False, 0.0, "unsupported_model_interface"

            data = self._parse_json(raw or "")
            if not isinstance(data, dict):
                return False, 0.0, "json_parse_failed"

            is_correction = bool(data.get("is_correction", False))
            confidence = float(data.get("confidence", 0.0) or 0.0)
            reasoning = str(data.get("reasoning", ""))
            return is_correction, confidence, reasoning
        except Exception as e:
            logger.error(f"模型调用异常: {e}")
            return False, 0.0, "model_error"

    def _parse_json(self, text: str) -> Optional[dict]:
        """解析JSON"""
        import json
        try:
            start = text.find("{")
            end = text.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(text[start:end])
        except json.JSONDecodeError:
            pass
        return None

    def get_last_bot_message(self, stream_id: str) -> Optional[CorrectionEvent]:
        """获取最后一条机器人消息"""
        history = self._history.get(stream_id) or []
        if history:
            return history[-1]
        return None

    def clear_history(self, stream_id: Optional[str] = None):
        """清除历史"""
        if stream_id:
            self._history.pop(stream_id, None)
        else:
            self._history.clear()

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        total = sum(len(v) for v in self._history.values())
        corrections = sum(
            1 for events in self._history.values()
            for e in events if e.need_recall
        )
        return {
            "total_messages": total,
            "corrections_detected": corrections,
            "active_streams": len(self._history),
        }


_correction_detector: Optional[CorrectionDetector] = None


def get_correction_detector(
    config_engine: Optional[ConfigEngine] = None,
    prompt_manager: Any = None,
    model_client: Any = None,
) -> CorrectionDetector:
    """获取纠正检测器单例"""
    global _correction_detector
    if _correction_detector is None:
        _correction_detector = CorrectionDetector(
            config_engine, prompt_manager, model_client
        )
    return _correction_detector
