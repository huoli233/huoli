import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from src.common.logger import get_logger
from src.common.config.config_engine import get_default_config_engine

logger = get_logger("recall_engine")


class TypoType(Enum):
    NONE = "none"
    WRONG_WORD = "wrong_word"
    WRONG_TONE = "wrong_tone"
    MISUNDERSTOOD = "misunderstood"
    OVER_REACTED = "over_reacted"


@dataclass
class TypoDecision:
    should_typo: bool = False
    typo_type: TypoType = TypoType.NONE
    error_content: str = ""
    confidence: float = 0.0
    reasoning: str = ""


@dataclass
class RecallDecision:
    should_recall: bool = False
    recall_reason: str = ""
    after_action: str = "ignore"
    confidence: float = 0.0


@dataclass
class PendingRecall:
    msg_id: str = ""
    channel_id: str = ""
    stream_id: str = ""
    user_id: str = ""
    original_content: str = ""
    sent_content: str = ""
    typo_type: Optional[TypoType] = None
    recall_decision: Optional[RecallDecision] = None
    created_at: float = field(default_factory=time.time)
    recalled: bool = False
    completed: bool = False


class ModelInterface:
    async def generate(self, prompt: str) -> str:
        raise NotImplementedError


class DefaultModelInterface(ModelInterface):
    async def generate(self, prompt: str) -> str:
        return '{"should_typo": false}'


class PromptManagerInterface:
    def get(self, name: str, **kwargs) -> Optional[str]:
        raise NotImplementedError


class DefaultPromptManager(PromptManagerInterface):
    def get(self, name: str, **kwargs) -> Optional[str]:
        return None


class RecallEngine:
    def __init__(
        self,
        config_engine=None,
        prompt_manager: Optional[PromptManagerInterface] = None,
        model_client: Optional[ModelInterface] = None,
    ):
        self._config = config_engine or get_default_config_engine()
        self._prompts = prompt_manager or DefaultPromptManager()
        self._model = model_client or DefaultModelInterface()
        self._pending: Dict[str, PendingRecall] = {}
        self._enabled: bool = True
        self._min_delay: float = 5.0
        self._max_delay: float = 110.0
        self._typo_probability: float = 0.15
        self._recall_probability: float = 0.08
        self._load_config()

    def _load_config(self) -> None:
        self._enabled = bool(self._config.get("recall", "enabled", True))
        self._min_delay = float(self._config.get("recall", "min_delay_seconds", 5.0))
        self._max_delay = float(self._config.get("recall", "max_delay_seconds", 110.0))
        self._typo_probability = float(self._config.get("recall", "typo_probability", 0.15))
        self._recall_probability = float(self._config.get("recall", "recall_probability", 0.08))

    def set_model_client(self, client: ModelInterface) -> None:
        self._model = client

    def set_prompt_manager(self, manager: PromptManagerInterface) -> None:
        self._prompts = manager

    async def decide_typo(
        self,
        content: str,
        user_id: str,
        channel_id: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> TypoDecision:
        if not self._enabled or not content:
            return TypoDecision()
        prompt = self._build_typo_prompt(content, user_id, channel_id, context)
        try:
            raw_response = await self._model.generate(prompt)
            return self._parse_typo_response(raw_response)
        except Exception as e:
            logger.debug("[撤回引擎] 打错字决策失败: %s", e)
            return TypoDecision()

    def _build_typo_prompt(
        self,
        content: str,
        user_id: str,
        channel_id: str,
        context: Optional[Dict[str, Any]],
    ) -> str:
        import json
        context_str = json.dumps(context or {}, ensure_ascii=False, default=str)[:500]
        return f"判断是否需要打错字:\n\n消息: {content}\n\n用户: {user_id}\n频道: {channel_id}\n上下文: {context_str}\n\n返回JSON: should_typo, typo_type, error_content, confidence, reasoning"

    def _parse_typo_response(self, raw_response: str) -> TypoDecision:
        import json
        try:
            parsed = json.loads(raw_response)
        except json.JSONDecodeError:
            return TypoDecision()
        if not isinstance(parsed, dict):
            return TypoDecision()
        typo_type = TypoType.NONE
        type_str = str(parsed.get("typo_type", "none")).lower()
        for t in TypoType:
            if t.value == type_str:
                typo_type = t
                break
        return TypoDecision(
            should_typo=bool(parsed.get("should_typo", False)),
            typo_type=typo_type,
            error_content=str(parsed.get("error_content", "")),
            confidence=self._safe_float(parsed.get("confidence", 0.0)),
            reasoning=str(parsed.get("reasoning", ""))[:200],
        )

    async def decide_recall(
        self,
        msg_id: str,
        sent_content: str,
        original_content: str,
        user_reaction: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> RecallDecision:
        if not self._enabled:
            return RecallDecision()
        prompt = self._build_recall_prompt(sent_content, original_content, user_reaction, context)
        try:
            raw_response = await self._model.generate(prompt)
            return self._parse_recall_response(raw_response)
        except Exception as e:
            logger.debug("[撤回引擎] 撤回决策失败: %s", e)
            return RecallDecision()

    def _build_recall_prompt(
        self,
        sent_content: str,
        original_content: str,
        user_reaction: Optional[str],
        context: Optional[Dict[str, Any]],
    ) -> str:
        import json
        context_str = json.dumps(context or {}, ensure_ascii=False, default=str)[:500]
        reaction_str = user_reaction or "无"
        return f"判断是否需要撤回:\n\n已发送: {sent_content}\n原始内容: {original_content}\n用户反应: {reaction_str}\n上下文: {context_str}\n\n返回JSON: should_recall, recall_reason, after_action, confidence"

    def _parse_recall_response(self, raw_response: str) -> RecallDecision:
        import json
        try:
            parsed = json.loads(raw_response)
        except json.JSONDecodeError:
            return RecallDecision()
        if not isinstance(parsed, dict):
            return RecallDecision()
        return RecallDecision(
            should_recall=bool(parsed.get("should_recall", False)),
            recall_reason=str(parsed.get("recall_reason", ""))[:100],
            after_action=str(parsed.get("after_action", "ignore")),
            confidence=self._safe_float(parsed.get("confidence", 0.0)),
        )

    def add_pending(self, pending: PendingRecall) -> None:
        self._pending[pending.msg_id] = pending

    def get_pending(self, msg_id: str) -> Optional[PendingRecall]:
        return self._pending.get(msg_id)

    def remove_pending(self, msg_id: str) -> None:
        self._pending.pop(msg_id, None)

    def get_delay_seconds(self) -> float:
        import random
        return random.uniform(self._min_delay, self._max_delay)

    def cleanup_expired(self, max_age_seconds: float = 300.0) -> int:
        now = time.time()
        expired = [
            msg_id for msg_id, pending in self._pending.items()
            if now - pending.created_at > max_age_seconds or pending.completed
        ]
        for msg_id in expired:
            del self._pending[msg_id]
        return len(expired)

    @staticmethod
    def _safe_float(value: Any) -> float:
        try:
            return max(0.0, min(1.0, float(value)))
        except (ValueError, TypeError):
            return 0.0

    def get_stats(self) -> Dict[str, Any]:
        return {
            "enabled": self._enabled,
            "pending_count": len(self._pending),
            "min_delay": self._min_delay,
            "max_delay": self._max_delay,
            "typo_probability": self._typo_probability,
            "recall_probability": self._recall_probability,
        }


_recall_engine: Optional[RecallEngine] = None


def get_recall_engine(
    config_engine=None,
    prompt_manager: Optional[PromptManagerInterface] = None,
    model_client: Optional[ModelInterface] = None,
) -> RecallEngine:
    global _recall_engine
    if _recall_engine is None:
        _recall_engine = RecallEngine(
            config_engine=config_engine,
            prompt_manager=prompt_manager,
            model_client=model_client,
        )
    elif model_client is not None:
        _recall_engine.set_model_client(model_client)
    return _recall_engine
