import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.common.config.config_engine import ConfigEngine
from src.common.logger import get_logger

logger = get_logger("dimension_collector")


@dataclass
class DimensionFactors:
    """维度因素集合"""
    social_value: float = 0.5
    relationship_depth: float = 0.5
    trust_value: float = 0.0
    annoyance_value: float = 0.0
    interaction_count: int = 0
    mental_fatigue: float = 0.0
    emotional_state: str = "平静"
    trauma_score: float = 0.0
    inner_chaos: float = 0.0
    persona_state: str = "default"
    is_private: bool = False
    group_atmosphere: float = 0.5
    group_member_count: int = 0
    group_activity: float = 0.5
    bystander_effect: float = 0.0
    time_of_day: str = "白天"
    time_elapsed: float = 0.0
    recent_typo_count: int = 0
    recent_recall_count: int = 0
    message_importance: float = 0.5
    topic_type: str = "日常"
    content_sensitivity: float = 0.0
    is_question: bool = False
    content_length: int = 0
    user_reaction: str = ""
    reaction_type: str = "无"
    reaction_content: str = ""
    conversation_context: str = ""
    main_personality: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "social_value": self.social_value,
            "relationship_depth": self.relationship_depth,
            "trust_value": self.trust_value,
            "annoyance_value": self.annoyance_value,
            "interaction_count": self.interaction_count,
            "mental_fatigue": self.mental_fatigue,
            "emotional_state": self.emotional_state,
            "trauma_score": self.trauma_score,
            "inner_chaos": self.inner_chaos,
            "persona_state": self.persona_state,
            "is_private": self.is_private,
            "group_atmosphere": self.group_atmosphere,
            "group_member_count": self.group_member_count,
            "group_activity": self.group_activity,
            "bystander_effect": self.bystander_effect,
            "time_of_day": self.time_of_day,
            "time_elapsed": self.time_elapsed,
            "recent_typo_count": self.recent_typo_count,
            "recent_recall_count": self.recent_recall_count,
            "message_importance": self.message_importance,
            "topic_type": self.topic_type,
            "content_sensitivity": self.content_sensitivity,
            "is_question": self.is_question,
            "content_length": self.content_length,
            "user_reaction": self.user_reaction,
            "reaction_type": self.reaction_type,
            "reaction_content": self.reaction_content,
            "conversation_context": self.conversation_context,
            "main_personality": self.main_personality,
        }


class DimensionCollector:
    """多维度因素收集器

    收集六大维度因素:
    - 社交维度: 社交分、关系深度、信任值、厌烦值、交互次数
    - 心理维度: 心理疲劳、创伤分数、情绪状态、内心混乱
    - 场景维度: 私聊/群聊、群氛围、群人数、群活跃度
    - 时间维度: 时间段、发送后经过时间、历史行为频率
    - 内容维度: 消息重要性、话题类型、内容敏感度
    - 反应维度: 用户反应、对话上下文、最近消息
    """

    def __init__(
        self,
        config_engine: Optional[ConfigEngine] = None,
        social_storage: Any = None,
        psychology_core: Any = None,
        trauma_system: Any = None,
        persona_controller: Any = None,
        group_sense: Any = None,
        message_buffer: Any = None,
    ):
        self._config = config_engine or ConfigEngine.get_instance()
        self._social_storage = social_storage
        self._psychology_core = psychology_core
        self._trauma_system = trauma_system
        self._persona_controller = persona_controller
        self._group_sense = group_sense
        self._message_buffer = message_buffer

        self._typo_history: Dict[str, List[float]] = {}
        self._recall_history: Dict[str, List[float]] = {}

        self._history_window = 3600.0
        self._max_typo_per_hour = 5
        self._max_recall_per_hour = 3

        self._main_personality: str = ""
        self._personality_states: List[str] = []
        self._state_probability: float = 0.0

        self._load_config()
        logger.info("多维度因素收集器初始化完成")

    def _load_config(self):
        """从配置加载参数"""
        self._history_window = self._config.get("dimension", "history_window_seconds", 3600.0)
        self._max_typo_per_hour = self._config.get("dimension", "max_typo_per_hour", 5)
        self._max_recall_per_hour = self._config.get("dimension", "max_recall_per_hour", 3)
        self._main_personality = self._config.get("personality", "main", "")
        self._personality_states = self._config.get("personality", "states", [])
        self._state_probability = self._config.get("personality", "state_probability", 0.0)

    def get_main_personality(self) -> str:
        """获取当前主人格"""
        import random
        if self._personality_states and random.random() < self._state_probability:
            return random.choice(self._personality_states)
        return self._main_personality

    async def collect(
        self,
        user_id: str,
        channel_id: str,
        stream_id: str,
        content: str,
        time_elapsed: float = 0.0,
        user_reaction: str = "",
    ) -> DimensionFactors:
        """收集所有维度的因素数据"""
        factors = DimensionFactors()

        await self._collect_social_dimension(factors, user_id, channel_id)
        await self._collect_psychology_dimension(factors, stream_id)
        await self._collect_scene_dimension(factors, channel_id, stream_id)
        self._collect_time_dimension(factors, stream_id, time_elapsed)
        self._collect_content_dimension(factors, content)
        await self._collect_reaction_dimension(factors, channel_id, time_elapsed, user_reaction)

        factors.main_personality = self.get_main_personality()

        return factors

    async def _collect_social_dimension(
        self,
        factors: DimensionFactors,
        user_id: str,
        channel_id: str,
    ):
        """收集社交维度因素"""
        if not self._social_storage:
            return

        try:
            if hasattr(self._social_storage, "get"):
                record = await self._social_storage.get(user_id, channel_id)
                if record:
                    factors.social_value = getattr(record, "value", 0.5)
                    factors.relationship_depth = getattr(record, "relationship_depth", 0.5)
                    factors.trust_value = getattr(record, "trust_value", 0.0)
                    factors.annoyance_value = getattr(record, "annoyance_value", 0.0)
                    factors.interaction_count = getattr(record, "interaction_count", 0)
        except Exception as e:
            logger.debug(f"收集社交维度失败: {e}")

    async def _collect_psychology_dimension(
        self,
        factors: DimensionFactors,
        stream_id: str,
    ):
        """收集心理维度因素"""
        if self._psychology_core:
            try:
                if hasattr(self._psychology_core, "get_state"):
                    state = self._psychology_core.get_state(stream_id)
                    if hasattr(state, "__await__"):
                        state = await state
                    if state:
                        factors.mental_fatigue = getattr(state, "mental_fatigue", 0.0)
                        factors.emotional_state = getattr(state, "emotional_state", "平静")
            except Exception as e:
                logger.debug(f"收集心理状态失败: {e}")

        if self._trauma_system:
            try:
                if hasattr(self._trauma_system, "get_state"):
                    trauma = self._trauma_system.get_state(stream_id)
                    if hasattr(trauma, "__await__"):
                        trauma = await trauma
                    if trauma:
                        factors.trauma_score = getattr(trauma, "score", getattr(trauma, "inner_chaos_level", 0.0))
                        factors.inner_chaos = getattr(trauma, "inner_chaos", getattr(trauma, "inner_chaos_level", 0.0))
            except Exception as e:
                logger.debug(f"收集创伤状态失败: {e}")

        if self._persona_controller:
            try:
                if hasattr(self._persona_controller, "get_current_persona"):
                    persona = self._persona_controller.get_current_persona(stream_id)
                    if hasattr(persona, "__await__"):
                        persona = await persona
                    if persona:
                        factors.persona_state = getattr(persona, "id", getattr(persona, "persona_id", "default"))
            except Exception as e:
                logger.debug(f"收集人格状态失败: {e}")

    async def _collect_scene_dimension(
        self,
        factors: DimensionFactors,
        channel_id: str,
        stream_id: str,
    ):
        """收集场景维度因素"""
        factors.is_private = self._is_private_channel(channel_id)

        if not factors.is_private and self._group_sense:
            try:
                if hasattr(self._group_sense, "get_atmosphere"):
                    atmosphere = self._group_sense.get_atmosphere(stream_id)
                    if hasattr(atmosphere, "__await__"):
                        atmosphere = await atmosphere
                    factors.group_atmosphere = atmosphere if atmosphere else 0.0

                if hasattr(self._group_sense, "get_member_count"):
                    member_count = self._group_sense.get_member_count(stream_id)
                    if hasattr(member_count, "__await__"):
                        member_count = await member_count
                    factors.group_member_count = member_count if member_count else 0

                if hasattr(self._group_sense, "get_activity"):
                    activity = self._group_sense.get_activity(stream_id)
                    if hasattr(activity, "__await__"):
                        activity = await activity
                    factors.group_activity = activity if activity else 0.0

                if factors.group_member_count > 0:
                    factors.bystander_effect = min(factors.group_member_count / 10.0, 1.0)
            except Exception as e:
                logger.debug(f"收集群场景失败: {e}")

    def _collect_time_dimension(
        self,
        factors: DimensionFactors,
        stream_id: str,
        time_elapsed: float,
    ):
        """收集时间维度因素"""
        now = datetime.now()
        hour = now.hour

        if 0 <= hour < 6:
            factors.time_of_day = "深夜"
        elif 6 <= hour < 12:
            factors.time_of_day = "早晨"
        elif 12 <= hour < 18:
            factors.time_of_day = "下午"
        else:
            factors.time_of_day = "晚上"

        factors.time_elapsed = time_elapsed
        factors.recent_typo_count = self._get_recent_count(stream_id, "typo")
        factors.recent_recall_count = self._get_recent_count(stream_id, "recall")

    def _collect_content_dimension(
        self,
        factors: DimensionFactors,
        content: str,
    ):
        """收集内容维度因素"""
        factors.message_importance = 0.5
        factors.topic_type = "日常"
        factors.content_sensitivity = 0.0
        factors.is_question = "?" in content or "？" in content
        factors.content_length = len(content)

        if len(content) < 5:
            factors.message_importance = 0.3
        elif len(content) > 100:
            factors.message_importance = 0.7

    async def _collect_reaction_dimension(
        self,
        factors: DimensionFactors,
        channel_id: str,
        time_elapsed: float,
        user_reaction: str,
    ):
        """收集反应维度因素"""
        factors.user_reaction = user_reaction
        factors.reaction_type = "无" if not user_reaction else "有"
        factors.reaction_content = user_reaction

        if self._message_buffer:
            try:
                if hasattr(self._message_buffer, "get_recent"):
                    recent = self._message_buffer.get_recent(channel_id, limit=5)
                    if hasattr(recent, "__await__"):
                        recent = await recent
                    if recent:
                        factors.conversation_context = "\n".join(str(m) for m in recent)
            except Exception as e:
                logger.debug(f"收集对话上下文失败: {e}")

    def _is_private_channel(self, channel_id: str) -> bool:
        """判断是否私聊频道"""
        if not channel_id:
            return True
        return "private" in channel_id.lower() or channel_id.startswith("u_")

    def _get_recent_count(self, stream_id: str, event_type: str) -> int:
        """获取最近事件计数"""
        history = self._typo_history if event_type == "typo" else self._recall_history
        if stream_id not in history:
            return 0

        now = time.time()
        events = [t for t in history[stream_id] if now - t < self._history_window]
        return len(events)

    def record_typo(self, stream_id: str):
        """记录打错字事件"""
        if stream_id not in self._typo_history:
            self._typo_history[stream_id] = []
        self._typo_history[stream_id].append(time.time())
        self._cleanup_history(stream_id, "typo")

    def record_recall(self, stream_id: str):
        """记录撤回事件"""
        if stream_id not in self._recall_history:
            self._recall_history[stream_id] = []
        self._recall_history[stream_id].append(time.time())
        self._cleanup_history(stream_id, "recall")

    def _cleanup_history(self, stream_id: str, event_type: str):
        """清理过期历史"""
        history = self._typo_history if event_type == "typo" else self._recall_history
        if stream_id in history:
            now = time.time()
            history[stream_id] = [t for t in history[stream_id] if now - t < self._history_window]

    def can_typo(self, stream_id: str) -> bool:
        """检查是否可以打错字"""
        count = self._get_recent_count(stream_id, "typo")
        return count < self._max_typo_per_hour

    def can_recall(self, stream_id: str) -> bool:
        """检查是否可以撤回"""
        count = self._get_recent_count(stream_id, "recall")
        return count < self._max_recall_per_hour

    def set_social_storage(self, storage: Any):
        """设置社交存储"""
        self._social_storage = storage

    def set_psychology_core(self, core: Any):
        """设置心理核心"""
        self._psychology_core = core

    def set_trauma_system(self, system: Any):
        """设置创伤系统"""
        self._trauma_system = system

    def set_persona_controller(self, controller: Any):
        """设置人格控制器"""
        self._persona_controller = controller

    def set_group_sense(self, sense: Any):
        """设置群感知"""
        self._group_sense = sense

    def set_message_buffer(self, buffer: Any):
        """设置消息缓冲"""
        self._message_buffer = buffer


_dimension_collector_instance: Optional[DimensionCollector] = None


def get_dimension_collector(config_engine: Optional[ConfigEngine] = None) -> DimensionCollector:
    """获取维度收集器单例"""
    global _dimension_collector_instance
    if _dimension_collector_instance is None:
        _dimension_collector_instance = DimensionCollector(config_engine)
    return _dimension_collector_instance
