"""内置测试页面 - 提供简单的WebUI界面"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter()

TEST_PAGE_HTML = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Huoli Bot 控制台</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            color: #fff;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            padding: 40px 0;
        }
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .header p {
            color: #888;
            font-size: 1.1em;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .card {
            background: rgba(255,255,255,0.05);
            border-radius: 16px;
            padding: 24px;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s;
        }
        .card:hover {
            background: rgba(255,255,255,0.08);
            transform: translateY(-2px);
        }
        .card h3 {
            font-size: 1.3em;
            margin-bottom: 12px;
            color: #667eea;
        }
        .card p {
            color: #aaa;
            font-size: 0.95em;
            line-height: 1.6;
        }
        .btn {
            display: inline-block;
            margin-top: 16px;
            padding: 10px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 0.9em;
            transition: opacity 0.2s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .status-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0,0,0,0.8);
            padding: 15px;
            text-align: center;
            font-size: 0.9em;
            color: #888;
        }
        .status-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #4ade80;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 2s infinite;
        }
        .status-indicator.disconnected {
            background: #ef4444;
            animation: none;
        }
        .status-indicator.connecting {
            background: #f59e0b;
            animation: pulse 1s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        .chat-section {
            margin-top: 40px;
            background: rgba(255,255,255,0.05);
            border-radius: 16px;
            padding: 24px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .chat-messages {
            height: 400px;
            overflow-y: auto;
            background: rgba(0,0,0,0.2);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 16px;
        }
        .message {
            margin-bottom: 12px;
            padding: 12px 16px;
            border-radius: 12px;
            max-width: 80%;
            word-wrap: break-word;
        }
        .message.user {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin-left: auto;
        }
        .message.bot {
            background: rgba(255,255,255,0.1);
        }
        .message.system {
            background: rgba(255,255,255,0.05);
            text-align: center;
            font-size: 0.85em;
            color: #888;
            max-width: 100%;
        }
        .message .sender {
            font-size: 0.75em;
            color: #888;
            margin-bottom: 4px;
        }
        .chat-input {
            display: flex;
            gap: 12px;
        }
        .chat-input input {
            flex: 1;
            padding: 12px 16px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 8px;
            color: white;
            font-size: 1em;
        }
        .chat-input input:focus {
            outline: none;
            border-color: #667eea;
        }
        .chat-input input:disabled {
            opacity: 0.5;
        }
        .typing-indicator {
            display: flex;
            gap: 4px;
            padding: 12px 16px;
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            max-width: 80px;
        }
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: #667eea;
            border-radius: 50%;
            animation: typing 1.4s infinite;
        }
        .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-10px); }
        }
        .api-list {
            margin-top: 20px;
        }
        .api-item {
            background: rgba(0,0,0,0.2);
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 8px;
            font-family: monospace;
            font-size: 0.85em;
        }
        .api-item span {
            color: #667eea;
            margin-right: 8px;
        }
        .connection-status {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 12px;
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            font-size: 0.85em;
            margin-left: 10px;
        }
        .auth-panel {
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
        }
        .auth-panel input {
            padding: 10px 16px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 8px;
            color: white;
            font-size: 1em;
            width: 300px;
            margin-right: 10px;
        }
        .auth-panel input:focus {
            outline: none;
            border-color: #667eea;
        }
        .auth-status {
            margin-top: 10px;
            font-size: 0.9em;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 Huoli Bot 控制台</h1>
            <p>欢迎使用 Huoli 机器人管理系统</p>
        </div>
        
        <div class="auth-panel" id="authPanel">
            <h3 style="margin-bottom: 15px;">🔐 认证</h3>
            <p style="color: #aaa; margin-bottom: 15px;">请输入 Access Token 进行认证</p>
            <input type="text" id="tokenInput" placeholder="输入 Access Token...">
            <button class="btn" onclick="authenticate()">认证</button>
            <div class="auth-status" id="authStatus"></div>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3>💬 本地聊天室</h3>
                <p>直接与 Huoli 进行对话，测试机器人的回复能力。</p>
                <a href="#chat" class="btn" onclick="scrollToChat()">开始聊天</a>
            </div>
            
            <div class="card">
                <h3>📊 系统状态</h3>
                <p>查看机器人的运行状态、内存使用、插件加载情况。</p>
                <button class="btn" onclick="checkStatus()">查看状态</button>
            </div>
            
            <div class="card">
                <h3>🔧 配置管理</h3>
                <p>管理机器人的配置文件，调整参数设置。</p>
                <button class="btn" onclick="alert('配置管理功能需要完整的WebUI前端')">打开配置</button>
            </div>
            
            <div class="card">
                <h3>📚 知识库</h3>
                <p>管理 LPMM 知识库内容，添加或查询知识。</p>
                <button class="btn" onclick="alert('知识库管理功能需要完整的WebUI前端')">管理知识</button>
            </div>
            
            <div class="card">
                <h3>😊 表情管理</h3>
                <p>管理表情包，配置自动回复表情。</p>
                <button class="btn" onclick="alert('表情管理功能需要完整的WebUI前端')">管理表情</button>
            </div>
            
            <div class="card">
                <h3>📝 日志查看</h3>
                <p>实时查看系统日志，监控运行状态。</p>
                <button class="btn" onclick="alert('日志查看功能需要完整的WebUI前端')">查看日志</button>
            </div>
        </div>
        
        <div class="chat-section" id="chat">
            <h3>
                💬 实时聊天
                <span class="connection-status" id="connectionStatus">
                    <span class="status-indicator disconnected"></span>
                    未连接
                </span>
            </h3>
            <div class="chat-messages" id="chatMessages">
                <div class="message system">请先完成认证，然后连接WebSocket服务器</div>
            </div>
            <div class="chat-input">
                <input type="text" id="messageInput" placeholder="输入消息..." onkeypress="handleKeyPress(event)" disabled>
                <button class="btn" id="sendBtn" onclick="sendMessage()" disabled>发送</button>
            </div>
        </div>
        
        <div class="chat-section">
            <h3>🔌 可用 API 接口</h3>
            <div class="api-list">
                <div class="api-item"><span>GET</span>/api/webui/health - 健康检查</div>
                <div class="api-item"><span>POST</span>/api/webui/auth/verify - 验证Token</div>
                <div class="api-item"><span>GET</span>/api/chat/history - 获取聊天历史</div>
                <div class="api-item"><span>WS</span>/api/chat/ws - WebSocket聊天</div>
                <div class="api-item"><span>GET</span>/api/webui/config/list - 获取配置列表</div>
                <div class="api-item"><span>GET</span>/api/webui/statistics - 获取统计数据</div>
            </div>
        </div>
    </div>
    
    <div class="status-bar">
        <span class="status-indicator" id="bottomStatus"></span>
        <span id="statusText">Huoli Bot 运行中 | WebUI 端口: 8001</span>
    </div>
    
    <script>
        let ws = null;
        let userId = null;
        let userName = 'Web用户';
        let isConnected = false;
        let botName = 'Huoli';
        let accessToken = null;
        
        // 生成用户ID
        function generateUserId() {
            return 'web_user_' + Math.random().toString(36).substr(2, 9);
        }
        
        // 认证
        async function authenticate() {
            const tokenInput = document.getElementById('tokenInput');
            const token = tokenInput.value.trim();
            const authStatus = document.getElementById('authStatus');
            
            if (!token) {
                authStatus.textContent = '请输入 Access Token';
                authStatus.style.color = '#ef4444';
                return;
            }
            
            try {
                const response = await fetch('/api/webui/auth/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token: token })
                });
                
                const data = await response.json();
                
                if (data.valid) {
                    accessToken = token;
                    authStatus.textContent = '✅ 认证成功！正在连接WebSocket...';
                    authStatus.style.color = '#4ade80';
                    
                    // 保存token到localStorage
                    localStorage.setItem('huoli_token', token);
                    
                    // 连接WebSocket
                    initWebSocket();
                } else {
                    authStatus.textContent = '❌ 认证失败: ' + data.message;
                    authStatus.style.color = '#ef4444';
                }
            } catch (error) {
                authStatus.textContent = '❌ 请求失败: ' + error.message;
                authStatus.style.color = '#ef4444';
            }
        }
        
        // 初始化WebSocket连接
        function initWebSocket() {
            if (!accessToken) return;
            
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/api/chat/ws?token=${encodeURIComponent(accessToken)}&user_id=${generateUserId()}&user_name=${encodeURIComponent(userName)}`;
            
            updateConnectionStatus('connecting');
            addSystemMessage('正在连接WebSocket服务器...');
            
            ws = new WebSocket(wsUrl);
            
            ws.onopen = function() {
                isConnected = true;
                updateConnectionStatus('connected');
                enableChat();
                addSystemMessage('已连接到服务器');
            };
            
            ws.onmessage = function(event) {
                const data = JSON.parse(event.data);
                handleMessage(data);
            };
            
            ws.onclose = function() {
                isConnected = false;
                updateConnectionStatus('disconnected');
                disableChat();
                addSystemMessage('连接已断开，5秒后尝试重新连接...');
                setTimeout(() => {
                    if (accessToken) initWebSocket();
                }, 5000);
            };
            
            ws.onerror = function(error) {
                console.error('WebSocket错误:', error);
                updateConnectionStatus('error');
                addSystemMessage('WebSocket连接错误');
            };
        }
        
        // 处理收到的消息
        function handleMessage(data) {
            switch(data.type) {
                case 'session_info':
                    userId = data.user_id;
                    botName = data.bot_name || 'Huoli';
                    addSystemMessage(`欢迎！我是 ${botName}，很高兴为你服务。`);
                    break;
                    
                case 'history':
                    // 加载历史消息
                    if (data.messages && data.messages.length > 0) {
                        data.messages.forEach(msg => {
                            if (msg.type === 'user') {
                                addUserMessage(msg.content, msg.sender_name);
                            } else if (msg.type === 'bot') {
                                addBotMessage(msg.content);
                            }
                        });
                    }
                    break;
                    
                case 'user_message':
                    // 其他用户的消息（广播）
                    if (data.sender && data.sender.user_id !== userId) {
                        addUserMessage(data.content, data.sender.name);
                    }
                    break;
                    
                case 'bot_message':
                case 'message':
                    // Bot的回复
                    removeTypingIndicator();
                    addBotMessage(data.content);
                    break;
                    
                case 'typing':
                    if (data.is_typing) {
                        showTypingIndicator();
                    } else {
                        removeTypingIndicator();
                    }
                    break;
                    
                case 'system':
                    addSystemMessage(data.content);
                    break;
                    
                case 'error':
                    removeTypingIndicator();
                    addSystemMessage('错误: ' + data.content);
                    break;
                    
                case 'pong':
                    // 心跳响应，忽略
                    break;
            }
        }
        
        // 更新连接状态显示
        function updateConnectionStatus(status) {
            const indicator = document.querySelector('#connectionStatus .status-indicator');
            const text = document.querySelector('#connectionStatus');
            const bottomIndicator = document.getElementById('bottomStatus');
            
            indicator.className = 'status-indicator';
            bottomIndicator.className = 'status-indicator';
            
            switch(status) {
                case 'connected':
                    indicator.classList.add('connected');
                    bottomIndicator.classList.add('connected');
                    text.innerHTML = '<span class="status-indicator"></span>已连接';
                    break;
                case 'disconnected':
                    indicator.classList.add('disconnected');
                    bottomIndicator.classList.add('disconnected');
                    text.innerHTML = '<span class="status-indicator disconnected"></span>未连接';
                    break;
                case 'connecting':
                    indicator.classList.add('connecting');
                    bottomIndicator.classList.add('connecting');
                    text.innerHTML = '<span class="status-indicator connecting"></span>连接中...';
                    break;
                case 'error':
                    indicator.classList.add('disconnected');
                    bottomIndicator.classList.add('disconnected');
                    text.innerHTML = '<span class="status-indicator disconnected"></span>连接错误';
                    break;
            }
        }
        
        // 启用聊天输入
        function enableChat() {
            document.getElementById('messageInput').disabled = false;
            document.getElementById('sendBtn').disabled = false;
            document.getElementById('messageInput').focus();
        }
        
        // 禁用聊天输入
        function disableChat() {
            document.getElementById('messageInput').disabled = true;
            document.getElementById('sendBtn').disabled = true;
        }
        
        // 添加用户消息
        function addUserMessage(content, sender) {
            const messagesDiv = document.getElementById('chatMessages');
            const msgDiv = document.createElement('div');
            msgDiv.className = 'message user';
            msgDiv.innerHTML = `<div class="sender">${sender || '我'}</div>${escapeHtml(content)}`;
            messagesDiv.appendChild(msgDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        // 添加Bot消息
        function addBotMessage(content) {
            const messagesDiv = document.getElementById('chatMessages');
            const msgDiv = document.createElement('div');
            msgDiv.className = 'message bot';
            msgDiv.innerHTML = `<div class="sender">${botName}</div>${escapeHtml(content)}`;
            messagesDiv.appendChild(msgDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        // 添加系统消息
        function addSystemMessage(content) {
            const messagesDiv = document.getElementById('chatMessages');
            const msgDiv = document.createElement('div');
            msgDiv.className = 'message system';
            msgDiv.textContent = content;
            messagesDiv.appendChild(msgDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        // 显示正在输入指示器
        function showTypingIndicator() {
            if (document.getElementById('typingIndicator')) return;
            
            const messagesDiv = document.getElementById('chatMessages');
            const indicatorDiv = document.createElement('div');
            indicatorDiv.id = 'typingIndicator';
            indicatorDiv.className = 'message bot';
            indicatorDiv.innerHTML = `
                <div class="sender">${botName}</div>
                <div class="typing-indicator">
                    <span></span><span></span><span></span>
                </div>
            `;
            messagesDiv.appendChild(indicatorDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        // 移除正在输入指示器
        function removeTypingIndicator() {
            const indicator = document.getElementById('typingIndicator');
            if (indicator) {
                indicator.remove();
            }
        }
        
        // HTML转义
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // 发送消息
        function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            if (!message || !isConnected) return;
            
            // 添加用户消息到界面
            addUserMessage(message, '我');
            
            // 发送到服务器
            ws.send(JSON.stringify({
                type: 'message',
                content: message,
                user_name: userName
            }));
            
            input.value = '';
        }
        
        // 处理按键
        function handleKeyPress(event) {
            if (event.key === 'Enter') sendMessage();
        }
        
        // 滚动到聊天区域
        function scrollToChat() {
            document.getElementById('chat').scrollIntoView({ behavior: 'smooth' });
        }
        
        // 检查系统状态
        function checkStatus() {
            fetch('/api/webui/health')
                .then(res => res.json())
                .then(data => {
                    alert('系统状态: ' + JSON.stringify(data, null, 2));
                })
                .catch(err => {
                    alert('获取状态失败: ' + err.message);
                });
        }
        
        // 页面加载完成后检查是否有保存的token
        document.addEventListener('DOMContentLoaded', function() {
            const savedToken = localStorage.getItem('huoli_token');
            if (savedToken) {
                document.getElementById('tokenInput').value = savedToken;
                authenticate();
            }
        });
    </script>
</body>
</html>'''


@router.get("/", response_class=HTMLResponse)
async def test_page():
    """返回内置测试页面"""
    return TEST_PAGE_HTML
