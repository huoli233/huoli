from src.webui.routes import router as webui_router


def get_all_routers():
    return [webui_router]


__all__ = ["get_all_routers", "webui_router"]