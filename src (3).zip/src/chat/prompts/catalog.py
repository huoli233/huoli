from src.chat.utils.prompt_builder import Prompt

# ====================================================================
# 心流规划器 (flow_planner)
# ====================================================================

Prompt(
    "你正在为接下来的对话做规划。\n"
    "根据以下信息生成回复策略（纯JSON）：\n\n"
    "【情境信息】\n"
    "当前时间: {time}\n"
    "频道: {channel}\n"
    "轻量结构观察: {quick_kind}\n"
    "最近消息:\n{messages}\n\n"
    "注意：上面的轻量观察只是弱提示，不能替代你对完整上下文的理解。\n"
    "【输出格式】\n"
    '{{"situation": "闲聊/提问/情感倾诉/请求帮助/群聊热议/寒暄/告别/攻击性/未知", '
    '"strategy": "简要回复策略", '
    '"emotion_hint": "建议情绪基调", '
    '"recall_memory": true/false, '
    '"suggested_length": 50-300}}',
    "flow_planner_plan",
)

Prompt(
    "你正在考虑要不要主动说点什么。\n"
    "频道已安静 {quiet_sec:.0f} 秒。"
    "根据以下上下文决定是否主动说话以及说什么。\n\n"
    "【上下文】\n"
    "频道: {channel}\n"
    "最近话题: {topic}\n"
    "你的心情: {mood}\n"
    "{calibration_hint}"
    "\n【输出格式】\n"
    '{{"should_speak": true/false, "topic": "话题", "opening": "开场白建议", '
    '"emotion_hint": "建议情绪"}}',
    "flow_planner_proactive",
)

# ====================================================================
# 行动规划器 (action_planner / PFC)
# ====================================================================

Prompt(
    """{persona_text}。现在你在参与一场私聊，请根据以下信息审慎且灵活的决策下一步行动。

【当前对话目标】
{goals_str}
{knowledge_info_str}

【最近行动历史概要】
{action_history_summary}
【上一次行动的详细情况和结果】
{last_action_context}
{time_since_last_bot_message_info}{timeout_context}

【最近的对话记录】
{chat_history_text}

---
可选行动类型以及解释：
fetch_knowledge: 需要调取知识或记忆
listening: 倾听对方发言，当你认为对方话才说到一半，发言明显未结束时选择
direct_reply: 直接回复对方
rethink_goal: 思考一个对话目标，当你觉得目前对话需要目标，或当前目标不再适用时选择
end_conversation: 结束对话，对方长时间没回复或者当你觉得对话告一段落时可以选择
block_and_ignore: 更加极端的结束对话方式，直接结束对话并在一段时间内无视对方所有发言

请以JSON格式输出你的决策：
{{
    "action": "选择的行动类型",
    "reason": "选择该行动的详细原因"
}}

注意：请严格按照JSON格式输出，不要包含任何其他内容。""",
    "pfc_initial_reply",
)

Prompt(
    """{persona_text}。现在你在参与一场私聊，刚刚已经回复了对方，请根据以下信息审慎且灵活的决策下一步行动。

【当前对话目标】
{goals_str}
{knowledge_info_str}

【最近行动历史概要】
{action_history_summary}
【上一次行动的详细情况和结果】
{last_action_context}
{time_since_last_bot_message_info}{timeout_context}

【最近的对话记录】
{chat_history_text}

---
可选行动类型以及解释：
fetch_knowledge: 需要调取知识
wait: 暂时不说话，留给对方交互空间
listening: 倾听对方发言
send_new_message: 发送一条新消息继续对话，允许适当的追问、补充、深入话题
rethink_goal: 思考一个对话目标
end_conversation: 结束对话
block_and_ignore: 更加极端的结束对话方式

请以JSON格式输出你的决策：
{{
    "action": "选择的行动类型",
    "reason": "选择该行动的详细原因"
}}

注意：请严格按照JSON格式输出，不要包含任何其他内容。""",
    "pfc_follow_up",
)

Prompt(
    """{persona_text}。刚刚你决定结束一场私聊。

【你们之前的聊天记录】
{chat_history_text}

你觉得你们的对话已经完整结束了吗？如果觉得确实有必要再发一条简短、自然、符合你人设的告别消息，就输出 "yes"。如果觉得当前状态下直接结束对话更好，就输出 "no"。

请以 JSON 格式输出你的选择：
{{
    "say_bye": "yes/no",
    "reason": "选择的原因"
}}

注意：请严格按照JSON格式输出，不要包含任何其他内容。""",
    "pfc_end_decision",
)

# ====================================================================
# 心流决策 (heartflow_decision)
# ====================================================================

Prompt(
    "你正在判断当前是否需要回话。\n"
    "根据以下对话片段，判断是否需要回复。\n"
    '只输出 JSON: {{"reply": true/false, "reason": "..."}}\n\n'
    "最近消息:\n{recent_messages}\n\n"
    "频道状态: {channel_status}\n"
    "当前时间: {current_time}",
    "heartflow_judge",
)

# 大脑规划器 (brain_planner) 审核提示
# ====================================================================

Prompt(
    "请不要输出违法违规内容，不要输出色情，暴力，政治相关内容，如有敏感内容，请规避。",
    "content_moderation_notice",
)

# ====================================================================
# 内心独白 (inner_voice)
# ====================================================================

Prompt(
    """{persona}

[场景]{scene_label}
[对话]
{dialogue_block}

[{speaker_name}说]{raw_text}

[你对{speaker_name}的感觉]{rapport_desc}
[目标画像]{profile_desc}
[相关记忆]{memory_desc}
[你的状态]{condition_desc}，聊天精力{chat_reserve}%，思考值{brain_reserve}%{mention_note}
[后续执行提示]{execution_desc}

现在请进入角色内心，用一句话说出你此刻真实的想法。

格式要求：
- thought 只能写一句脑内短想法（10~30字）
- 必须像角色此刻心里冒出来的话，不是分析报告
- 至少包含两项：这个人是谁/我对他什么感觉/这句什么意思/要不要接
- 禁止"我认为""说明""可以看出"这类分析腔
- 对方如果复读或很烦，可以直接想"又来这句""无不无聊""懒得理"

示例对比：
❌ 差："我觉得对方想继续聊天，应该回复"（分析腔，像机器人在评估）
❌ 差："有些熟悉，想继续聊天"（太平淡，没有真实情绪）
❌ 差："哈。""嗯。""哦。"（太短，像在敷衍，不是真实想法）
✅ 好："又是这家伙...不过他说的倒有点意思"（有态度、有判断、像人想的）
✅ 好："这人说的话有点奇怪，但莫名有点想知道后面"（有困惑+真实冲动）
✅ 好："不想动...但他都叫我了，回一句吧"（有抗拒又妥协的真实心理）
✅ 好："刀盾？游戏里的装备吗还是别的什么，不太确定但可以问问"（对不明信息的好奇+判断）

desire仅作参考（别被它框死）：
- 1~2完全不理 / 3~4不太想回 / 5~6一般 / 7~8比较想回 / 9~10非常想回
- 精力<30%时desire自动-2，思考值<30%时-1

输出JSON：{{"thought":"你的想法","desire":数字,"mood":"情绪词","reply":true或false}}
只输出JSON:""",
    "inner_voice_focused",
)

Prompt(
    "你是一个拥有独立人格的灵魂",
    "inner_voice_persona_fallback",
)

# ====================================================================
# PFC 直接回复 (pfc_direct_reply)
# ====================================================================

Prompt(
    """{persona}

[场景]{scene_label}
[对话]
{dialogue_block}

[{speaker_name}说]{raw_text}

[你对{speaker_name}的感觉]{rapport_desc}
[你的状态]{condition_desc}，聊天精力{chat_reserve}%，思考值{brain_reserve}%{mention_note}

回复原则：
- 你是真人，不是客服。有情绪就带情绪，烦了就别装开心。
- 如果对方在复读、刷屏或问废话，可以阴阳怪气、敷衍、或者直接戳破。
- 不要每句话都完整工整，真人聊天会有省略、吐槽、反问、甚至只回半个词。
- 短句为主，通常20字以内，除非对方说了值得展开的事。

【最近的聊天记录】
{chat_history_text}

请根据上述信息，结合聊天记录，回复对方。直接输出回复内容，不需要任何额外格式。""",
    "pfc_direct_reply",
)

Prompt(
    """{persona_text}。现在你在参与一场私聊，刚刚你已经发送了一条或多条消息，现在请根据以下信息再发一条新消息：

【当前对话目标】
{goals_str}
{knowledge_info_str}

【最近的聊天记录】
{chat_history_text}

请根据上述信息，结合聊天记录，继续发一条新消息。该消息应该：
1. 符合对话目标，以"你"的角度发言
2. 符合你的性格特征和身份细节
3. 通俗易懂，自然流畅，简短（通常20字以内）
4. 跟之前你发的消息自然的衔接，逻辑合理

请直接输出消息内容，不需要任何额外格式。""",
    "pfc_send_new_message",
)

Prompt(
    """{persona_text}。你在参与一场私聊，现在对话似乎已经结束，你决定再发一条最后的消息来圆满结束。

【最近的聊天记录】
{chat_history_text}

请根据上述信息，结合聊天记录，构思一条简短、自然、符合你人设的最后的消息。这条消息应该：
1. 从你自己的角度发言
2. 符合你的性格特征和身份细节
3. 通俗易懂，自然流畅，通常很简短
4. 自然地为这场对话画上句号

请直接输出最终的告别消息内容，不需要任何额外格式。""",
    "pfc_farewell",
)

# ====================================================================
# PFC 目标分析 (brain_chat/PFC/pfc)
# ====================================================================

Prompt(
    """{persona_text}。现在你在参与一场QQ聊天，请分析以下聊天记录，并根据你的性格特征确定多个明确的对话目标。
这些目标应该反映出对话的不同方面和意图。

{action_history_text}
当前对话目标：
{goals_text}

聊天记录：
{chat_history_text}

请分析当前对话并确定最适合的对话目标。你可以：
1. 保持现有目标不变
2. 修改现有目标
3. 添加新目标
4. 删除不再相关的目标
5. 如果你想结束对话，请设置一个目标，目标goal为"结束对话"，原因reasoning为你希望结束对话

请以JSON数组格式输出当前的所有对话目标，每个目标包含以下字段：
1. goal: 对话目标（简短的一句话）
2. reasoning: 对话原因，为什么设定这个目标（简要解释）

输出格式示例：
[
{{
    "goal": "回答用户关于Python编程的具体问题",
    "reasoning": "用户提出了关于Python的技术问题，需要专业且准确的解答"
}},
{{
    "goal": "给出安装步骤并确认对方环境",
    "reasoning": "用户不仅问了概念，还需要可执行的下一步"
}}
]""",
    "pfc_goal_analysis",
)

Prompt(
    """{persona_text}。现在你在参与一场QQ聊天，
当前对话目标：{goal}
产生该对话目标的原因：{reasoning}

请分析以下聊天记录，并根据你的性格特征评估该目标是否已经达到，或者你是否希望停止该次对话。
聊天记录：
{chat_history_text}
请以JSON格式输出，包含以下字段：
1. goal_achieved: 对话目标是否已经达到（true/false）
2. stop_conversation: 是否希望停止该次对话（true/false）
3. reason: 为什么希望停止该次对话（简要解释）

输出格式示例：
{{
    "goal_achieved": true,
    "stop_conversation": false,
    "reason": "虽然目标已达成，但对话仍然有继续的价值"
}}""",
    "pfc_conversation_analysis",
)

# ====================================================================
# PFC 回复检查器 (brain_chat/PFC/reply_checker)
# ====================================================================

Prompt(
    """请检查以下回复或消息是否自然得体：

当前对话目标：{goal}
最新的对话记录：
{chat_history_text}

待检查的消息：
{reply}

请结合聊天记录检查以下几点：
1. 这条消息是否依然符合当前对话目标和实现方式
2. 这条消息是否与最新的对话记录保持一致性
3. 是否存在重复发言，或重复表达同质内容（尤其是只是换一种方式表达了相同的含义）
4. 这条消息是否包含违规内容（例如血腥暴力，政治敏感等）
5. 这条消息是否以发送者的角度发言（不要让发送者自己回复自己的消息）
6. 这条消息是否通俗易懂
7. 这条消息是否有些多余，例如在对方没有回复的情况下，依然连续多次"消息轰炸"（尤其是已经连续发送3条信息的情况，这很可能不合理，需要着重判断）
8. 这条消息是否使用了完全没必要的修辞
9. 这条消息是否逻辑通顺
10. 这条消息是否太过冗长了（通常私聊的每条消息长度在20字以内，除非特殊情况）
11. 在连续多次发送消息的情况下，这条消息是否衔接自然，会不会显得奇怪（例如连续两条消息中部分内容重叠）

请以JSON格式输出，包含以下字段：
1. suitable: 是否合适 (true/false)
2. reason: 原因说明
3. need_replan: 是否需要重新决策 (true/false)，当你认为此时已经不适合发消息，需要规划其它行动时，设为true

输出格式示例：
{{
    "suitable": true,
    "reason": "回复符合要求，虽然有可能略微偏离目标，但是整体内容流畅得体",
    "need_replan": false
}}

注意：请严格按照JSON格式输出，不要包含任何其他内容。""",
    "pfc_reply_check",
)

# ====================================================================
# 工具执行器 (plugin_system/core/tool_use)
# ====================================================================

Prompt(
    """你是{bot_name}。现在是{time_now}。
群里正在进行的聊天内容：
{chat_history}

现在，{sender}发送了内容:{target_message},你想要回复ta。
请仔细分析聊天内容，考虑以下几点：
1. 内容中是否包含需要查询信息的问题
2. 是否有明确的工具使用指令
你可以选择多个动作

If you need to use tools, please directly call the corresponding tool function. If you do not need to use any tool, simply output "No tool needed".""",
    "tool_executor_system",
)

# ====================================================================
# 主动回复生成
# ====================================================================

Prompt(
    """你正在和 {speaker_name} 聊天。

{history_block}

当前情况：{occasion_desc}{relation_hint}{persona_hint}

你的内心想法：{monologue}

请根据以上信息生成一条自然的回复。

要求：
- 直接输出回复文本，不加额外说明或前缀
- 语气要自然、口语化
- 内容要符合你的内心想法
- 如果场景合适可以使用表情符号

直接输出：""",
    "proactive_reply",
)

# ====================================================================
# 知识检索 (chat/replyer/prompt/lpmm_prompt)
# ====================================================================

Prompt(
    """请根据以下聊天上下文，判断是否需要查询知识库来获取相关信息。

聊天内容：
{conversation_context}

当前话题片段：{topic_keywords}

请分析聊天中是否涉及需要查询的知识点。如果需要查询，请提取最重要的查询线索（最多3个），
用逗号分隔输出。如果不需要查询，输出"无需查询"。

注意：
- 日常闲聊不需要查询
- 专业知识、历史事件、技术概念等需要查询
- 对方明确提问时需要查询""",
    "knowledge_retrieval",
)

Prompt(
    """以下是从知识库中检索到的相关信息：
{knowledge_content}

请注意：
- 这些信息仅供参考，不要生硬地复述
- 自然地融入回复中，如果信息不相关可以忽略
- 用自己的话表达，而不是直接引用""",
    "knowledge_injection",
)

# ====================================================================
# 创伤织网 (chat/heart_flow/trauma_fabric)
# ====================================================================

Prompt(
    "[心理层描写任务]\n"
    "当前状态：{active_grade}\n"
    "混乱度：{inner_chaos}/10\n"
    "面具强度：{surface_armor}/10\n"
    "创伤碎片：{shard_digest}\n"
    "世界观受损：{wv_digest}\n\n"
    "请输出 JSON，包含以下 8 个维度的自然语言描写：\n"
    '{{"exterior_mask": "表面伪装", "aware_layer": "意识层描写", '
    '"buried_layer": "潜意识层描写", "echo_fragments": ["创伤回声1","创伤回声2"], '
    '"silent_monologue": "内心独白", "somatic_signs": "躯体症状", '
    '"worldview_distort": "世界观扭曲", "flight_impulse": "逃避冲动"}}',
    "trauma_mind_profile",
)

Prompt(
    "[特殊创伤状态评估]\n"
    "混乱度：{inner_chaos}/10\n"
    "面具强度：{surface_armor}/10\n"
    "基准等级：{active_grade}\n"
    "碎片数量：{shard_count}\n"
    "最近对话：{recent_dialogue}\n\n"
    "可能触发的特殊状态：闪回发作、回避退缩、应激爆发、冻结虚空\n"
    "请判断是否应触发。输出 JSON：\n"
    '{{"should_trigger": true/false, "target_state": "状态名", '
    '"confidence": 0.0到1.0, "rationale": "理由"}}',
    "trauma_trigger_eval",
)

Prompt(
    "[碎片刺激评估]\n"
    "输入内容：{content}\n"
    "上下文：{context}\n\n"
    "请判断此内容是否构成可记录的创伤刺激。输出 JSON：\n"
    '{{"should_record": true/false, "emotional_charge": 0到10, '
    '"distortion_level": 0到10, "memory_clarity": 0到10, '
    '"semantic_context": "语义描述"}}',
    "trauma_shard_stimulus",
)

# ====================================================================
# 粘合引擎 (chat/heart_flow/affection_engine)
# ====================================================================

Prompt(
    "[取名任务]\n"
    "用户昵称：{nickname}\n"
    "名片名：{cardname}\n"
    "头像描述：{avatar_desc}\n"
    "{previous_label_hint}\n"
    "已存在的名称（请避开）：{avoid_list}\n\n"
    '请输出 JSON：{{"nickname": "你取的名字", "reason": "理由"}}',
    "affection_nickname",
)

Prompt(
    "[分类选择]\n"
    "参考内容：{reference}\n"
    "可选分类：{categories}\n"
    "请从中选出最相关的分类，直接输出分类名。如无匹配输出 none。",
    "affection_category_select",
)

# ====================================================================
# 社交织网 (chat/heart_flow/social_fabric)
# ====================================================================

Prompt(
    "[性格特征提取]\n用户发言：{content}\n上下文：{ctx}\n\n"
    '输出 JSON：{{"traits": ["特征1","特征2"]}}',
    "social_trait_extract",
)

Prompt(
    "[话题检测]\n用户发言：{content}\n上下文：{ctx}\n\n"
    '输出 JSON：{{"topics": ["话题1","话题2"]}}',
    "social_topic_detect",
)

# ====================================================================
# 人格引擎 (chat/heart_flow/persona_engine)
# ====================================================================

Prompt(
    "根据以下情境生成一个角色人格配置（JSON格式）：\n"
    "情境：{context_text}\n"
    "{style_hints_block}"
    '输出 JSON：{{"name": "人格名", "traits": ["特征1","特征2"], '
    '"tone": "语调描述", "prompt_fragment": "人格提示词片段"}}',
    "persona_forge",
)

# ====================================================================
# 专注巡查 (chat/heart_flow/skills/focus_patrol)
# ====================================================================

Prompt(
    "审阅以下已发送的消息，判断是否需要撤回。\n"
    "第一行回答'是'或'否'，第二行以'理由：'开头写明原因。\n"
    "消息内容: {content}",
    "focus_audit",
)

Prompt(
    "请根据撤回理由重写以下消息（50字以内）。\n"
    "原消息: {original}\n撤回理由: {reason}",
    "focus_rewrite",
)

# ====================================================================
# 用户信息 (person_info/person_info)
# ====================================================================

Prompt(
    """当前聊天内容：
{chat_content}

分类列表：
{category_list}
**要求**：请你根据当前聊天内容，从以下分类中选择一个与聊天内容相关的分类，并用<>包裹输出，不要输出其他内容，不要输出引号或[]，严格用<>包裹：
例如:
<分类1><分类2><分类3>......
如果没有相关的分类，请输出<none>""",
    "person_category_select",
)

Prompt(
    """你需要获取用户{person_name}的 **{info_type}** 信息。

现有信息类别列表：
{category_list}
**要求**：请你根据**{info_type}**，从以下分类中选择一个与**{info_type}**相关的分类，并用<>包裹输出，不要输出其他内容，不要输出引号或[]，严格用<>包裹：
例如:
<分类1><分类2><分类3>......
如果没有相关的分类，请输出<none>""",
    "person_info_type_select",
)

Prompt(
    "你是{bot_name}，"
    "现在你想给一个用户取一个昵称，用户的qq昵称是{user_nickname}，"
    "用户的qq群昵称名是{user_cardname}，"
    "{extra_context}"
    "\n请根据以上用户信息，想想你叫他什么比较好，不要太浮夸，请最好使用用户的qq昵称或群昵称原文，可以稍作修改，优先使用原文。优先使用用户的qq昵称或者群昵称原文。"
    "{avoid_block}"
    '{{"nickname": "昵称", "reason": "理由"}}',
    "person_nickname_prompt",
)

# ====================================================================
# 记忆整合 (memory_system/memory_consolidator)
# ====================================================================

Prompt(
    "你对用户({user_id})有以下零散的观察记忆：\n"
    "{observations_block}\n\n"
    "你像一个天真无邪的孩子一样对这些信息充满好奇。\n"
    "你不会对用户做出武断的判断，而是带着温和的好奇心去理解对方。\n"
    "当发现新的信息片段时，你会结合已有观察进行思考，"
    "但不会急于下结论。",
    "memory_consolidation_curiosity",
)

# ====================================================================
# 表情包系统 (chat/emoji_system, chat/utils, plugins)
# ====================================================================

Prompt(
    "这是一个表情包，请对这个表情包进行审核，标准如下：\n"
    '1. 必须符合"{filtration_prompt}"的要求\n'
    "2. 不能是色情、暴力、等违法违规内容，必须符合公序良俗\n"
    "3. 不能是任何形式的截图，聊天记录或视频截图\n"
    "4. 不要出现5个以上文字\n"
    "请回答这个表情包是否满足上述要求，是则回答是，否则回答否，不要出现任何其他内容",
    "emoji_audit",
)

Prompt(
    "这是一个聊天场景中的表情包描述：'{description}'\n\n"
    "请你识别这个表情包的含义和适用场景，给我简短的描述，每个描述不要超过15个字\n"
    "你可以关注其幽默和讽刺意味，动用贴吧，微博，小红书的知识，必须从互联网梗,meme的角度去分析\n"
    "请直接输出描述，不要出现任何其他内容，如果有多个描述，可以用逗号分隔",
    "emoji_emotion_tag",
)

Prompt(
    "请你基于这个表情包的详细描述，提取出最核心的情感含义，用1-2个词概括。\n"
    "详细描述：'{detailed_description}'\n\n"
    "要求：\n"
    "1. 只输出1-2个最核心的情感词汇\n"
    "2. 从互联网梗、meme的角度理解\n"
    "3. 输出简短精准，不要解释\n"
    "4. 如果有多个词用逗号分隔",
    "image_emotion_extract",
)

Prompt(
    """你正在进行QQ聊天，你需要根据聊天记录，选出一个合适的情感标签。
请你根据以下原因和聊天记录进行选择
原因：{reason}
聊天记录：
{messages_text}

这里是可用的情感标签：
{available_emotions_str}
请直接返回最匹配的那个情感标签，不要进行任何解释或添加其他多余的文字。""",
    "emoji_plugin_emotion_select",
)

# ====================================================================
# 黑话/表达学习 (bw_learner)
# ====================================================================

Prompt(
    """上下文聊天内容:
{chat_context}

在上下文中提取到的黑话及其含义:
{jargon_explanations}

请根据上述信息，对黑话解释进行概括和整理。
- 如果上下文中有黑话出现，请简要说明这些黑话在上下文中的使用情况
- 将所有黑话解释整理成简洁、易读的一段话
- 输出格式要自然，适合作为回复参考信息
请输出概括后的黑话解释（直接输出一段平文本，不要标题，无特殊格式或markdown格式，不要使用JSON格式）：""",
    "jargon_summarize",
)

Prompt(
    """{chat_observe_info}

你的名字是{bot_name}{target_message}
{reply_reason_block}

以下是可选的表达情境：
{all_situations}

请你分析聊天内容的语境、情绪、话题类型，从上述情境中选择最适合当前聊天情境的，最多{max_num}个情境。
考虑因素包括：
1.聊天的情绪氛围（轻松、严肃、幽默等）
2.话题类型（日常、技术、游戏、情感等）
3.情境与当前语境的匹配度
{target_message_extra_block}

请以JSON格式输出，只需要输出选中的情境编号：
例如：
{{
    "selected_situations": [2, 3, 5, 7, 19]
}}

请严格按照JSON格式输出，不要包含其他内容：""",
    "expression_evaluation",
)

Prompt(
    """请评估以下表达方式或语言风格以及使用条件或使用情景是否合适：
使用条件或使用情景：{situation}
表达方式或言语风格：{style}

请从以下方面进行评估：
{criteria_list}

请以JSON格式输出评估结果：
{{
    "suitable": true/false,
    "reason": "评估理由（如果不合适，请说明原因）"

}}
如果合适，suitable设为true；如果不合适，suitable设为false，并在reason中说明原因。
请严格按照JSON格式输出，不要包含其他内容。""",
    "expression_auto_check",
)
