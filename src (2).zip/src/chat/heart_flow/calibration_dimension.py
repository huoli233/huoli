import math
import time as _tm
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from src.chat.heart_flow.dimension_protocol import (
    DimensionBase,
    DimensionScope,
    DimensionVote,
    EventContext,
    TickResult,
)
from src.common.logger import get_logger

logger = get_logger("校准维度")

_LIGHT_THRESHOLD_SEC = 3600.0
_MODERATE_THRESHOLD_SEC = 86400.0


@dataclass
class _CalibrationState:
    last_active_ts: float = field(default_factory=_tm.time)
    calibrated: bool = False
    offline_total_sec: float = 0.0
    current_level: str = "无"
    intimacy_delta: float = 0.0
    emotion_delta: float = 0.0
    memory_forget_prob: float = 0.0
    last_calibrate_ts: float = 0.0


class CalibrationDimension(DimensionBase):
    """D9 系统校准维度

    职责:
      - 追踪系统活跃/离线时长
      - 离线后分级校准（轻度/中度/重度）
      - 向其他维度广播校准信号，触发衰减补算
      - 为决策网关提供离线恢复因子投票
    """

    _instance: Optional["CalibrationDimension"] = None

    def __init__(self):
        self._state = _CalibrationState()
        self._calibrate_hooks: list = []

    @classmethod
    def get_instance(cls) -> "CalibrationDimension":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @property
    def dimension_name(self) -> str:
        return "system_calibration"

    @property
    def scope(self) -> DimensionScope:
        return DimensionScope.GLOBAL

    @property
    def needs_persistence(self) -> bool:
        return True

    @property
    def tick_interval_sec(self) -> float:
        return 5.0

    def initialize(self):
        self.restore_state()

    def tick(self, elapsed_sec: float) -> TickResult:
        now = _tm.time()
        self._state.last_active_ts = now
        return TickResult(
            dimension_name=self.dimension_name,
            updated=False,
            persisted=False,
            summary="tick-keepalive",
        )

    def on_event(self, ctx: EventContext):
        if ctx.event_type == "message_received":
            self.mark_active()
        elif ctx.event_type == "reply_completed":
            self.mark_active()

    def vote(self, ctx: EventContext) -> DimensionVote:
        offline_sec = max(0.0, _tm.time() - self._state.last_active_ts)
        level = self._determine_level(offline_sec)
        if level == "无" or offline_sec < _LIGHT_THRESHOLD_SEC:
            return DimensionVote(
                dimension_name=self.dimension_name,
                probability_factor=1.0,
                debug_reason="在线/轻度离线，无影响",
            )
        if level == "中度":
            factor = max(0.6, 1.0 - (offline_sec / _MODERATE_THRESHOLD_SEC) * 0.3)
            return DimensionVote(
                dimension_name=self.dimension_name,
                probability_factor=round(factor, 3),
                attitude_tag="略显生疏",
                style_hint="稍显拘谨",
                debug_reason=f"中度离线({offline_sec / 3600:.1f}h)",
            )
        factor = max(0.2, 1.0 - (offline_sec / (_MODERATE_THRESHOLD_SEC * 3)) * 0.7)
        return DimensionVote(
            dimension_name=self.dimension_name,
            probability_factor=round(factor, 3),
            attitude_tag="明显疏远",
            style_hint="冷淡简短",
            debug_reason=f"重度离线({offline_sec / 3600:.1f}h)",
        )

    def mark_active(self) -> None:
        self._state.last_active_ts = _tm.time()
        self._state.calibrated = False

    def calibrate(self, offline_seconds: float) -> Dict[str, Any]:
        """执行一次完整校准并返回结果摘要"""
        level = self._determine_level(offline_seconds)
        now = _tm.time()
        self._state.offline_total_sec = offline_seconds
        self._state.current_level = level
        self._state.last_calibrate_ts = now
        if level == "无":
            self._state.intimacy_delta = 0.0
            self._state.emotion_delta = 0.0
            self._state.memory_forget_prob = 0.0
            self._state.calibrated = True
            logger.info(f"[校准] 轻度({offline_seconds:.0f}s)，几乎无衰减")
            result = {"level": level, "intimacy_delta": 0.0, "emotion_delta": 0.0}
        else:
            hours = offline_seconds / 3600.0
            intimacy_rate = 0.5
            emotion_half_life = 12.0
            new_intimacy = max(0.0, 50.0 - intimacy_rate * hours)
            decay_factor = math.exp(-0.693 * hours / emotion_half_life)
            new_emotion = 50.0 * decay_factor
            forget_prob = 1.0 - math.exp(-0.01 * hours)
            self._state.intimacy_delta = round(new_intimacy - 50.0, 2)
            self._state.emotion_delta = round(new_emotion - 50.0, 2)
            self._state.memory_forget_prob = round(forget_prob, 4)
            self._state.calibrated = True
            result = {
                "level": level,
                "intimacy_delta": self._state.intimacy_delta,
                "emotion_delta": self._state.emotion_delta,
                "memory_forget_prob": self._state.memory_forget_prob,
                "hours_offline": round(hours, 1),
            }
            logger.info(
                f"[校准] {level}({hours:.1f}h) "
                f"亲密度{self._state.intimacy_delta:+.1f} "
                f"情绪{self._state.emotion_delta:+.1f} "
                f"遗忘{self._state.memory_forget_prob:.3f}"
            )
        self._fire_hooks(result)
        return result

    def register_hook(self, hook):
        self._calibrate_hooks.append(hook)

    def _fire_hooks(self, summary: dict):
        for hook in self._calibrate_hooks:
            try:
                hook(summary)
            except Exception as exc:
                logger.debug(f"[校准] 回调异常: {exc}")

    def _determine_level(self, offline_sec: float) -> str:
        if offline_sec < _LIGHT_THRESHOLD_SEC:
            return "无"
        if offline_sec < _MODERATE_THRESHOLD_SEC:
            return "轻度"
        return "重度"

    def serialize(self) -> dict:
        return {
            "last_active_ts": self._state.last_active_ts,
            "current_level": self._state.current_level,
            "offline_total_sec": self._state.offline_total_sec,
            "last_calibrate_ts": self._state.last_calibrate_ts,
        }

    def deserialize(self, data: dict):
        if not data:
            return
        self._state.last_active_ts = data.get(
            "last_active_ts", _tm.time()
        )
        self._state.current_level = data.get("current_level", "无")
        self._state.offline_total_sec = data.get(
            "offline_total_sec", 0.0
        )
        self._state.last_calibrate_ts = data.get(
            "last_calibrate_ts", 0.0
        )

    def restore_state(self) -> bool:
        try:
            from src.chat.heart_flow.persistent_state_db import (
                acquire_persistent_store,
            )
            data = acquire_persistent_store().get_state(
                "dimension_calibration", "__global__"
            )
            if data and isinstance(data, dict):
                self.deserialize(data)
                logger.debug("[校准维度] 已从数据库恢复状态")
                return True
        except Exception as exc:
            logger.debug(f"[校准维度] 恢复失败: {exc}")
        return False

    def persist_state(self) -> bool:
        try:
            from src.chat.heart_flow.persistent_state_db import (
                acquire_persistent_store,
            )
            payload = self.serialize()
            payload["saved_at"] = _tm.time()
            acquire_persistent_store().set_state(
                "dimension_calibration", "__global__", payload
            )
            return True
        except Exception as exc:
            logger.debug(f"[校准维度] 持久化失败: {exc}")
            return False

    def get_state_summary(self) -> dict:
        offline_sec = max(0.0, _tm.time() - self._state.last_active_ts)
        return {
            "dimension": self.dimension_name,
            "scope": self.scope.value,
            "current_level": self._state.current_level,
            "offline_seconds": round(offline_sec, 0),
            "offline_hours": round(offline_sec / 3600, 1),
            "calibrated": self._state.calibrated,
            "last_calibrate_ts": self._state.last_calibrate_ts,
        }

    def reset(self, user_id: str = "", channel_id: str = ""):
        self._state = _CalibrationState()


def get_calibration_dimension() -> CalibrationDimension:
    return CalibrationDimension.get_instance()
